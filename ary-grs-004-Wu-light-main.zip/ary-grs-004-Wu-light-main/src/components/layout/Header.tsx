import Link from "next/link";
import Image from "next/image";
import { auth, signOut } from "@/lib/auth";
import { PublicNav } from "@/components/layout/PublicNav";
import aryLogo from "../../../design-prototype/assets/logo-horse-compass-transparent.png";

export async function Header() {
  const session = await auth();
  const user = session?.user;

  return (
    <header className="fixed inset-x-0 top-0 z-50 border-b border-ary-line bg-white/80 backdrop-blur-xl supports-[backdrop-filter]:bg-white/70">
      <div className="mx-auto flex h-[72px] max-w-[1440px] items-center justify-between gap-4 px-5 sm:px-8 lg:px-12">
        <Link href="/" className="flex min-w-0 items-center gap-3 no-underline" aria-label="ARY 首页">
          <Image src={aryLogo} alt="" priority className="h-11 w-11 object-contain" />
          <span className="min-w-0">
            <strong className="block truncate text-base font-black tracking-tight text-ary-blue-950 sm:text-lg">
              Agent Racing Yard
            </strong>
            <span className="hidden text-[11px] font-semibold text-ary-muted sm:block">
              骑行智能体 · 看见真实能力
            </span>
          </span>
        </Link>

        <PublicNav authenticated={Boolean(user)} />

        <div className="hidden items-center gap-3 md:flex">
          {user ? (
            <div className="flex items-center gap-3">
              <Link
                href="/console"
                className="flex items-center gap-2 rounded-xl border border-ary-line bg-white px-2.5 py-1.5 text-xs font-bold text-ary-blue-700 transition hover:border-ary-line-strong hover:bg-ary-blue-100"
              >
                {(user as any).image ? (
                  <Image
                    src={(user as any).image}
                    alt=""
                    width={24}
                    height={24}
                    className="h-6 w-6 rounded-full object-cover"
                    unoptimized
                  />
                ) : (
                  <span className="flex h-6 w-6 items-center justify-center rounded-full bg-ary-blue-200 text-[11px] font-bold text-ary-blue-800">
                    {(user.name ?? "U")[0]}
                  </span>
                )}
                <span>Workspace</span>
              </Link>
              <form
                action={async () => {
                  "use server";
                  await signOut({ redirectTo: "/" });
                }}
              >
                <button
                  type="submit"
                  className="min-h-10 px-2 text-xs font-semibold text-ary-muted transition-colors hover:text-ary-blue-900"
                >
                  Sign Out
                </button>
              </form>
            </div>
          ) : (
            <Link
              href="/login"
              className="rounded-xl bg-ary-blue-800 px-4 py-2.5 text-xs font-bold text-white shadow-[0_8px_20px_rgba(7,91,236,0.2)] transition hover:-translate-y-0.5 hover:bg-ary-blue-700"
            >
              Login
            </Link>
          )}
        </div>
      </div>
    </header>
  );
}
