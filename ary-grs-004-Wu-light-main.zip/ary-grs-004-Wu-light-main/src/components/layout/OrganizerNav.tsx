import Link from "next/link";

const ITEMS = [
  { label: "Overview", href: "" },
  { label: "Settings", href: "/settings" },
  { label: "Registrations", href: "/registrations" },
  { label: "Riders", href: "/riders" },
  { label: "CA Status", href: "/ca-status" },
  { label: "Works", href: "/works" },
  { label: "Judges", href: "/judges" },
  { label: "Judging", href: "/judging" },
  { label: "Awards", href: "/awards" },
  { label: "Reports", href: "/reports" },
  { label: "Maintenance", href: "/maintenance" },
];

export function OrganizerNav({ slug, current }: { slug: string; current: string }) {
  return (
    <nav className="mb-6 flex flex-wrap gap-2">
      {ITEMS.map((item) => {
        const href = `/console/races/${slug}/organizer${item.href}`;
        const isActive = item.label.toLowerCase() === current.toLowerCase();
        return (
          <Link
            key={item.href}
            href={href}
            className={`rounded-lg px-3 py-1.5 text-xs font-medium transition-colors ${
              isActive
                ? "bg-ary-blue-100 text-ary-blue-900"
                : "text-slate-500 hover:bg-slate-100 hover:text-slate-800"
            }`}
          >
            {item.label}
          </Link>
        );
      })}
    </nav>
  );
}
