import type { Role } from "@/types";

interface RequireRoleProps {
  roles: Role[];
  userRoles: string[];
  children: React.ReactNode;
  fallback?: React.ReactNode;
}

export function RequireRole({ roles, children, fallback, userRoles }: RequireRoleProps) {
  const hasRole = roles.some((r) => userRoles.includes(r));

  if (!hasRole) {
    return (
      <>
        {fallback ?? (
          <div className="flex min-h-[200px] items-center justify-center">
            <p className="text-sm text-muted-foreground">
              Access Denied — you do not have the required role.
            </p>
          </div>
        )}
      </>
    );
  }

  return <>{children}</>;
}
