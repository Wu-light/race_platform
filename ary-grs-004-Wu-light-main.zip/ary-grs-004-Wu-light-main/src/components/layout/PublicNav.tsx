"use client";

import Link from "next/link";
import { Menu, X } from "lucide-react";
import { usePathname } from "next/navigation";
import { useEffect, useRef, useState } from "react";
import { cn } from "@/lib/utils";

const publicLinks = [
  { href: "/", label: "Races", match: (path: string) => path === "/" || path.startsWith("/races/") },
  { href: "/#works", label: "Works", match: (path: string) => path.startsWith("/works/") },
  { href: "/#riders", label: "Riders", match: (path: string) => path.startsWith("/riders/") },
  { href: "/cooperation", label: "Cooperation", match: (path: string) => path === "/cooperation" },
];

export function PublicNav({ authenticated }: { authenticated: boolean }) {
  const pathname = usePathname();
  const [open, setOpen] = useState(false);
  const triggerRef = useRef<HTMLButtonElement>(null);
  const panelRef = useRef<HTMLDivElement>(null);

  useEffect(() => setOpen(false), [pathname]);

  useEffect(() => {
    if (!open) return;
    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    const firstLink = panelRef.current?.querySelector<HTMLElement>("a");
    firstLink?.focus();

    function onKeyDown(event: KeyboardEvent) {
      if (event.key === "Escape") {
        setOpen(false);
        triggerRef.current?.focus();
        return;
      }
      if (event.key !== "Tab" || !panelRef.current) return;
      const focusable = Array.from(
        panelRef.current.querySelectorAll<HTMLElement>("a, button"),
      );
      if (focusable.length === 0) return;
      const first = focusable[0];
      const last = focusable[focusable.length - 1];
      if (event.shiftKey && document.activeElement === first) {
        event.preventDefault();
        last.focus();
      } else if (!event.shiftKey && document.activeElement === last) {
        event.preventDefault();
        first.focus();
      }
    }

    document.addEventListener("keydown", onKeyDown);
    return () => {
      document.body.style.overflow = previousOverflow;
      document.removeEventListener("keydown", onKeyDown);
    };
  }, [open]);

  return (
    <>
      <nav className="hidden items-center gap-1 md:flex" aria-label="公开站点导航">
        {publicLinks.map((link) => {
          const active = link.match(pathname);
          return (
            <Link
              key={link.href}
              href={link.href}
              aria-current={active ? "page" : undefined}
              className={cn(
                "relative rounded-lg px-3 py-2 text-sm font-semibold transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ary-blue-700",
                active ? "text-ary-blue-900" : "text-ary-muted hover:text-ary-blue-900",
              )}
            >
              {link.label}
              {active && (
                <span className="absolute inset-x-3 -bottom-0.5 h-0.5 rounded-full bg-ary-blue-700" aria-hidden="true" />
              )}
            </Link>
          );
        })}
      </nav>

      <button
        ref={triggerRef}
        type="button"
        aria-expanded={open}
        aria-controls="public-mobile-nav"
        aria-label={open ? "关闭导航" : "打开导航"}
        onClick={() => setOpen((value) => !value)}
        className="grid h-11 w-11 place-items-center rounded-xl border border-ary-line bg-white/80 text-ary-blue-900 md:hidden"
      >
        {open ? <X className="h-5 w-5" aria-hidden="true" /> : <Menu className="h-5 w-5" aria-hidden="true" />}
      </button>

      {open && (
        <div className="fixed inset-0 top-[73px] z-40 bg-ary-blue-950/30 backdrop-blur-sm md:hidden" onMouseDown={() => setOpen(false)}>
          <div
            ref={panelRef}
            id="public-mobile-nav"
            role="dialog"
            aria-modal="true"
            aria-label="移动导航"
            className="ml-auto h-full w-[min(88vw,360px)] border-l border-ary-line bg-white p-5 shadow-2xl"
            onMouseDown={(event) => event.stopPropagation()}
          >
            <nav className="grid gap-2" aria-label="移动端公开站点导航">
              {publicLinks.map((link) => (
                <Link
                  key={link.href}
                  href={link.href}
                  aria-current={link.match(pathname) ? "page" : undefined}
                  className={cn(
                    "rounded-xl px-4 py-3 text-base font-bold",
                    link.match(pathname)
                      ? "bg-ary-blue-100 text-ary-blue-900"
                      : "text-ary-muted hover:bg-slate-50 hover:text-ary-blue-900",
                  )}
                >
                  {link.label}
                </Link>
              ))}
              <Link
                href={authenticated ? "/console" : "/login"}
                className="mt-4 rounded-xl bg-ary-blue-800 px-4 py-3 text-center font-bold text-white"
              >
                {authenticated ? "进入 Workspace" : "Login"}
              </Link>
            </nav>
          </div>
        </div>
      )}
    </>
  );
}
