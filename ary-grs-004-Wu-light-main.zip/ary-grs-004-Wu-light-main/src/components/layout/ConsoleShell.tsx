import Link from "next/link";
import Image from "next/image";
import { auth, signOut } from "@/lib/auth";
import { getUserRoles } from "@/lib/permissions";
import { prisma } from "@/lib/db";
import aryLogo from "../../../design-prototype/assets/logo-horse-compass-transparent.png";

interface ConsoleShellProps {
  children: React.ReactNode;
  currentRace?: { slug: string; title: string } | null;
}

export async function ConsoleShell({ children, currentRace = null }: ConsoleShellProps) {
  const session = await auth();
  if (!session?.user) return null;

  const roles = getUserRoles((session.user as any).roles ?? "[]");

  const managedRaces =
    roles.includes("organizer") || roles.includes("admin")
      ? await prisma.race.findMany({
          where: roles.includes("admin") ? {} : { organizerId: session.user.id },
          select: { id: true, slug: true, title: true },
          orderBy: { createdAt: "desc" },
          take: 20,
        })
      : [];

  const riderRegs =
    roles.includes("rider")
      ? await prisma.registration.findMany({
          where: { userId: session.user.id },
          select: { race: { select: { slug: true, title: true } }, status: true },
          orderBy: { createdAt: "desc" },
          take: 20,
        })
      : [];

  const user = session.user;

  return (
    <div className="flex min-h-screen flex-col">
      <header className="sticky top-0 z-50 flex h-16 shrink-0 items-center justify-between border-b border-ary-line bg-white/90 px-6 backdrop-blur-xl">
        <div className="flex items-center gap-3">
          <Image src={aryLogo} alt="" className="h-8 w-8 object-contain" />
          <Link href="/console" className="text-base font-black tracking-tight text-ary-blue-950 no-underline">
            ARY Console
          </Link>
          {currentRace && (
            <>
              <span className="text-ary-muted">/</span>
              <span className="text-sm font-semibold text-ary-blue-800">{currentRace.title}</span>
            </>
          )}
        </div>
        <div className="flex items-center gap-3">
          {user.image ? (
            <Image
              src={user.image as string}
              alt=""
              width={28}
              height={28}
              className="h-7 w-7 rounded-full object-cover"
              unoptimized
            />
          ) : (
            <span className="flex h-7 w-7 items-center justify-center rounded-full bg-ary-blue-200 text-[11px] font-bold text-ary-blue-800">
              {(user.name ?? "U")[0]}
            </span>
          )}
          <span className="hidden text-sm font-medium text-ary-blue-950 sm:inline">
            {user.name ?? "User"}
          </span>
          <form
            action={async () => {
              "use server";
              await signOut({ redirectTo: "/" });
            }}
          >
            <button
              type="submit"
              className="rounded-lg px-3 py-1.5 text-xs font-semibold text-ary-muted transition-colors hover:bg-slate-100 hover:text-ary-blue-900"
            >
              Sign Out
            </button>
          </form>
        </div>
      </header>

      <div className="flex flex-1">
        <aside className="sticky top-16 z-40 flex h-[calc(100vh-4rem)] w-64 shrink-0 flex-col border-r border-ary-line bg-white">
          <nav className="flex-1 overflow-y-auto px-3 py-4">
            <Link
              href="/console"
              className="flex items-center gap-2 rounded-lg px-3 py-2 text-sm font-medium text-ary-blue-900 transition-colors hover:bg-ary-blue-50"
            >
              Home
            </Link>

            {roles.includes("admin") && (
              <Link
                href="/console/admin"
                className="mt-1 flex items-center gap-2 rounded-lg px-3 py-2 text-sm font-medium text-ary-blue-900 transition-colors hover:bg-ary-blue-50"
              >
                Admin Console
              </Link>
            )}

            {(roles.includes("organizer") || roles.includes("admin")) && managedRaces.length > 0 && (
              <div className="mt-4">
                <p className="mb-1 px-3 text-[11px] font-semibold uppercase tracking-wider text-ary-muted">
                  My Races
                </p>
                {managedRaces.map((race) => (
                  <Link
                    key={race.id}
                    href={`/console/races/${race.slug}/organizer`}
                    className={`flex items-center gap-2 rounded-lg px-3 py-1.5 text-sm transition-colors ${
                      currentRace?.slug === race.slug
                        ? "bg-ary-blue-100 font-semibold text-ary-blue-900"
                        : "text-ary-blue-800 hover:bg-ary-blue-50"
                    }`}
                  >
                    {race.title}
                  </Link>
                ))}
              </div>
            )}

            {roles.includes("rider") && riderRegs.length > 0 && (
              <div className="mt-4">
                <p className="mb-1 px-3 text-[11px] font-semibold uppercase tracking-wider text-ary-muted">
                  My Rides
                </p>
                {riderRegs.map((reg, i) => (
                  <Link
                    key={i}
                    href={`/console/races/${reg.race.slug}/rider`}
                    className={`flex items-center gap-2 rounded-lg px-3 py-1.5 text-sm transition-colors ${
                      currentRace?.slug === reg.race.slug
                        ? "bg-ary-blue-100 font-semibold text-ary-blue-900"
                        : "text-ary-blue-800 hover:bg-ary-blue-50"
                    }`}
                  >
                    {reg.race.title}
                  </Link>
                ))}
              </div>
            )}

            {roles.includes("judge") && (
              <Link
                href="/console/races/judge"
                className="mt-1 flex items-center gap-2 rounded-lg px-3 py-2 text-sm font-medium text-ary-blue-900 transition-colors hover:bg-ary-blue-50"
              >
                Judge View
              </Link>
            )}

            {(roles.includes("organizer") || roles.includes("admin")) && (
              <Link
                href="/console/screen"
                className="mt-1 flex items-center gap-2 rounded-lg px-3 py-2 text-sm font-medium text-ary-blue-900 transition-colors hover:bg-ary-blue-50"
              >
                Screen Console
              </Link>
            )}
          </nav>

          <div className="border-t border-ary-line px-4 py-3">
            <p className="truncate text-[11px] text-ary-muted">Roles: {roles.join(", ") || "none"}</p>
          </div>
        </aside>

        <main className="flex-1 bg-slate-50">{children}</main>
      </div>
    </div>
  );
}
