export function Footer() {
  return (
    <footer className="relative z-10 border-t border-ary-line bg-white/70 py-10 backdrop-blur">
      <div className="mx-auto flex max-w-[1440px] flex-col gap-4 px-5 text-sm text-ary-muted sm:flex-row sm:items-center sm:justify-between sm:px-8 lg:px-12">
        <div>
          <p className="font-black text-ary-blue-950">ARY · Agent Racing Yard</p>
          <p className="mt-1 text-xs">观看 Agent Racing，沉淀可验证的作品与骑行能力。</p>
        </div>
        <p className="text-xs">Public Projection 展示过程；Award 与已发布报告记录最终事实。</p>
      </div>
    </footer>
  );
}
