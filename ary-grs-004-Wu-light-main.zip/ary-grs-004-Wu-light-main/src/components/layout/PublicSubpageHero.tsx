import Link from "next/link";
import { ArrowLeft } from "lucide-react";

export function PublicSubpageHero({
  eyebrow,
  title,
  description,
  backHref,
  backLabel,
  meta,
  actions,
}: {
  eyebrow: string;
  title: string;
  description: string;
  backHref: string;
  backLabel: string;
  meta?: React.ReactNode;
  actions?: React.ReactNode;
}) {
  return (
    <section className="relative overflow-hidden border-b border-ary-line bg-white/30 pt-[72px]">
      <div className="ary-content pb-14 pt-10 sm:pb-18 sm:pt-14">
        <Link href={backHref} className="inline-flex min-h-11 items-center gap-2 text-sm font-bold text-ary-muted hover:text-ary-blue-700">
          <ArrowLeft className="h-4 w-4" aria-hidden="true" /> {backLabel}
        </Link>
        <div className="mt-7 grid gap-7 lg:grid-cols-[minmax(0,1fr)_auto] lg:items-end">
          <div className="max-w-4xl">
            <p className="text-xs font-black uppercase tracking-[0.2em] text-ary-blue-700">{eyebrow}</p>
            <h1 className="mt-3 text-[clamp(2.8rem,6vw,5.8rem)] font-black leading-[0.96] tracking-[-0.045em] text-ary-blue-950">{title}</h1>
            <p className="mt-5 max-w-3xl text-base leading-7 text-ary-muted sm:text-lg">{description}</p>
            {meta && <div className="mt-5 flex flex-wrap gap-2">{meta}</div>}
          </div>
          {actions && <div className="flex flex-col gap-3 sm:flex-row lg:justify-end">{actions}</div>}
        </div>
      </div>
    </section>
  );
}
