import Link from "next/link";
import { ArrowRight, Award, Layers3 } from "lucide-react";
import type { PublicRiderSummary } from "@/types/public";

function initials(name: string) {
  return name
    .split(/\s+/)
    .map((part) => part[0])
    .join("")
    .slice(0, 2)
    .toUpperCase();
}

export function RiderCard({ rider }: { rider: PublicRiderSummary }) {
  return (
    <article className="ary-glass flex h-full flex-col rounded-3xl p-6">
      <div className="flex items-center gap-4">
        <div className="grid h-14 w-14 shrink-0 place-items-center rounded-2xl bg-gradient-to-br from-ary-blue-800 to-ary-blue-500 text-base font-black text-white shadow-[0_10px_24px_rgba(7,91,236,0.2)]">
          {initials(rider.name)}
        </div>
        <div className="min-w-0">
          <p className="text-xs font-bold uppercase tracking-[0.14em] text-ary-blue-700">Rider</p>
          <h3 className="truncate text-xl font-black text-ary-blue-950">
            {rider.slug ? <Link href={`/riders/${rider.slug}`} className="hover:text-ary-blue-700">{rider.name}</Link> : rider.name}
          </h3>
          <p className="truncate text-sm text-ary-muted">{rider.affiliation || "独立开发者"}</p>
        </div>
      </div>
      <div className="mt-5 rounded-2xl bg-ary-blue-100/70 p-4">
        <p className="text-xs font-semibold text-ary-muted">代表作品</p>
        <p className="mt-1 font-bold text-ary-blue-950">{rider.representativeWork}</p>
        <p className="mt-1 text-xs text-ary-blue-700">{rider.representativeRace}</p>
      </div>
      <div className="mt-4 flex flex-wrap gap-2">
        {rider.skillTags.map((tag) => (
          <span key={tag} className="rounded-full border border-ary-line bg-white/70 px-2.5 py-1 text-xs font-semibold text-ary-blue-800">
            {tag}
          </span>
        ))}
      </div>
      <div className="mt-auto flex items-center gap-4 pt-5 text-xs font-semibold text-ary-muted">
        <span className="inline-flex items-center gap-1.5"><Layers3 className="h-3.5 w-3.5" aria-hidden="true" />{rider.workCount} 作品</span>
        <span className="inline-flex items-center gap-1.5"><Award className="h-3.5 w-3.5" aria-hidden="true" />{rider.awardCount} 奖项</span>
        {rider.slug ? (
          <Link href={`/riders/${rider.slug}`} className="ml-auto inline-flex min-h-11 items-center gap-1.5 text-ary-blue-700 hover:text-ary-blue-950">
            查看档案 <ArrowRight className="h-3.5 w-3.5" aria-hidden="true" />
          </Link>
        ) : <span className="ml-auto text-ary-blue-500">档案待开放</span>}
      </div>
    </article>
  );
}
