"use client";

import { Search } from "lucide-react";
import { useMemo, useState } from "react";
import { EmptyState } from "@/components/ui/EmptyState";
import { WorkCard } from "@/components/work/WorkCard";
import type { PublicWorkSummary } from "@/types/public";

export function WorksExplorer({ works }: { works: PublicWorkSummary[] }) {
  const [query, setQuery] = useState("");
  const [sort, setSort] = useState<"featured" | "title">("featured");
  const visibleWorks = useMemo(() => {
    const normalized = query.trim().toLocaleLowerCase("zh-CN");
    return works
      .filter((work) => !normalized || [work.title, work.description, work.author.name, ...work.awards].join(" ").toLocaleLowerCase("zh-CN").includes(normalized))
      .sort((a, b) => sort === "title" ? a.title.localeCompare(b.title, "zh-CN") : b.awards.length - a.awards.length || a.title.localeCompare(b.title, "zh-CN"));
  }, [query, sort, works]);

  return (
    <div>
      <div className="flex flex-col gap-3 rounded-3xl border border-ary-line bg-white/70 p-4 shadow-sm backdrop-blur sm:flex-row sm:items-center">
        <label className="relative flex-1">
          <span className="sr-only">搜索公开作品</span>
          <Search className="pointer-events-none absolute left-4 top-1/2 h-4 w-4 -translate-y-1/2 text-ary-blue-500" aria-hidden="true" />
          <input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="搜索作品、Rider 或奖项" className="min-h-12 w-full rounded-2xl border border-ary-line bg-white pl-11 pr-4 text-sm text-ary-blue-950 outline-none transition placeholder:text-ary-muted/70 focus:border-ary-blue-500 focus:ring-2 focus:ring-ary-blue-500/20" />
        </label>
        <label className="flex items-center gap-3 text-sm font-bold text-ary-muted">
          <span className="shrink-0">排序</span>
          <select value={sort} onChange={(event) => setSort(event.target.value as "featured" | "title")} className="min-h-12 rounded-2xl border border-ary-line bg-white px-4 text-ary-blue-950 outline-none focus:border-ary-blue-500 focus:ring-2 focus:ring-ary-blue-500/20">
            <option value="featured">奖项优先</option>
            <option value="title">名称排序</option>
          </select>
        </label>
        <span className="shrink-0 px-2 text-sm font-semibold text-ary-muted" aria-live="polite">{visibleWorks.length} 个作品</span>
      </div>
      {visibleWorks.length > 0 ? (
        <div className="mt-7 grid gap-5 md:grid-cols-2 xl:grid-cols-3">
          {visibleWorks.map((work, index) => <WorkCard key={work.id} work={work} featured={index === 0 && work.awards.length > 0} />)}
        </div>
      ) : (
        <div className="mt-7"><EmptyState title="没有匹配的公开作品" description="尝试缩短关键词，或按名称浏览本场全部公开作品。" /></div>
      )}
    </div>
  );
}
