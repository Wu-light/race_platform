import Link from "next/link";
import { ArrowRight, ExternalLink, Trophy } from "lucide-react";
import type { PublicWorkSummary } from "@/types/public";

export function WorkCard({ work, featured = false }: { work: PublicWorkSummary; featured?: boolean }) {
  return (
    <article className="group ary-glass relative flex h-full flex-col overflow-hidden rounded-3xl p-6 transition duration-300 hover:-translate-y-1 hover:border-ary-line-strong">
      <div className="absolute inset-x-0 top-0 h-1 bg-gradient-to-r from-ary-blue-800 via-ary-blue-500 to-ary-cyan opacity-80" />
      <div className="flex items-center justify-between gap-3 text-xs font-bold uppercase tracking-[0.14em] text-ary-blue-700">
        <span>{featured ? "Featured Work" : work.race.title}</span>
        {work.awards.length > 0 && <Trophy className="h-4 w-4" aria-label="获奖作品" />}
      </div>
      <h3 className="mt-5 text-xl font-black tracking-tight text-ary-blue-950">
        <Link href={`/works/${work.slug}`} className="hover:text-ary-blue-700">
          {work.title}
        </Link>
      </h3>
      <p className="mt-2 text-sm font-semibold text-ary-blue-700">
        {work.author.name}
        {work.author.affiliation ? ` · ${work.author.affiliation}` : ""}
      </p>
      <p className="mt-4 line-clamp-3 flex-1 text-sm leading-6 text-ary-muted">{work.description}</p>
      {work.awards.length > 0 && (
        <div className="mt-4 flex flex-wrap gap-2">
          {work.awards.slice(0, 2).map((award) => (
            <span key={award} className="rounded-full bg-amber-50 px-2.5 py-1 text-xs font-semibold text-amber-700">
              {award}
            </span>
          ))}
        </div>
      )}
      <div className="mt-5 flex items-center gap-4 border-t border-ary-line pt-4 text-sm font-bold">
        <Link href={`/works/${work.slug}`} className="inline-flex items-center gap-1.5 text-ary-blue-800 hover:text-ary-blue-500">
          查看作品 <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" aria-hidden="true" />
        </Link>
        {work.demoUrl && (
          <a href={work.demoUrl} target="_blank" rel="noreferrer" className="ml-auto inline-flex items-center gap-1.5 text-ary-muted hover:text-ary-blue-700">
            Demo <ExternalLink className="h-3.5 w-3.5" aria-hidden="true" />
          </a>
        )}
      </div>
    </article>
  );
}
