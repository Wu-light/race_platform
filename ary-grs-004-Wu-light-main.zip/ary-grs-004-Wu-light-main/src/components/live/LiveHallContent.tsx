"use client";

import { useEffect, useState, useCallback, useRef } from "react";
import Link from "next/link";
import type { PublicLiveHallData } from "@/types/public";
import {
  AlertTriangle,
  ArrowRight,
  Clock3,
  Flag,
  Gauge,
  MonitorUp,
  Radio,
  RefreshCw,
  Sparkles,
} from "lucide-react";
import { LiveRefreshControl } from "@/components/live/LiveRefreshControl";
import { ActionLink } from "@/components/ui/ActionLink";
import { EmptyState } from "@/components/ui/EmptyState";
import { MetricCard } from "@/components/ui/MetricCard";
import { SectionHeading } from "@/components/ui/SectionHeading";
import { StatusBadge } from "@/components/ui/StatusBadge";
import { RaceLifecycle } from "@/components/race/RaceLifecycle";
import { formatDateTime } from "@/lib/utils";

const riskLabels = { low: "低风险", medium: "需关注", high: "高风险" } as const;
const riskStyles = {
  low: "bg-emerald-50 text-emerald-700",
  medium: "bg-amber-50 text-amber-700",
  high: "bg-rose-50 text-rose-700",
} as const;

function compactNumber(value: number | null) {
  if (value === null) return "—";
  return new Intl.NumberFormat("zh-CN", {
    notation: "compact",
    maximumFractionDigits: 1,
  }).format(value);
}

interface Props {
  slug: string;
  initialData: PublicLiveHallData;
}

export function LiveHallContent({ slug, initialData }: Props) {
  const [data, setData] = useState<PublicLiveHallData>(initialData);
  const [pending, setPending] = useState(false);
  const [autoRefresh, setAutoRefresh] = useState(true);
  const [lastRefresh, setLastRefresh] = useState<Date>(new Date());
  const [countdown, setCountdown] = useState(5);

  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const countdownRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const fetchData = useCallback(async () => {
    try {
      setPending(true);
      const res = await fetch(`/api/live/${slug}`);
      if (res.ok) {
        const fresh = await res.json();
        setData(fresh);
        setLastRefresh(new Date());
      }
    } catch {
      // 静默失败，保留上次成功数据
    } finally {
      setPending(false);
    }
  }, [slug]);

  useEffect(() => {
    if (!autoRefresh) {
      if (intervalRef.current) clearInterval(intervalRef.current);
      if (countdownRef.current) clearInterval(countdownRef.current);
      return;
    }
    setCountdown(5);
    countdownRef.current = setInterval(() => {
      setCountdown((prev) => (prev <= 1 ? 5 : prev - 1));
    }, 1000);
    intervalRef.current = setInterval(fetchData, 5000);
    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
      if (countdownRef.current) clearInterval(countdownRef.current);
    };
  }, [autoRefresh, fetchData]);

  const { race } = data;

  return (
    <>
      {/* 控制栏 */}
      <div className="flex flex-wrap items-center gap-3">
        <button
          type="button"
          disabled={pending}
          onClick={fetchData}
          className="inline-flex min-h-11 items-center justify-center gap-2 rounded-xl border border-ary-line bg-white/80 px-4 py-2.5 text-sm font-black text-ary-blue-800 transition hover:border-ary-line-strong hover:bg-white disabled:cursor-wait disabled:opacity-60"
        >
          <RefreshCw
            className={`h-4 w-4 ${pending ? "animate-spin" : ""}`}
          />
          {pending ? "刷新中..." : "手动刷新"}
        </button>

        <button
          type="button"
          onClick={() => setAutoRefresh((prev) => !prev)}
          className={`inline-flex min-h-11 items-center justify-center gap-2 rounded-xl border px-4 py-2.5 text-sm font-black transition ${
            autoRefresh
              ? "border-ary-cyan bg-ary-blue-50 text-ary-blue-800"
              : "border-ary-line bg-white/80 text-ary-muted"
          }`}
        >
          <span
            className={`grid h-5 w-5 place-items-center rounded-full text-xs ${
              autoRefresh ? "bg-ary-cyan text-white" : "bg-gray-200 text-gray-500"
            }`}
          >
            {autoRefresh ? countdown : "—"}
          </span>
          自动刷新{autoRefresh ? "中" : "已暂停"}
        </button>

        <span className="text-xs text-ary-muted">
          上次刷新: {lastRefresh.toLocaleTimeString("zh-CN")}
        </span>
      </div>

      {data.projectionUpdatedAt && (
        <p className="mt-2 text-xs text-ary-muted">
          Projection 更新时间:{" "}
          {new Date(data.projectionUpdatedAt).toLocaleString("zh-CN")}
        </p>
      )}

      {/* Public Projection 横幅 */}
      <section className="border-b border-ary-line bg-ary-blue-950 py-3 text-white">
        <div className="ary-content flex flex-col gap-2 text-sm sm:flex-row sm:items-center sm:justify-between">
          <span className="inline-flex items-center gap-2 font-bold">
            <Sparkles className="h-4 w-4 text-ary-cyan" />
            赛况为最近一次公开投影快照
          </span>
          <span className="text-white/60">
            最终结果以已发布 Results / Review 为准
          </span>
        </div>
      </section>

      {/* 阶段进度 */}
      <section className="ary-section ary-content">
        <SectionHeading
          eyebrow="01 · Stage Progress"
          title="当前阶段：Agent Riding"
          description="赛事状态由 Race 事实驱动，赛程日期和 Projection 只负责解释当前现场。"
        />
        <RaceLifecycle status={race.status} />
        <div
          className="ary-track mt-10 min-h-[250px] sm:min-h-[310px]"
          aria-label={`过程榜当前包含 ${data.leaderboard.length} 位 Rider`}
        >
          <div className="absolute left-5 top-5 rounded-2xl border border-ary-line bg-white/90 px-4 py-3 shadow-sm">
            <p className="text-[10px] font-black uppercase tracking-[0.15em] text-ary-blue-600">
              Riding Signal
            </p>
            <p className="mt-1 text-3xl font-black italic text-ary-blue-950">
              {race.metrics.averageProgress === null
                ? "LIVE"
                : `${race.metrics.averageProgress}%`}
            </p>
          </div>
          {data.leaderboard.slice(0, 4).map((entry, index) => (
            <span
              key={entry.riderName}
              className={`ary-rider-marker ${index === 1 ? "bg-ary-cyan" : index === 2 ? "bg-amber-400" : index === 3 ? "bg-rose-400" : ""}`}
              data-label={entry.riderName}
              style={{
                left: `${18 + index * 21}%`,
                top: `${68 - (index % 2) * 18}%`,
              }}
            />
          ))}
          <div className="absolute bottom-5 right-5 rounded-xl bg-ary-blue-800 px-4 py-2 text-xs font-black text-white shadow-lg">
            {race.metrics.sessionsStarted === null
              ? "等待 Projection"
              : `${race.metrics.sessionsStarted} Sessions started`}
          </div>
        </div>
      </section>

      {/* 指标卡片 */}
      <section className="ary-section border-y border-ary-line/70 bg-white/35">
        <div className="ary-content">
          <SectionHeading
            eyebrow="02 · Live Metrics"
            title="公开赛况指标"
            description={'动态字段缺失时显示"—"，不会将未同步误报为零。'}
          />
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
            <MetricCard label="Riders" value={race.metrics.riders} hint="approved" />
            <MetricCard label="Active" value={race.metrics.activeRiders ?? "—"} hint="Projection" />
            <MetricCard label="Sessions" value={race.metrics.sessionsStarted ?? "—"} hint="started" />
            <MetricCard label="Works" value={race.metrics.submittedWorks} hint="submitted" />
            <MetricCard label="Progress" value={race.metrics.averageProgress === null ? "—" : `${race.metrics.averageProgress}%`} hint="average" />
            <MetricCard label="Tokens" value={compactNumber(race.metrics.totalTokens)} hint="Projection" />
            <MetricCard label="Cost" value={race.metrics.totalCost === null ? "—" : `$${race.metrics.totalCost}`} hint="Projection" />
            <MetricCard label="Risk" value={race.metrics.highRiskRiders ?? "—"} hint="high signals" />
          </div>
        </div>
      </section>

      {/* 过程榜 + 现场观察 */}
      <section className="ary-section ary-content">
        <div className="grid gap-6 xl:grid-cols-[minmax(0,1.2fr)_minmax(320px,0.8fr)]">
          <div>
            <SectionHeading
              eyebrow="03 · Current Leaderboard"
              title="当前过程榜"
              description="按 Projection 中的进度顺序展示，只用于观看进行中的 Race。"
            />
            {data.leaderboard.length > 0 ? (
              <ol className="space-y-3">
                {data.leaderboard.map((entry) => (
                  <li
                    key={entry.riderName}
                    className="ary-glass grid gap-4 rounded-3xl p-5 sm:grid-cols-[52px_minmax(0,1fr)_100px_100px] sm:items-center"
                  >
                    <span className="grid h-11 w-11 place-items-center rounded-2xl bg-ary-blue-100 font-black text-ary-blue-800">
                      #{entry.rank}
                    </span>
                    <div>
                      <div className="flex flex-wrap items-center justify-between gap-2">
                        <p className="font-black text-ary-blue-950">
                          {entry.riderName}
                        </p>
                        <span
                          className={`rounded-full px-2.5 py-1 text-xs font-bold ${riskStyles[entry.risk]}`}
                        >
                          {riskLabels[entry.risk]}
                        </span>
                      </div>
                      <div className="mt-3 h-2 overflow-hidden rounded-full bg-ary-blue-100">
                        <div
                          className="h-full rounded-full bg-gradient-to-r from-ary-blue-800 to-ary-cyan"
                          style={{ width: `${entry.progress}%` }}
                        />
                      </div>
                    </div>
                    <div className="text-sm">
                      <p className="text-xs font-semibold text-ary-muted">Progress</p>
                      <p className="mt-1 font-black text-ary-blue-950">
                        {entry.progress}%
                      </p>
                    </div>
                    <div className="text-sm">
                      <p className="text-xs font-semibold text-ary-muted">Cost</p>
                      <p className="mt-1 font-black text-ary-blue-950">
                        ${entry.cost}
                      </p>
                    </div>
                  </li>
                ))}
              </ol>
            ) : (
              <EmptyState
                title="过程榜等待同步"
                description="没有通过校验的 current_leaderboard Projection 时，页面不会用报名数据猜测排名。"
              />
            )}
          </div>
          <aside>
            <SectionHeading
              eyebrow="04 · Rider Activity"
              title="现场观察"
              description="从过程榜汇总当前活动，不展示原始 Session 内容。"
            />
            <div className="space-y-3">
              {data.leaderboard.slice(0, 4).map((entry) => (
                <article
                  key={entry.riderName}
                  className="ary-glass rounded-3xl p-5"
                >
                  <div className="flex items-center justify-between gap-3">
                    <div className="flex items-center gap-3">
                      <span className="grid h-10 w-10 place-items-center rounded-2xl bg-ary-blue-100 text-ary-blue-700">
                        <Gauge className="h-5 w-5" />
                      </span>
                      <div>
                        <h3 className="font-black text-ary-blue-950">
                          {entry.riderName}
                        </h3>
                        <p className="text-xs text-ary-muted">
                          当前进度 {entry.progress}%
                        </p>
                      </div>
                    </div>
                    <span
                      className={`rounded-full px-2.5 py-1 text-xs font-bold ${riskStyles[entry.risk]}`}
                    >
                      {riskLabels[entry.risk]}
                    </span>
                  </div>
                </article>
              ))}
            </div>
            {race.metrics.highRiskRiders !== null &&
              race.metrics.highRiskRiders > 0 && (
                <div className="mt-4 rounded-3xl border border-amber-200 bg-amber-50 p-5">
                  <div className="flex items-start gap-3">
                    <AlertTriangle className="mt-0.5 h-5 w-5 shrink-0 text-amber-700" />
                    <div>
                      <h3 className="font-black text-amber-900">风险信号不等于判罚</h3>
                      <p className="mt-2 text-sm leading-6 text-amber-800">
                        当前有 {race.metrics.highRiskRiders} 位 Rider
                        进入关注范围。公开端只展示聚合信号，具体原因留在授权工作台处理。
                      </p>
                    </div>
                  </div>
                </div>
              )}
          </aside>
        </div>
      </section>

      {/* 事件流 */}
      <section className="ary-section border-y border-ary-line/70 bg-white/35">
        <div className="ary-content">
          <SectionHeading
            eyebrow="05 · Event Stream"
            title="最近公开事件"
            description="事件流由公开公告和 Projection 更新时间构成，不读取 CA 消息正文。"
          />
          {data.events.length > 0 ? (
            <div className="relative space-y-4 before:absolute before:bottom-4 before:left-[21px] before:top-4 before:w-px before:bg-ary-line">
              {data.events.map((event) => (
                <article
                  key={event.id}
                  className="relative grid grid-cols-[44px_minmax(0,1fr)] gap-4"
                >
                  <span
                    className={`relative z-10 grid h-11 w-11 place-items-center rounded-2xl ${
                      event.type === "projection"
                        ? "bg-ary-blue-800 text-white"
                        : "bg-white text-ary-blue-700"
                    }`}
                  >
                    {event.type === "projection" ? (
                      <Radio className="h-5 w-5" />
                    ) : (
                      <Flag className="h-5 w-5" />
                    )}
                  </span>
                  <div className="ary-glass rounded-3xl p-5">
                    <div className="flex flex-col gap-1 sm:flex-row sm:items-center sm:justify-between">
                      <h3 className="font-black text-ary-blue-950">{event.title}</h3>
                      <time className="text-xs font-semibold text-ary-muted">
                        {formatDateTime(event.occurredAt)}
                      </time>
                    </div>
                    <p className="mt-2 text-sm leading-6 text-ary-muted">
                      {event.description}
                    </p>
                  </div>
                </article>
              ))}
            </div>
          ) : (
            <EmptyState
              title="暂无公开事件"
              description="公告或 Projection 更新后会出现在这里。"
            />
          )}
        </div>
      </section>

      {/* Screen 入口 */}
      <section className="ary-section ary-content">
        <div className="rounded-[32px] bg-gradient-to-br from-ary-blue-950 to-ary-blue-700 p-8 text-white shadow-ary sm:p-10">
          <div className="grid gap-8 lg:grid-cols-[minmax(0,1fr)_auto] lg:items-center">
            <div>
              <MonitorUp className="h-8 w-8 text-ary-cyan" />
              <p className="mt-5 text-xs font-black uppercase tracking-[0.16em] text-white/55">
                Screen Entry
              </p>
              <h2 className="mt-3 text-3xl font-black">
                把当前 Race 带到现场大屏
              </h2>
              <p className="mt-3 max-w-2xl leading-7 text-white/65">
                大屏控制属于授权 Console；公开访客进入后会按现有认证边界处理。
              </p>
            </div>
            <div className="flex flex-col gap-3">
              <ActionLink
                href={`/console/screen?race=${race.slug}`}
                className="bg-white text-ary-blue-900 shadow-none"
              >
                进入大屏控制
              </ActionLink>
              <Link
                href={`/races/${race.slug}`}
                className="inline-flex min-h-11 items-center justify-center gap-2 rounded-xl border border-white/20 px-5 py-2.5 text-sm font-black text-white hover:bg-white/10"
              >
                返回赛事 <ArrowRight className="h-4 w-4" />
              </Link>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
