"use client";

import { useEffect, useState, useCallback, useRef } from "react";
import { RefreshCw } from "lucide-react";
import type {
  PublicLiveHallData,
  PublicLiveLeaderboardEntry,
  PublicLiveEvent,
} from "@/types/public";

interface LiveHallClientProps {
  slug: string;
  initialData: PublicLiveHallData;
}

/**
 * Live Hall 客户端交互层 — 第5棒 T5.3
 *
 * 接收 Server Component 的初始数据，然后每 5 秒自动轮询
 * /api/live/[slug] 获取最新 Projection 数据。
 */
export function LiveHallClient({ slug, initialData }: LiveHallClientProps) {
  const [data, setData] = useState<PublicLiveHallData>(initialData);
  const [autoRefresh, setAutoRefresh] = useState(true);
  const [pending, setPending] = useState(false);
  const [lastRefresh, setLastRefresh] = useState<Date>(new Date());
  const [countdown, setCountdown] = useState(5);
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const countdownRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const fetchData = useCallback(async () => {
    try {
      setPending(true);
      const res = await fetch(`/api/live/${slug}`);
      if (res.ok) {
        const fresh = await res.json();
        setData(fresh);
        setLastRefresh(new Date());
      }
    } catch {
      // 静默失败 — 保留上次成功数据
    } finally {
      setPending(false);
    }
  }, [slug]);

  // 自动轮询
  useEffect(() => {
    if (!autoRefresh) {
      if (intervalRef.current) clearInterval(intervalRef.current);
      if (countdownRef.current) clearInterval(countdownRef.current);
      return;
    }

    setCountdown(5);
    countdownRef.current = setInterval(() => {
      setCountdown((prev) => (prev <= 1 ? 5 : prev - 1));
    }, 1000);

    intervalRef.current = setInterval(fetchData, 5000);

    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
      if (countdownRef.current) clearInterval(countdownRef.current);
    };
  }, [autoRefresh, fetchData]);

  const toggleAutoRefresh = () => setAutoRefresh((prev) => !prev);

  return (
    <>
      {/* 控���栏 */}
      <div className="flex flex-wrap items-center gap-3">
        <button
          type="button"
          disabled={pending}
          onClick={fetchData}
          className="inline-flex min-h-11 items-center justify-center gap-2 rounded-xl border border-ary-line bg-white/80 px-4 py-2.5 text-sm font-black text-ary-blue-800 transition hover:border-ary-line-strong hover:bg-white disabled:cursor-wait disabled:opacity-60"
        >
          <RefreshCw
            className={`h-4 w-4 ${pending ? "animate-spin" : ""}`}
            aria-hidden="true"
          />
          {pending ? "刷新中..." : "手动刷新"}
        </button>

        <button
          type="button"
          onClick={toggleAutoRefresh}
          className={`inline-flex min-h-11 items-center justify-center gap-2 rounded-xl border px-4 py-2.5 text-sm font-black transition ${
            autoRefresh
              ? "border-ary-cyan bg-ary-blue-50 text-ary-blue-800"
              : "border-ary-line bg-white/80 text-ary-muted"
          }`}
        >
          <span
            className={`grid h-5 w-5 place-items-center rounded-full text-xs ${
              autoRefresh ? "bg-ary-cyan text-white" : "bg-gray-200 text-gray-500"
            }`}
          >
            {autoRefresh ? countdown : "—"}
          </span>
          自动刷新{autoRefresh ? "中" : "已暂停"}
        </button>

        <span className="text-xs text-ary-muted">
          上次刷新: {lastRefresh.toLocaleTimeString("zh-CN")}
        </span>
      </div>

      {/* 数据更新指示器 */}
      {data.projectionUpdatedAt && (
        <p className="mt-2 text-xs text-ary-muted">
          Projection 更新时间:{" "}
          {new Date(data.projectionUpdatedAt).toLocaleString("zh-CN")}
        </p>
      )}
    </>
  );
}

// 重新导出类型以便 page.tsx 使用
export type { PublicLiveHallData, PublicLiveLeaderboardEntry, PublicLiveEvent };
