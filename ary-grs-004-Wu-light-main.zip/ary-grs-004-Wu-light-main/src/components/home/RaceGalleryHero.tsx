"use client";

import Link from "next/link";
import {
  ArrowRight,
  ChevronRight,
  Clock3,
  Flag,
  Gauge,
  Pause,
  Play,
  Trophy,
  Users,
  X,
} from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { createPortal } from "react-dom";
import { StatusBadge } from "@/components/ui/StatusBadge";
import { getRacePrimaryAction, getRaceSecondaryAction } from "@/lib/race-utils";
import type { HomeGalleryData } from "@/types/public";

function metric(value: number | null, suffix = "") {
  return value === null ? "未同步" : `${value}${suffix}`;
}

function shortDate(value?: string) {
  if (!value) return "时间待公布";
  return new Intl.DateTimeFormat("zh-CN", {
    month: "short",
    day: "numeric",
    timeZone: "Asia/Shanghai",
  }).format(new Date(value));
}

function RaceUpdatesDrawer({
  open,
  onOpen,
  onClose,
  data,
}: {
  open: boolean;
  onOpen: () => void;
  onClose: () => void;
  data: HomeGalleryData;
}) {
  const desktopTriggerRef = useRef<HTMLButtonElement>(null);
  const mobileTriggerRef = useRef<HTMLButtonElement>(null);
  const lastTriggerRef = useRef<HTMLButtonElement | null>(null);
  const panelRef = useRef<HTMLDivElement>(null);

  function openDrawer(event: React.MouseEvent<HTMLButtonElement>) {
    lastTriggerRef.current = event.currentTarget;
    onOpen();
  }

  function closeDrawer() {
    onClose();
    window.requestAnimationFrame(() => lastTriggerRef.current?.focus());
  }

  useEffect(() => {
    if (!open) return;
    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    panelRef.current?.querySelector<HTMLElement>("button, a")?.focus();

    function onKeyDown(event: KeyboardEvent) {
      if (event.key === "Escape") {
        closeDrawer();
        return;
      }
      if (event.key !== "Tab" || !panelRef.current) return;
      const focusable = Array.from(
        panelRef.current.querySelectorAll<HTMLElement>("button, a"),
      );
      if (focusable.length === 0) return;
      const first = focusable[0];
      const last = focusable[focusable.length - 1];
      if (event.shiftKey && document.activeElement === first) {
        event.preventDefault();
        last.focus();
      } else if (!event.shiftKey && document.activeElement === last) {
        event.preventDefault();
        first.focus();
      }
    }

    document.addEventListener("keydown", onKeyDown);
    return () => {
      document.body.style.overflow = previousOverflow;
      document.removeEventListener("keydown", onKeyDown);
    };
  }, [open]);

  return (
    <>
      <button
        ref={desktopTriggerRef}
        type="button"
        aria-expanded={open}
        aria-controls="race-updates-drawer"
        onClick={openDrawer}
        className="group absolute right-0 top-24 z-20 hidden min-h-12 items-center gap-3 rounded-l-2xl border border-r-0 border-ary-line bg-white/90 px-3 py-4 text-ary-blue-900 shadow-ary backdrop-blur lg:flex"
      >
        <span className="[writing-mode:vertical-rl] text-[11px] font-black uppercase tracking-[0.18em]">
          Race Updates
        </span>
        <span className="grid h-7 w-7 place-items-center rounded-full bg-ary-blue-100 text-xs font-black text-ary-blue-700">
          {data.openRaces.length + data.latestResults.length + data.pastRaces.length}
        </span>
        <ChevronRight className="h-4 w-4 transition-transform group-hover:translate-x-0.5" aria-hidden="true" />
      </button>

      <button
        ref={mobileTriggerRef}
        type="button"
        aria-expanded={open}
        aria-controls="race-updates-drawer"
        onClick={openDrawer}
        className="absolute right-5 top-24 z-20 inline-flex min-h-11 items-center gap-2 rounded-xl border border-ary-line bg-white/90 px-3 py-2 text-xs font-black text-ary-blue-800 shadow-sm lg:hidden"
      >
        Race Updates
        <span className="grid h-6 w-6 place-items-center rounded-full bg-ary-blue-100">
          {data.openRaces.length + data.latestResults.length + data.pastRaces.length}
        </span>
      </button>

      {open && typeof document !== "undefined" && createPortal(
        <div className="fixed inset-0 z-[60] bg-ary-blue-950/25 backdrop-blur-sm" onMouseDown={closeDrawer}>
          <aside
            ref={panelRef}
            id="race-updates-drawer"
            role="dialog"
            aria-modal="true"
            aria-labelledby="race-updates-title"
            className="ml-auto h-full w-full max-w-md overflow-y-auto border-l border-ary-line bg-[#f7fbff] p-5 shadow-2xl sm:p-7"
            onMouseDown={(event) => event.stopPropagation()}
          >
            <div className="flex items-center justify-between border-b border-ary-line pb-5">
              <div>
                <p className="text-xs font-bold uppercase tracking-[0.18em] text-ary-blue-500">Live Gallery</p>
                <h2 id="race-updates-title" className="mt-1 text-2xl font-black text-ary-blue-950">
                  Race Updates
                </h2>
              </div>
              <button
                type="button"
                aria-label="关闭 Race Updates"
                onClick={closeDrawer}
                className="grid h-11 w-11 place-items-center rounded-xl border border-ary-line bg-white text-ary-blue-900 hover:bg-ary-blue-100"
              >
                <X className="h-5 w-5" aria-hidden="true" />
              </button>
            </div>

            <div className="mt-6 space-y-4">
              <section className="rounded-3xl border border-ary-line bg-white p-5 shadow-sm">
                <div className="flex items-center justify-between gap-3">
                  <p className="text-xs font-black uppercase tracking-[0.14em] text-ary-blue-700">Open Registration</p>
                  <span className="rounded-full bg-emerald-50 px-2.5 py-1 text-xs font-bold text-emerald-700">Open</span>
                </div>
                {data.openRaces[0] ? (
                  <>
                    <h3 className="mt-4 text-xl font-black text-ary-blue-950">{data.openRaces[0].title}</h3>
                    <p className="mt-2 text-sm leading-6 text-ary-muted">{data.openRaces[0].challenge}</p>
                    <Link
                      href={`/races/${data.openRaces[0].slug}`}
                      className="mt-4 inline-flex min-h-11 items-center gap-2 rounded-xl bg-ary-blue-800 px-4 py-2 text-sm font-bold text-white"
                    >
                      查看报名赛道 <ArrowRight className="h-4 w-4" aria-hidden="true" />
                    </Link>
                  </>
                ) : (
                  <p className="mt-3 text-sm text-ary-muted">当前没有开放报名的赛道。</p>
                )}
              </section>

              <section className="rounded-3xl border border-ary-line bg-white p-5 shadow-sm">
                <div className="flex items-center gap-2 text-xs font-black uppercase tracking-[0.14em] text-ary-blue-700">
                  <Trophy className="h-4 w-4" aria-hidden="true" /> Latest Results
                </div>
                <div className="mt-3 divide-y divide-ary-line">
                  {data.latestResults.map((result) => (
                    <Link key={result.race.id} href={`/races/${result.race.slug}/results`} className="flex min-h-14 items-center justify-between gap-4 py-3 text-sm hover:text-ary-blue-700">
                      <span className="font-bold text-ary-blue-950">{result.race.title}</span>
                      <span className="shrink-0 text-xs font-semibold text-ary-muted">{result.topAward?.name || "赛果已发布"}</span>
                    </Link>
                  ))}
                  {data.latestResults.length === 0 && <p className="py-3 text-sm text-ary-muted">赛果仍在冲线中。</p>}
                </div>
              </section>

              <section className="rounded-3xl border border-ary-line bg-white p-5 shadow-sm">
                <p className="text-xs font-black uppercase tracking-[0.14em] text-ary-blue-700">Past Races</p>
                <div className="mt-3 divide-y divide-ary-line">
                  {data.pastRaces.map((race) => (
                    <Link key={race.id} href={`/races/${race.slug}`} className="flex min-h-12 items-center justify-between gap-4 py-3 text-sm">
                      <span className="font-bold text-ary-blue-950">{race.title}</span>
                      <ArrowRight className="h-4 w-4 text-ary-blue-500" aria-hidden="true" />
                    </Link>
                  ))}
                  {data.pastRaces.length === 0 && <p className="py-3 text-sm text-ary-muted">更多往届赛事即将归档。</p>}
                </div>
              </section>

              <Link href="/cooperation" className="flex min-h-16 items-center justify-between rounded-3xl bg-gradient-to-br from-ary-blue-950 to-ary-blue-700 px-5 py-4 text-white shadow-ary">
                <span>
                  <span className="block text-xs font-bold uppercase tracking-[0.14em] text-white/60">Cooperation</span>
                  <span className="mt-1 block font-black">报名、办赛或成为合作伙伴</span>
                </span>
                <ArrowRight className="h-5 w-5" aria-hidden="true" />
              </Link>
            </div>
          </aside>
        </div>,
        document.body,
      )}
    </>
  );
}

export function RaceGalleryHero({ data }: { data: HomeGalleryData }) {
  const [activeIndex, setActiveIndex] = useState(0);
  const [paused, setPaused] = useState(false);
  const [drawerOpen, setDrawerOpen] = useState(false);
  const features = data.featuredRaces;
  const feature = features[activeIndex] ?? features[0];

  useEffect(() => {
    if (features.length < 2 || paused || drawerOpen) return;
    const media = window.matchMedia("(prefers-reduced-motion: reduce)");
    if (media.matches) return;
    const timer = window.setInterval(
      () => setActiveIndex((index) => (index + 1) % features.length),
      7000,
    );
    return () => window.clearInterval(timer);
  }, [drawerOpen, features.length, paused]);

  if (!feature) {
    return (
      <section className="ary-content flex min-h-[70vh] items-center pt-28">
        <div className="max-w-3xl py-20">
          <p className="text-sm font-bold uppercase tracking-[0.2em] text-ary-blue-700">Agent Racing Yard</p>
          <h1 className="mt-4 text-5xl font-black text-ary-blue-950">下一场 Race 正在准备</h1>
          <p className="mt-5 text-lg text-ary-muted">赛事公开后，会在这里出现赛题、实况、作品和赛果。</p>
          <Link href="/cooperation" className="mt-8 inline-flex min-h-11 items-center rounded-xl bg-ary-blue-800 px-5 py-2.5 font-bold text-white">了解如何参赛</Link>
        </div>
      </section>
    );
  }

  const { race, work, rider } = feature;
  const primaryAction = getRacePrimaryAction(race);
  const secondaryAction = getRaceSecondaryAction(race);
  const progress = race.metrics.averageProgress ?? 0;

  function selectRace(index: number) {
    setActiveIndex(index);
    setPaused(true);
  }

  function onSwitcherKeyDown(event: React.KeyboardEvent<HTMLButtonElement>, index: number) {
    let next = index;
    if (event.key === "ArrowRight") next = (index + 1) % features.length;
    else if (event.key === "ArrowLeft") next = (index - 1 + features.length) % features.length;
    else if (event.key === "Home") next = 0;
    else if (event.key === "End") next = features.length - 1;
    else return;
    event.preventDefault();
    selectRace(next);
    document.getElementById(`race-switch-${next}`)?.focus();
  }

  return (
    <section
      className="relative z-10 min-h-[900px] overflow-hidden pt-[72px] lg:min-h-[940px]"
      aria-labelledby="featured-race-title"
      onMouseEnter={() => setPaused(true)}
      onMouseLeave={() => setPaused(false)}
    >
      <div className="ary-content pb-14 pt-16 sm:pt-20 lg:pt-24">
        <div className="mx-auto max-w-4xl text-center">
          <div className="flex flex-wrap items-center justify-center gap-3">
            <StatusBadge status={race.status} />
            <span className="text-xs font-bold uppercase tracking-[0.16em] text-ary-muted">
              {shortDate(race.schedule.raceStart)} · {race.subtitle || "Agent Racing"}
            </span>
          </div>
          <h1
            id="featured-race-title"
            className="mt-5 bg-gradient-to-b from-ary-blue-950 via-ary-blue-700 to-ary-blue-500 bg-clip-text text-[clamp(3.25rem,7vw,6.5rem)] font-black italic leading-[0.92] tracking-[-0.055em] text-transparent"
          >
            {race.title}
          </h1>

          {features.length > 1 && (
            <div className="mt-6 flex items-center justify-center gap-1" role="tablist" aria-label="切换主推赛事">
              {features.map((candidate, index) => (
                <button
                  id={`race-switch-${index}`}
                  key={candidate.race.id}
                  type="button"
                  role="tab"
                  aria-selected={index === activeIndex}
                  aria-controls="featured-race-panel"
                  tabIndex={index === activeIndex ? 0 : -1}
                  title={candidate.race.title}
                  onClick={() => selectRace(index)}
                  onKeyDown={(event) => onSwitcherKeyDown(event, index)}
                  className="group grid h-11 place-items-center px-1"
                >
                  <span className={`block h-1 rounded-full transition-all ${index === activeIndex ? "w-20 bg-ary-blue-700" : "w-12 bg-ary-blue-500/30 group-hover:bg-ary-blue-500/60"}`} />
                  <span className="sr-only">{candidate.race.title}</span>
                </button>
              ))}
              <button
                type="button"
                onClick={() => setPaused((value) => !value)}
                aria-label={paused ? "继续自动切换" : "暂停自动切换"}
                className="ml-2 grid h-11 w-11 place-items-center rounded-full text-ary-muted hover:bg-white/70 hover:text-ary-blue-700"
              >
                {paused ? <Play className="h-4 w-4" aria-hidden="true" /> : <Pause className="h-4 w-4" aria-hidden="true" />}
              </button>
            </div>
          )}

          <div id="featured-race-panel" role="tabpanel" className="mt-5" aria-live="polite">
            <p className="mx-auto max-w-3xl text-base font-medium leading-7 text-ary-muted sm:text-lg">
              <span className="font-black text-ary-blue-900">赛题：</span>{race.challenge}
            </p>
            <div className="mt-7 flex flex-wrap justify-center gap-2 sm:gap-3">
              {[
                [Users, race.metrics.riders, "riders"],
                [Gauge, metric(race.metrics.activeRiders), "active"],
                [Flag, race.metrics.submittedWorks, "works"],
                [Clock3, metric(race.metrics.averageProgress, "%"), "progress"],
              ].map(([Icon, value, label]) => {
                const MetricIcon = Icon as typeof Users;
                return (
                  <span key={String(label)} className="inline-flex min-h-12 items-center gap-2 rounded-2xl border border-ary-line bg-white/70 px-4 py-2 text-sm text-ary-muted backdrop-blur">
                    <MetricIcon className="h-4 w-4 text-ary-blue-700" aria-hidden="true" />
                    <b className="text-base text-ary-blue-950">{String(value)}</b> {String(label)}
                  </span>
                );
              })}
            </div>
            <div className="mt-7 flex flex-col justify-center gap-3 sm:flex-row">
              <Link href={primaryAction.href} className="inline-flex min-h-12 items-center justify-center gap-2 rounded-xl bg-gradient-to-br from-ary-blue-800 to-ary-blue-500 px-6 py-3 text-sm font-black text-white shadow-[0_14px_30px_rgba(7,91,236,0.24)] transition hover:-translate-y-0.5">
                {primaryAction.label} <ArrowRight className="h-4 w-4" aria-hidden="true" />
              </Link>
              <Link href={secondaryAction.href} className="inline-flex min-h-12 items-center justify-center rounded-xl border border-ary-line bg-white/80 px-6 py-3 text-sm font-black text-ary-blue-900 backdrop-blur transition hover:-translate-y-0.5 hover:border-ary-line-strong">
                {secondaryAction.label}
              </Link>
            </div>
          </div>
        </div>

        <div className="ary-track mt-12 animate-track-flow motion-reduce:animate-none" aria-hidden="true">
          <div className="absolute left-6 top-6 rounded-xl border border-ary-line bg-white/85 px-4 py-3 shadow-sm backdrop-blur">
            <span className="block text-[10px] font-black uppercase tracking-[0.14em] text-ary-blue-700">Riding Signal</span>
            <b className="mt-1 block text-2xl font-black italic text-ary-blue-900">{progress || "LIVE"}{progress ? "%" : ""}</b>
          </div>
          <span className="ary-rider-marker animate-marker-pulse motion-reduce:animate-none" data-label={rider?.name || "Rider 01"} style={{ left: "19%", top: "68%" }} />
          <span className="ary-rider-marker animate-marker-pulse bg-ary-cyan motion-reduce:animate-none" data-label="Rider 02" style={{ left: "49%", top: "52%", animationDelay: "0.5s" }} />
          <span className="ary-rider-marker animate-marker-pulse bg-amber-400 motion-reduce:animate-none" data-label="Rider 03" style={{ left: "78%", top: "62%", animationDelay: "1s" }} />
          <span className="absolute bottom-6 right-6 rounded-xl bg-ary-blue-800 px-3 py-2 text-xs font-black text-white shadow-lg">
            Projection · {race.metrics.sessionsStarted === null ? "等待同步" : `${race.metrics.sessionsStarted} sessions`}
          </span>
        </div>

        <div className="relative mx-auto -mt-7 grid max-w-5xl gap-4 px-4 sm:grid-cols-2">
          <article className="ary-glass rounded-3xl p-5 sm:p-6">
            <p className="text-xs font-black uppercase tracking-[0.15em] text-ary-blue-500">Featured Work</p>
            {work ? (
              <div className="mt-3 flex items-end justify-between gap-5">
                <div>
                  <h2 className="text-xl font-black text-ary-blue-950">{work.title}</h2>
                  <p className="mt-1 line-clamp-2 text-sm leading-6 text-ary-muted">{work.description}</p>
                </div>
                <Link href={`/works/${work.slug}`} className="grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-ary-blue-100 text-ary-blue-700" aria-label={`查看作品 ${work.title}`}>
                  <ArrowRight className="h-4 w-4" aria-hidden="true" />
                </Link>
              </div>
            ) : <p className="mt-3 text-sm text-ary-muted">公开作品即将上墙。</p>}
          </article>
          <article className="ary-glass rounded-3xl p-5 sm:p-6">
            <p className="text-xs font-black uppercase tracking-[0.15em] text-ary-blue-500">Featured Rider</p>
            {rider ? (
              <div className="mt-3">
                <h2 className="text-xl font-black text-ary-blue-950">{rider.name}</h2>
                <p className="mt-1 text-sm text-ary-muted">{rider.affiliation || "独立开发者"} · {rider.representativeWork}</p>
                <div className="mt-3 flex flex-wrap gap-2">
                  {rider.skillTags.map((tag) => <span key={tag} className="rounded-full bg-ary-blue-100 px-2.5 py-1 text-xs font-semibold text-ary-blue-800">{tag}</span>)}
                </div>
              </div>
            ) : <p className="mt-3 text-sm text-ary-muted">骑手能力档案正在形成。</p>}
          </article>
        </div>
      </div>

      <RaceUpdatesDrawer
        open={drawerOpen}
        onOpen={() => { setDrawerOpen(true); setPaused(true); }}
        onClose={() => setDrawerOpen(false)}
        data={data}
      />
    </section>
  );
}
