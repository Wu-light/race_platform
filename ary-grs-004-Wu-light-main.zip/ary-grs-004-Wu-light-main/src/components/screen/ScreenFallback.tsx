"use client";

import {
  AlertTriangle,
  Wifi,
  WifiOff,
  Database,
  FileWarning,
  Users,
  Radio,
  ServerCrash,
  HelpCircle,
} from "lucide-react";

export type FallbackType =
  | "no-data"           // Projection 尚未生成
  | "disconnected"      // 客户端网络断开
  | "error"             // 通用加载异常
  | "no-projection"     // 指定类型的 Projection 缺失
  | "empty-rankings"    // 榜单存在但 ranking 为空（无 approved rider）
  | "no-announcements"  // 赛事无公告
  | "corrupted-json"    // Projection JSON 解析失败
  | "no-ca-connections" // 所有 CA 连接未配置或已禁用
  | "partial-failure"   // 部分 Projection 重建成功、部分失败
  | "race-not-running"; // 赛事不在进行中（Live Hall 特有）

interface ScreenFallbackProps {
  type?: FallbackType;
  message?: string;
  /** 部分失败时列出失败的类型名 */
  failedTypes?: string[];
  raceSlug?: string;
}

const FALLBACK_CONFIG: Record<
  FallbackType,
  { icon: typeof AlertTriangle; title: string; color: string }
> = {
  "no-data": {
    icon: Database,
    title: "等待数据同步",
    color: "text-ary-cyan",
  },
  disconnected: {
    icon: WifiOff,
    title: "网络连接中断",
    color: "text-amber-400",
  },
  error: {
    icon: AlertTriangle,
    title: "加载异常",
    color: "text-red-400",
  },
  "no-projection": {
    icon: FileWarning,
    title: "Projection 数据缺失",
    color: "text-amber-400",
  },
  "empty-rankings": {
    icon: Users,
    title: "暂无参赛选手",
    color: "text-white/30",
  },
  "no-announcements": {
    icon: Radio,
    title: "暂无公告",
    color: "text-white/30",
  },
  "corrupted-json": {
    icon: FileWarning,
    title: "Projection 数据格式异常",
    color: "text-red-400",
  },
  "no-ca-connections": {
    icon: Radio,
    title: "CA 连接未配置",
    color: "text-amber-400",
  },
  "partial-failure": {
    icon: ServerCrash,
    title: "部分 Projection 重建失败",
    color: "text-amber-400",
  },
  "race-not-running": {
    icon: HelpCircle,
    title: "赛事未在进行中",
    color: "text-white/30",
  },
};

/**
 * 大屏 Fallback 组件
 *
 * 覆盖全部 10 种错误/边界状态。
 * 1920×1080：垂直居中，图标 80px，标题 36px，正文 24px。
 */
export function ScreenFallback({
  type = "no-data",
  message,
  failedTypes,
  raceSlug,
}: ScreenFallbackProps) {
  const config = FALLBACK_CONFIG[type];
  const Icon = config.icon;

  // 默认消息
  const defaultMessage: Record<FallbackType, string> = {
    "no-data":
      "Projection 数据尚未生成。请通知主办方在 Admin Console 中触发 Projection 重建。",
    disconnected:
      "大屏与服务器连接中断。请检查现场网络后刷新页面。",
    error:
      "大屏加载时发生异常。请刷新页面重试，或联系技术支持。",
    "no-projection":
      "当前展示模式需要的 Projection 数据不存在。请切换其他模式，或触发 Projection 重建。",
    "empty-rankings":
      "该赛事暂无已批准的参赛选手，或选手尚未开始骑行。请确认报名审核和 CA 接入状态。",
    "no-announcements":
      "该赛事暂无公开公告。请主办方在 Organizer Console 中发布公告。",
    "corrupted-json":
      "Projection 数据格式异常，无法正确解析。请触发 Projection 重建以修复。",
    "no-ca-connections":
      "当前赛事没有已配置且活跃的 CA 连接。请选手在 Rider Console 中完成 CA Setup。",
    "partial-failure":
      failedTypes && failedTypes.length > 0
        ? `以下 Projection 类型重建失败: ${failedTypes.join("、")}。其他类型已成功更新。`
        : "部分 Projection 类型重建失败。请检查服务端日志后重试。",
    "race-not-running":
      "该赛事当前不在进行中状态，Live Hall 仅对 running 状态的赛事开放。",
  };

  return (
    <div className="flex h-full items-center justify-center overflow-hidden bg-ary-blue-950">
      <div className="max-w-3xl px-20 text-center">
        {/* 图标 */}
        <Icon className={`mx-auto h-20 w-20 ${config.color}`} />

        {/* 标题 */}
        <h2 className="mt-8 text-[36px] font-black text-white">
          {config.title}
        </h2>

        {/* 描述 */}
        <p className="mt-5 text-2xl leading-relaxed text-white/40">
          {message || defaultMessage[type]}
        </p>

        {/* 部分失败列表 */}
        {type === "partial-failure" && failedTypes && failedTypes.length > 0 && (
          <div className="mt-8 space-y-2">
            {failedTypes.map((t) => (
              <div
                key={t}
                className="rounded-xl border border-red-500/20 bg-red-500/5 px-5 py-3"
              >
                <p className="text-xl font-bold text-red-400">
                  ✕ {t} — 重建失败
                </p>
              </div>
            ))}
          </div>
        )}

        {/* 操作提示 */}
        <div className="mt-12 space-y-3 text-xl text-white/25">
          {type === "disconnected" && (
            <p className="animate-pulse text-amber-400/60">
              正在尝试重新连接...
            </p>
          )}
          {raceSlug && (
            <p>
              赛事: {raceSlug} ·{" "}
              <button
                onClick={() => window.location.reload()}
                className="underline hover:text-white/50"
              >
                刷新页面
              </button>
            </p>
          )}
        </div>

        {/* 页脚 */}
        <p className="mt-16 text-lg font-semibold uppercase tracking-[0.2em] text-white/15">
          Agent Racing Yard · Screen Display
        </p>
      </div>
    </div>
  );
}
