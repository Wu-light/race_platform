import type { ScreenData } from "@/lib/screen-data";

interface Props {
  data: ScreenData;
}

/**
 * Billboard 信息看板模式
 *
 * 1920×1080：左侧榜单（flex-[2]）+ 右侧公告/状态（flex-1）
 * 最小字号 24px，榜单行高紧凑以容纳 4 条不溢出。
 */
export function ScreenBillboard({ data }: Props) {
  const leaderboard = data.projections.current_leaderboard as {
    rankings?: { riderName: string; progress: number; cost: number; risk: string }[];
  } | null;
  const rankings = leaderboard?.rankings ?? [];

  return (
    <div className="flex h-full overflow-hidden bg-ary-blue-950 text-white">
      {/* 左侧榜单 */}
      <div className="flex-[2] flex flex-col border-r border-white/10 px-14 py-10">
        <p className="text-2xl font-black uppercase tracking-[0.18em] text-ary-cyan">
          Current Leaderboard
        </p>
        <h1 className="mt-2 text-[42px] font-black leading-tight line-clamp-2">
          {data.race.title}
        </h1>

        {rankings.length > 0 ? (
          <div className="mt-8 flex-1 space-y-3 overflow-hidden">
            {rankings.map((entry, i) => (
              <div
                key={entry.riderName}
                className="flex items-center gap-5 rounded-2xl border border-white/10 bg-white/5 px-6 py-4"
              >
                <span className="grid h-14 w-14 shrink-0 place-items-center rounded-xl bg-ary-blue-800 text-[28px] font-black">
                  #{i + 1}
                </span>
                <div className="flex-1 min-w-0">
                  <p className="text-[26px] font-black truncate">{entry.riderName}</p>
                  <div className="mt-2 h-3 overflow-hidden rounded-full bg-white/10">
                    <div
                      className="h-full rounded-full bg-gradient-to-r from-ary-cyan to-ary-blue-400"
                      style={{ width: `${Math.min(100, entry.progress)}%` }}
                    />
                  </div>
                </div>
                <div className="shrink-0 text-right">
                  <p className="text-[28px] font-black tabular-nums">{Math.round(entry.progress)}%</p>
                  <p className="text-xl text-white/40">${entry.cost}</p>
                </div>
                <RiskBadge risk={entry.risk} />
              </div>
            ))}
          </div>
        ) : (
          <p className="mt-12 text-2xl text-white/30">等待数据同步...</p>
        )}
      </div>

      {/* 右侧公告/状态 */}
      <div className="flex-1 flex flex-col px-12 py-10 overflow-hidden">
        <p className="text-2xl font-black uppercase tracking-[0.15em] text-ary-cyan">
          Announcements
        </p>
        <div className="mt-6 flex-1 space-y-4 overflow-hidden">
          {data.announcements.length > 0 ? (
            data.announcements.slice(0, 4).map((a) => (
              <div
                key={a.id}
                className="rounded-2xl border border-white/10 bg-white/5 px-6 py-5"
              >
                <h3 className="text-2xl font-black line-clamp-1">{a.title}</h3>
                <p className="mt-2 text-xl leading-relaxed text-white/55 line-clamp-2">
                  {a.body}
                </p>
              </div>
            ))
          ) : (
            <p className="text-2xl text-white/30">暂无公告</p>
          )}
        </div>

        <div className="mt-auto rounded-2xl border border-ary-cyan/20 bg-ary-cyan/5 px-6 py-5">
          <p className="text-xl font-bold uppercase tracking-[0.1em] text-ary-cyan">
            Status
          </p>
          <p className="mt-1 text-[28px] font-black">{data.race.status}</p>
        </div>
      </div>
    </div>
  );
}

function RiskBadge({ risk }: { risk: string }) {
  const colors: Record<string, string> = {
    low: "bg-emerald-500/15 text-emerald-400 border-emerald-500/25",
    medium: "bg-amber-500/15 text-amber-400 border-amber-500/25",
    high: "bg-red-500/15 text-red-400 border-red-500/25",
  };
  const labels: Record<string, string> = {
    low: "低风险",
    medium: "关注",
    high: "高风险",
  };
  return (
    <span
      className={`shrink-0 rounded-full border px-5 py-2 text-xl font-bold ${colors[risk] || ""}`}
    >
      {labels[risk] || risk}
    </span>
  );
}
