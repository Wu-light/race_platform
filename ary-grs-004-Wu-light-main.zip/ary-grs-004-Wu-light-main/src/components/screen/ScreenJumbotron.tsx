import type { ScreenData } from "@/lib/screen-data";

interface Props {
  data: ScreenData;
}

/**
 * Jumbotron 巨幕模式 — 大标题 + 关键数字
 *
 * 1920×1080 视口适配：
 *   - 垂直居中，无滚动
 *   - 最小字号 24px，标题 72px，数字 56px
 */
export function ScreenJumbotron({ data }: Props) {
  const progress = data.projections.race_progress as Record<string, number> | null;

  return (
    <div className="flex h-full flex-col items-center justify-center overflow-hidden bg-gradient-to-br from-ary-blue-950 via-ary-blue-900 to-ary-blue-950 px-20 text-center">
      <p className="text-2xl font-black uppercase tracking-[0.3em] text-ary-cyan">
        {data.race.status === "running" ? "LIVE NOW" : data.race.status}
      </p>
      <h1 className="mt-8 max-w-5xl text-[72px] font-black leading-tight text-white">
        {data.race.title}
      </h1>

      <div className="mt-20 grid grid-cols-4 gap-10">
        <MetricBlock label="参赛人数" value={progress?.totalRiders ?? "—"} />
        <MetricBlock label="活跃骑手" value={progress?.activeRiders ?? "—"} />
        <MetricBlock label="平均进度" value={progress?.averageProgress != null ? `${progress.averageProgress}%` : "—"} />
        <MetricBlock label="Token 消耗" value={progress?.totalTokens != null ? `${(progress.totalTokens / 1_000_000).toFixed(1)}M` : "—"} />
      </div>

      <p className="mt-20 text-xl font-semibold uppercase tracking-[0.2em] text-white/25">
        Agent Racing Yard · Screen Display
      </p>
    </div>
  );
}

function MetricBlock({ label, value }: { label: string; value: string | number }) {
  return (
    <div className="rounded-3xl border border-white/10 bg-white/5 px-10 py-8">
      <p className="text-2xl font-bold uppercase tracking-[0.12em] text-ary-cyan">
        {label}
      </p>
      <p className="mt-4 text-[56px] font-black leading-none text-white">
        {value}
      </p>
    </div>
  );
}
