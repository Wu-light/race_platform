"use client";

import { useEffect, useState } from "react";
import type { ScreenData } from "@/lib/screen-data";

interface Props {
  data: ScreenData;
}

/**
 * Announcement 公告展示模式
 *
 * 1920×1080：垂直居中，标题 56px，正文 28px，日期 24px。
 * 每 8 秒自动切换。
 */
export function ScreenAnnouncement({ data }: Props) {
  const [currentIndex, setCurrentIndex] = useState(0);

  useEffect(() => {
    if (data.announcements.length <= 1) return;
    const interval = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % data.announcements.length);
    }, 8000);
    return () => clearInterval(interval);
  }, [data.announcements.length]);

  if (data.announcements.length === 0) {
    return (
      <div className="flex h-full items-center justify-center overflow-hidden bg-ary-blue-950">
        <p className="text-3xl font-black text-white/25">暂无公告</p>
      </div>
    );
  }

  const announcement = data.announcements[currentIndex];

  return (
    <div className="flex h-full flex-col items-center justify-center overflow-hidden bg-gradient-to-br from-ary-blue-950 via-ary-blue-900 to-ary-blue-950 px-20 text-center">
      <p className="text-2xl font-black uppercase tracking-[0.25em] text-ary-cyan">
        Announcement · {currentIndex + 1}/{data.announcements.length}
      </p>

      <div className="mt-14 max-w-4xl">
        <h1 className="text-[56px] font-black leading-tight text-white">
          {announcement.title}
        </h1>
        <p className="mt-10 text-[28px] leading-relaxed text-white/65">
          {announcement.body}
        </p>
        <p className="mt-10 text-2xl text-white/30">
          {new Date(announcement.publishedAt).toLocaleDateString("zh-CN", {
            year: "numeric",
            month: "long",
            day: "numeric",
          })}
        </p>
      </div>

      {/* 进度指示器 */}
      {data.announcements.length > 1 && (
        <div className="mt-16 flex gap-4">
          {data.announcements.map((_, i) => (
            <button
              key={i}
              onClick={() => setCurrentIndex(i)}
              className={`h-3 rounded-full transition-all ${
                i === currentIndex ? "w-14 bg-ary-cyan" : "w-3 bg-white/15"
              }`}
              aria-label={`公告 ${i + 1}`}
            />
          ))}
        </div>
      )}

      <p className="mt-16 text-xl font-semibold uppercase tracking-[0.2em] text-white/25">
        {data.race.title}
      </p>
    </div>
  );
}
