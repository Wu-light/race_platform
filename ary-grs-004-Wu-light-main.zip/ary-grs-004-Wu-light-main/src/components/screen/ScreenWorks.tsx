"use client";

import { useEffect, useState } from "react";
import type { ScreenData } from "@/lib/screen-data";

interface Props {
  data: ScreenData;
}

/** 真实数据为空时的后备占位 */
const FALLBACK_WORKS = [
  {
    title: "等待作品提交...",
    authorName: "—",
    description: "该赛事暂无公开作品。作品提交并发布后将在此展示。",
  },
];

/**
 * Works 作品轮播模式
 *
 * 1920×1080：垂直居中，标题 64px，副标题 28px，正文 24px。
 * 优先使用 data.works（真实数据），为空时显示占位。
 * 每 10 秒自动切换。
 */
export function ScreenWorks({ data }: Props) {
  const [currentIndex, setCurrentIndex] = useState(0);
  const works = data.works.length > 0 ? data.works : FALLBACK_WORKS;

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % works.length);
    }, 10000);
    return () => clearInterval(interval);
  }, [works.length]);

  const work = works[currentIndex];

  return (
    <div className="flex h-full flex-col items-center justify-center overflow-hidden bg-gradient-to-br from-ary-blue-950 via-ary-blue-900 to-ary-blue-950 px-20 text-center">
      <p className="text-2xl font-black uppercase tracking-[0.25em] text-ary-cyan">
        Featured Works · {currentIndex + 1}/{works.length}
      </p>

      <div className="mt-14 max-w-4xl">
        <h1 className="text-[64px] font-black leading-tight text-white">
          {work.title}
        </h1>
        <p className="mt-8 text-[28px] font-bold text-ary-cyan">
          by {work.authorName}
        </p>
        <p className="mt-6 text-2xl leading-relaxed text-white/55">
          {work.description}
        </p>
      </div>

      {/* 进度指示器 */}
      <div className="mt-16 flex gap-4">
        {works.map((_, i) => (
          <button
            key={i}
            onClick={() => setCurrentIndex(i)}
            className={`h-3 rounded-full transition-all ${
              i === currentIndex ? "w-14 bg-ary-cyan" : "w-3 bg-white/15"
            }`}
            aria-label={`作品 ${i + 1}`}
          />
        ))}
      </div>

      <p className="mt-16 text-xl font-semibold uppercase tracking-[0.2em] text-white/25">
        {data.race.title}
      </p>
    </div>
  );
}
