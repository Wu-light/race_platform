import type { ScreenData } from "@/lib/screen-data";

interface Props {
  data: ScreenData;
}

/**
 * Leaderboard 大字体榜单模式
 *
 * 1920×1080：5 列表格，字号 24-32px。
 * 表头 24px，数据行 26-32px，最大容纳 6 行。
 */
export function ScreenLeaderboard({ data }: Props) {
  const leaderboard = data.projections.current_leaderboard as {
    rankings?: { riderName: string; progress: number; cost: number; risk: string }[];
  } | null;
  const rankings = leaderboard?.rankings ?? [];

  return (
    <div className="flex h-full flex-col overflow-hidden bg-ary-blue-950 text-white">
      <div className="shrink-0 px-16 pt-14">
        <p className="text-2xl font-black uppercase tracking-[0.25em] text-ary-cyan">
          Leaderboard
        </p>
        <h1 className="mt-2 text-[52px] font-black leading-tight line-clamp-1">
          {data.race.title}
        </h1>
      </div>

      {rankings.length > 0 ? (
        <div className="flex-1 overflow-hidden px-16 pt-8 pb-14">
          {/* 表头 */}
          <div className="grid grid-cols-[90px_1fr_200px_180px_140px] gap-4 border-b border-white/10 pb-4 text-2xl font-bold uppercase tracking-[0.12em] text-white/35">
            <span>Rank</span>
            <span>Rider</span>
            <span>Progress</span>
            <span>Cost</span>
            <span>Risk</span>
          </div>

          {/* 表体 */}
          <div className="mt-3 flex-1 space-y-3 overflow-hidden">
            {rankings.slice(0, 6).map((entry, i) => (
              <div
                key={entry.riderName}
                className="grid grid-cols-[90px_1fr_200px_180px_140px] items-center gap-4 rounded-2xl border border-white/10 bg-white/5 px-6 py-4"
              >
                <span className="text-[32px] font-black text-ary-cyan tabular-nums">
                  {i + 1}
                </span>
                <span className="text-[28px] font-black truncate">{entry.riderName}</span>
                <span className="text-[28px] font-black tabular-nums">
                  {Math.round(entry.progress)}%
                </span>
                <span className="text-[26px] font-semibold text-white/65 tabular-nums">
                  ${entry.cost}
                </span>
                <span
                  className={`text-2xl font-bold ${
                    entry.risk === "high"
                      ? "text-red-400"
                      : entry.risk === "medium"
                        ? "text-amber-400"
                        : "text-emerald-400"
                  }`}
                >
                  {entry.risk === "high" ? "⚠ HIGH" : entry.risk === "medium" ? "● MED" : "✓ LOW"}
                </span>
              </div>
            ))}
          </div>
        </div>
      ) : (
        <div className="flex flex-1 items-center justify-center">
          <p className="text-3xl font-black text-white/25">等待榜单数据...</p>
        </div>
      )}
    </div>
  );
}
