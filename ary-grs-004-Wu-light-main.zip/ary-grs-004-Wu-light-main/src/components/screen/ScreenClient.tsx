"use client";

import { useEffect, useState, useCallback, useRef } from "react";
import { ScreenFallback } from "@/components/screen/ScreenFallback";
import type { FallbackType } from "@/components/screen/ScreenFallback";

type ScreenMode = "jumbotron" | "billboard" | "live" | "leaderboard" | "works" | "announcement";

const ALL_MODES: ScreenMode[] = [
  "jumbotron",
  "billboard",
  "live",
  "leaderboard",
  "works",
  "announcement",
];

interface ScreenClientProps {
  slug: string;
  mode: string;
  children: React.ReactNode;
  initialFallback?: FallbackType;
}

/**
 * 大屏客户端适配层
 *
 * 键盘快捷键：
 *   F      — 切换全屏
 *   ← →    — 切换展示模式
 *   R      — 手动刷新数据
 *
 * 轮询：每 10 秒检测 Projection 更新 / 网络断开
 */
export function ScreenClient({
  slug,
  mode,
  children,
  initialFallback,
}: ScreenClientProps) {
  const [fallback, setFallback] = useState<FallbackType | null>(
    initialFallback ?? null,
  );
  const [lastUpdate, setLastUpdate] = useState<Date | null>(null);
  const [showHelp, setShowHelp] = useState(false);
  const failCount = useRef(0);

  const currentIndex = ALL_MODES.indexOf(mode as ScreenMode);

  const navigateMode = useCallback(
    (delta: number) => {
      const newIndex = (currentIndex + delta + ALL_MODES.length) % ALL_MODES.length;
      const newMode = ALL_MODES[newIndex];
      window.location.href = `/screen/${slug}?mode=${newMode}`;
    },
    [currentIndex, slug],
  );

  const toggleFullscreen = useCallback(() => {
    if (document.fullscreenElement) {
      document.exitFullscreen();
    } else {
      document.documentElement.requestFullscreen();
    }
  }, []);

  const poll = useCallback(async () => {
    try {
      const res = await fetch(
        `/api/internal/projections?raceId=${encodeURIComponent(slug)}`,
      );
      if (!res.ok) {
        failCount.current++;
        if (failCount.current >= 3) setFallback("disconnected");
        return;
      }
      failCount.current = 0;
      if (fallback === "disconnected") setFallback(null);
      const projections = await res.json();
      if (Array.isArray(projections) && projections.length > 0) {
        setLastUpdate(new Date());
      }
    } catch {
      failCount.current++;
      if (failCount.current >= 3) setFallback("disconnected");
    }
  }, [slug, fallback]);

  // 键盘快捷键
  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      // 不拦截输入框内的按键
      if (
        e.target instanceof HTMLInputElement ||
        e.target instanceof HTMLTextAreaElement
      ) return;

      switch (e.key) {
        case "f":
        case "F":
          e.preventDefault();
          toggleFullscreen();
          break;
        case "ArrowLeft":
          e.preventDefault();
          navigateMode(-1);
          break;
        case "ArrowRight":
          e.preventDefault();
          navigateMode(1);
          break;
        case "r":
        case "R":
          if (!e.ctrlKey && !e.metaKey) {
            e.preventDefault();
            poll();
          }
          break;
        case "?":
          setShowHelp((prev) => !prev);
          break;
      }
    };
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, [toggleFullscreen, navigateMode, poll]);

  // 轮询
  useEffect(() => {
    const interval = setInterval(poll, 10_000);
    return () => clearInterval(interval);
  }, [poll]);

  if (fallback && initialFallback) {
    return <ScreenFallback type={fallback} raceSlug={slug} />;
  }
  if (fallback === "disconnected" && !initialFallback) {
    return <ScreenFallback type="disconnected" raceSlug={slug} />;
  }

  return (
    <div className="flex h-screen flex-col overflow-hidden bg-ary-blue-950">
      {/* 主内容区 */}
      <div className="flex-1 overflow-hidden">{children}</div>

      {/* 快捷键帮助面板 */}
      {showHelp && (
        <div className="absolute right-6 top-6 z-50 rounded-2xl border border-white/10 bg-black/80 px-6 py-4 backdrop-blur">
          <button
            onClick={() => setShowHelp(false)}
            className="float-right text-xs text-white/40 hover:text-white"
          >
            ✕
          </button>
          <h3 className="text-sm font-bold text-white/60">键盘快捷键</h3>
          <div className="mt-2 space-y-1.5 text-xs text-white/40">
            <p><kbd className="rounded bg-white/10 px-1.5 py-0.5 text-white/60">F</kbd> 全屏</p>
            <p><kbd className="rounded bg-white/10 px-1.5 py-0.5 text-white/60">← →</kbd> 切换模式</p>
            <p><kbd className="rounded bg-white/10 px-1.5 py-0.5 text-white/60">R</kbd> 刷新数据</p>
            <p><kbd className="rounded bg-white/10 px-1.5 py-0.5 text-white/60">?</kbd> 显示/隐藏帮助</p>
          </div>
        </div>
      )}

      {/* 底部状态栏 */}
      <div className="flex shrink-0 items-center justify-between border-t border-white/5 bg-black/60 px-6 py-1.5 backdrop-blur">
        <div className="flex items-center gap-4 text-xs text-white/30">
          <span>ARY Screen · {slug}</span>
          <span>Mode: {mode}</span>
          <span className="text-white/15">|</span>
          <span>F: 全屏 · ←→: 切换 · R: 刷新 · ?: 帮助</span>
        </div>
        <div className="flex items-center gap-4 text-xs text-white/30">
          {lastUpdate && <span>最后更新: {lastUpdate.toLocaleTimeString("zh-CN")}</span>}
          {failCount.current > 0 && (
            <span className="text-amber-400">连接异常 ({failCount.current})</span>
          )}
        </div>
      </div>
    </div>
  );
}
