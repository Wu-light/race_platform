import type { ScreenData } from "@/lib/screen-data";

interface Props {
  data: ScreenData;
}

/**
 * Live Feed 实时动态模式
 *
 * 1920×1080：左侧骑手活动（flex-1）+ 右侧事件流（420px）
 * 最小字号 24px，事件流文字 20px（辅助信息可酌情降级）。
 */
export function ScreenLive({ data }: Props) {
  const leaderboard = data.projections.current_leaderboard as {
    rankings?: { riderName: string; progress: number; cost: number; risk: string }[];
  } | null;
  const feed = data.projections.screen_feed as {
    events?: { id: string; type: string; title: string; description: string; occurredAt: string }[];
  } | null;
  const rankings = leaderboard?.rankings ?? [];
  const events = feed?.events ?? [];

  return (
    <div className="flex h-full flex-col overflow-hidden bg-ary-blue-950 text-white">
      {/* 顶栏 */}
      <div className="flex shrink-0 items-center justify-between border-b border-white/10 px-14 py-6">
        <div>
          <p className="text-2xl font-black uppercase tracking-[0.25em] text-ary-cyan">
            LIVE FEED
          </p>
          <h1 className="mt-1 text-[38px] font-black leading-tight">{data.race.title}</h1>
        </div>
        <div className="flex items-center gap-3 rounded-full bg-ary-cyan/20 px-6 py-3">
          <span className="h-4 w-4 animate-pulse rounded-full bg-ary-cyan" />
          <span className="text-2xl font-black text-ary-cyan">LIVE</span>
        </div>
      </div>

      {/* 主体 */}
      <div className="flex flex-1 overflow-hidden">
        {/* 骑手动态 */}
        <div className="flex-1 space-y-3 overflow-y-auto px-14 py-8">
          <h2 className="text-2xl font-black uppercase tracking-[0.1em] text-white/50">
            Rider Activity
          </h2>
          {rankings.map((entry) => (
            <div
              key={entry.riderName}
              className="rounded-2xl border border-white/10 bg-white/5 px-6 py-5"
            >
              <div className="flex items-center justify-between gap-4">
                <div className="flex items-center gap-4 min-w-0">
                  <span className="grid h-14 w-14 shrink-0 place-items-center rounded-xl bg-ary-blue-800 text-[26px] font-black">
                    {entry.riderName[0]}
                  </span>
                  <div className="min-w-0">
                    <p className="text-[26px] font-black truncate">{entry.riderName}</p>
                    <p className="text-xl text-white/45">
                      进度 {Math.round(entry.progress)}% · ${entry.cost}
                    </p>
                  </div>
                </div>
                <span
                  className={`shrink-0 rounded-full px-5 py-2 text-xl font-bold ${
                    entry.risk === "high"
                      ? "bg-red-500/15 text-red-400"
                      : entry.risk === "medium"
                        ? "bg-amber-500/15 text-amber-400"
                        : "bg-emerald-500/15 text-emerald-400"
                  }`}
                >
                  {entry.risk === "high" ? "⚠ 关注" : entry.risk === "medium" ? "● 观察" : "✓ 正常"}
                </span>
              </div>
              <div className="mt-4 h-3 overflow-hidden rounded-full bg-white/10">
                <div
                  className="h-full rounded-full bg-gradient-to-r from-ary-cyan to-ary-blue-400"
                  style={{ width: `${Math.min(100, entry.progress)}%` }}
                />
              </div>
            </div>
          ))}
          {rankings.length === 0 && (
            <p className="text-2xl text-white/30">暂无活跃骑手数据</p>
          )}
        </div>

        {/* 事件流 */}
        <div className="w-[420px] shrink-0 space-y-3 overflow-y-auto border-l border-white/10 px-10 py-8">
          <h2 className="text-2xl font-black uppercase tracking-[0.1em] text-white/50">
            Event Stream
          </h2>
          {events.length > 0 ? (
            events.slice(0, 12).map((event) => (
              <div
                key={event.id}
                className="rounded-xl border border-white/10 bg-white/5 px-5 py-4"
              >
                <div className="flex items-center gap-3">
                  <span
                    className={`h-3 w-3 shrink-0 rounded-full ${
                      event.type === "session" ? "bg-ary-cyan" : "bg-amber-400"
                    }`}
                  />
                  <p className="text-xl font-bold truncate">{event.title}</p>
                </div>
                <p className="mt-1 text-lg leading-relaxed text-white/45 line-clamp-2">
                  {event.description}
                </p>
                <p className="mt-1 text-lg text-white/25">
                  {new Date(event.occurredAt).toLocaleTimeString("zh-CN")}
                </p>
              </div>
            ))
          ) : (
            <p className="text-2xl text-white/30">等待事件数据...</p>
          )}
        </div>
      </div>
    </div>
  );
}
