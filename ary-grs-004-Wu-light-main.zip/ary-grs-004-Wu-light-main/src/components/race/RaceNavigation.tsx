import Link from "next/link";
import type { PublicRaceDetail } from "@/types/public";

export function RaceNavigation({ race }: { race: PublicRaceDetail }) {
  const items = [
    { href: "#overview", label: "Overview", show: true },
    { href: "#challenge", label: "Rules & Schedule", show: true },
    { href: `/races/${race.slug}/live`, label: "Live", show: race.status === "running" },
    { href: "#riders", label: "Riders", show: race.riders.length > 0 },
    { href: `/races/${race.slug}/works`, label: "Works", show: race.works.length > 0 },
    { href: `/races/${race.slug}/results`, label: "Results", show: race.publishedAwardCount > 0 },
    { href: `/races/${race.slug}/review`, label: "Review", show: race.hasPublishedReview },
  ].filter((item) => item.show);

  return (
    <div className="sticky top-[72px] z-30 border-y border-ary-line bg-white/82 backdrop-blur-xl">
      <nav className="mx-auto flex max-w-[1440px] gap-1 overflow-x-auto px-5 sm:px-8 lg:px-12" aria-label={`${race.title} 页面导航`}>
        {items.map((item) => (
          <Link key={item.href} href={item.href} className="flex min-h-12 shrink-0 items-center border-b-2 border-transparent px-3 text-sm font-bold text-ary-muted transition hover:border-ary-blue-500 hover:text-ary-blue-900 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-inset focus-visible:ring-ary-blue-700">
            {item.label}
          </Link>
        ))}
      </nav>
    </div>
  );
}
