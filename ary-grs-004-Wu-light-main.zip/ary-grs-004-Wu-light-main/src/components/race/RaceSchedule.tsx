import { CalendarClock } from "lucide-react";
import { formatDate } from "@/lib/utils";
import type { PublicRaceSchedule } from "@/types/public";

export function RaceSchedule({ schedule }: { schedule: PublicRaceSchedule }) {
  const entries = [
    ["报名开放", schedule.registrationStart],
    ["报名截止", schedule.registrationEnd],
    ["正式开跑", schedule.raceStart],
    ["作品截止", schedule.submissionDeadline || schedule.raceEnd],
    ["评审完成", schedule.judgingEnd],
  ].filter((entry): entry is [string, string] => Boolean(entry[1]));

  if (entries.length === 0) {
    return <p className="text-sm leading-6 text-ary-muted">完整赛程将在赛事发布后公布。</p>;
  }

  return (
    <ol className="space-y-1">
      {entries.map(([label, date], index) => (
        <li key={label} className="relative flex gap-4 pb-5 last:pb-0">
          {index < entries.length - 1 && <span className="absolute left-[15px] top-8 h-[calc(100%-20px)] w-px bg-ary-line-strong" aria-hidden="true" />}
          <span className="relative z-10 grid h-8 w-8 shrink-0 place-items-center rounded-full border border-ary-line bg-ary-blue-100 text-ary-blue-700">
            <CalendarClock className="h-4 w-4" aria-hidden="true" />
          </span>
          <div>
            <p className="text-sm font-black text-ary-blue-950">{label}</p>
            <time className="mt-0.5 block text-sm text-ary-muted" dateTime={date}>{formatDate(date)}</time>
          </div>
        </li>
      ))}
    </ol>
  );
}
