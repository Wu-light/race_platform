import Link from "next/link";
import { ArrowLeft, ArrowRight, CalendarDays, Flag, Gauge, Trophy, Users } from "lucide-react";
import { ActionLink } from "@/components/ui/ActionLink";
import { MetricCard } from "@/components/ui/MetricCard";
import { StatusBadge } from "@/components/ui/StatusBadge";
import { formatDate } from "@/lib/utils";
import { getRacePrimaryAction, getRaceSecondaryAction } from "@/lib/race-utils";
import type { PublicRaceDetail } from "@/types/public";

function displayDate(value?: string) {
  return value ? formatDate(value) : "时间待公布";
}

export function RaceHero({ race }: { race: PublicRaceDetail }) {
  const primary = getRacePrimaryAction(race);
  const secondary = getRaceSecondaryAction(race);
  const stageDate =
    race.status === "registration"
      ? race.schedule.registrationEnd
      : race.status === "running" || race.status === "submitting"
        ? race.schedule.submissionDeadline || race.schedule.raceEnd
        : race.schedule.judgingEnd || race.schedule.raceEnd;

  return (
    <section className="ary-content pb-12 pt-28 sm:pb-16 sm:pt-32" aria-labelledby="race-title">
      <Link href="/" className="inline-flex min-h-11 items-center gap-2 rounded-lg px-1 text-sm font-bold text-ary-muted hover:text-ary-blue-700">
        <ArrowLeft className="h-4 w-4" aria-hidden="true" /> 返回 Race Gallery
      </Link>

      <div className="mt-6 grid gap-8 lg:grid-cols-[minmax(0,1fr)_320px] lg:items-end">
        <div>
          <div className="flex flex-wrap items-center gap-3">
            <StatusBadge status={race.status} />
            <span className="inline-flex items-center gap-2 text-xs font-bold uppercase tracking-[0.13em] text-ary-muted">
              <CalendarDays className="h-4 w-4 text-ary-blue-500" aria-hidden="true" />
              {displayDate(stageDate)}
            </span>
          </div>
          <h1 id="race-title" className="mt-5 max-w-5xl text-[clamp(3rem,7vw,6.4rem)] font-black leading-[0.95] tracking-[-0.055em] text-ary-blue-950">
            {race.title}
          </h1>
          {race.subtitle && <p className="mt-4 text-lg font-bold text-ary-blue-700 sm:text-xl">{race.subtitle}</p>}
          <p className="mt-5 max-w-3xl text-base leading-7 text-ary-muted sm:text-lg">{race.description}</p>
          <div className="mt-7 flex flex-col gap-3 sm:flex-row">
            <ActionLink href={primary.href}>{primary.label}<ArrowRight className="h-4 w-4" aria-hidden="true" /></ActionLink>
            <ActionLink href={secondary.href} variant="secondary">{secondary.label}</ActionLink>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-3">
          <MetricCard label="Riders" value={race.metrics.riders} hint="approved" />
          <MetricCard label="Public works" value={race.metrics.publicWorks} hint="visible" />
          {race.status === "running" ? (
            <>
              <MetricCard label="Active" value={race.metrics.activeRiders ?? "—"} hint="Projection" />
              <MetricCard label="Progress" value={race.metrics.averageProgress === null ? "—" : `${race.metrics.averageProgress}%`} hint="Projection" />
            </>
          ) : (
            <>
              <MetricCard label="Awards" value={race.publishedAwardCount} hint="published" />
              <MetricCard label="Organizer" value={race.organizerName} className="[&>p:nth-child(2)]:text-base" />
            </>
          )}
        </div>
      </div>

      <div className="ary-track mt-12 min-h-[190px] sm:min-h-[230px]" aria-hidden="true">
        <div className="absolute left-6 top-6 flex items-center gap-2 rounded-xl bg-white/85 px-3 py-2 text-xs font-black text-ary-blue-800 shadow-sm">
          <Gauge className="h-4 w-4" /> {race.status === "running" ? "Riding now" : "Race archive"}
        </div>
        <span className="ary-rider-marker" data-label="Start" style={{ left: "14%", top: "67%" }} />
        <span className="ary-rider-marker bg-ary-cyan" data-label={race.status === "running" ? "Live" : "Work"} style={{ left: "52%", top: "49%" }} />
        <span className="ary-rider-marker bg-amber-400" data-label="Finish" style={{ left: "84%", top: "62%" }} />
        <div className="absolute bottom-5 right-5 flex flex-wrap items-center justify-end gap-2 text-xs font-bold text-ary-blue-900">
          <span className="inline-flex items-center gap-1.5 rounded-lg bg-white/80 px-3 py-2"><Users className="h-3.5 w-3.5" />{race.metrics.riders} Riders</span>
          <span className="inline-flex items-center gap-1.5 rounded-lg bg-white/80 px-3 py-2"><Flag className="h-3.5 w-3.5" />{race.metrics.submittedWorks} Works</span>
          {race.publishedAwardCount > 0 && <span className="inline-flex items-center gap-1.5 rounded-lg bg-white/80 px-3 py-2"><Trophy className="h-3.5 w-3.5" />{race.publishedAwardCount} Awards</span>}
        </div>
      </div>
    </section>
  );
}
