import Link from "next/link";
import { ArrowRight, CalendarDays, Flag, Users } from "lucide-react";
import { StatusBadge } from "@/components/ui/StatusBadge";
import { formatDate } from "@/lib/utils";
import { getRacePrimaryAction } from "@/lib/race-utils";
import type { PublicRaceSummary } from "@/types/public";

function raceDate(race: PublicRaceSummary) {
  const value = race.schedule.raceStart || race.schedule.registrationEnd;
  return value ? formatDate(value) : "时间待公布";
}

export function RaceCard({ race }: { race: PublicRaceSummary }) {
  const action = getRacePrimaryAction(race);
  return (
    <article className="group ary-glass flex h-full flex-col rounded-3xl p-6 transition duration-300 hover:-translate-y-1 hover:border-ary-line-strong hover:shadow-[0_24px_56px_rgba(11,57,150,0.2)]">
      <div className="flex items-start justify-between gap-4">
        <StatusBadge status={race.status} />
        <span className="text-xs font-black tracking-[0.16em] text-ary-blue-500">RACE</span>
      </div>
      <h3 className="mt-5 text-xl font-black tracking-tight text-ary-blue-950">
        <Link href={`/races/${race.slug}`} className="rounded-sm hover:text-ary-blue-700">
          {race.title}
        </Link>
      </h3>
      <p className="mt-2 line-clamp-3 flex-1 text-sm leading-6 text-ary-muted">{race.challenge}</p>
      <div className="mt-5 grid grid-cols-2 gap-2 text-xs text-ary-muted">
        <span className="flex items-center gap-2 rounded-xl bg-ary-blue-100/70 px-3 py-2.5">
          <CalendarDays className="h-3.5 w-3.5 text-ary-blue-700" aria-hidden="true" />
          {raceDate(race)}
        </span>
        <span className="flex items-center gap-2 rounded-xl bg-ary-blue-100/70 px-3 py-2.5">
          <Users className="h-3.5 w-3.5 text-ary-blue-700" aria-hidden="true" />
          {race.metrics.riders} Riders
        </span>
      </div>
      <Link
        href={action.href}
        className="mt-5 inline-flex min-h-11 items-center justify-between rounded-xl border border-ary-line px-4 py-2.5 text-sm font-bold text-ary-blue-800 transition hover:border-ary-line-strong hover:bg-ary-blue-100"
      >
        <span className="flex items-center gap-2">
          <Flag className="h-4 w-4" aria-hidden="true" />
          {action.label}
        </span>
        <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" aria-hidden="true" />
      </Link>
    </article>
  );
}
