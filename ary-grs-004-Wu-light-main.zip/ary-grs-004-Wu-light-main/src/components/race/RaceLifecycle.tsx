import { Check } from "lucide-react";
import { cn } from "@/lib/utils";
import type { RaceStatus } from "@/types";

const stages = [
  { label: "报名", statuses: ["published", "registration"] },
  { label: "骑行", statuses: ["running"] },
  { label: "提交", statuses: ["submitting"] },
  { label: "评审", statuses: ["judging"] },
  { label: "赛果", statuses: ["completed", "archived"] },
] as const;

function currentStage(status: RaceStatus) {
  const index = stages.findIndex((stage) => (stage.statuses as readonly string[]).includes(status));
  return Math.max(0, index);
}

export function RaceLifecycle({ status }: { status: RaceStatus }) {
  const activeIndex = currentStage(status);
  return (
    <ol className="grid gap-3 sm:grid-cols-5" aria-label="赛事生命周期">
      {stages.map((stage, index) => {
        const completed = index < activeIndex || status === "completed" || status === "archived";
        const active = index === activeIndex && status !== "completed" && status !== "archived";
        return (
          <li key={stage.label} className={cn("relative rounded-2xl border p-4", completed || active ? "border-ary-line-strong bg-white shadow-sm" : "border-ary-line bg-white/45")}>
            <div className="flex items-center gap-3">
              <span className={cn("grid h-8 w-8 shrink-0 place-items-center rounded-full text-xs font-black", completed ? "bg-ary-blue-700 text-white" : active ? "bg-ary-cyan text-ary-blue-950" : "bg-ary-blue-100 text-ary-muted")}>
                {completed ? <Check className="h-4 w-4" aria-hidden="true" /> : index + 1}
              </span>
              <span>
                <b className="block text-sm text-ary-blue-950">{stage.label}</b>
                <small className="text-ary-muted">{active ? "当前阶段" : completed ? "已完成" : "待开始"}</small>
              </span>
            </div>
          </li>
        );
      })}
    </ol>
  );
}
