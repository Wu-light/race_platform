import { Flag } from "lucide-react";

export function EmptyState({ title, description }: { title: string; description: string }) {
  return (
    <div className="rounded-3xl border border-dashed border-ary-line-strong bg-white/60 px-6 py-12 text-center">
      <Flag className="mx-auto h-7 w-7 text-ary-blue-500" aria-hidden="true" />
      <h3 className="mt-4 font-bold text-ary-blue-950">{title}</h3>
      <p className="mx-auto mt-2 max-w-md text-sm leading-6 text-ary-muted">{description}</p>
    </div>
  );
}
