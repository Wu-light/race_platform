import { cn } from "@/lib/utils";
import { raceStatusLabels } from "@/lib/race-utils";
import type { RaceStatus } from "@/types";

const statusStyles: Record<RaceStatus, string> = {
  draft: "border-slate-200 bg-slate-100 text-slate-600",
  published: "border-cyan-200 bg-cyan-50 text-cyan-800",
  registration: "border-emerald-200 bg-emerald-50 text-emerald-700",
  running: "border-blue-200 bg-blue-50 text-ary-blue-700",
  submitting: "border-violet-200 bg-violet-50 text-violet-700",
  judging: "border-amber-200 bg-amber-50 text-amber-700",
  completed: "border-indigo-200 bg-indigo-50 text-indigo-700",
  archived: "border-slate-200 bg-slate-100 text-slate-600",
};

export function StatusBadge({ status, className }: { status: RaceStatus; className?: string }) {
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-xs font-semibold",
        statusStyles[status],
        className,
      )}
    >
      {status === "running" && (
        <span className="relative flex h-1.5 w-1.5" aria-hidden="true">
          <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-ary-blue-500 opacity-60 motion-reduce:animate-none" />
          <span className="relative inline-flex h-1.5 w-1.5 rounded-full bg-ary-blue-700" />
        </span>
      )}
      {raceStatusLabels[status]}
    </span>
  );
}
