import { cn } from "@/lib/utils";

interface SectionHeadingProps {
  eyebrow: string;
  title: string;
  description?: string;
  action?: React.ReactNode;
  align?: "left" | "center";
  className?: string;
}

export function SectionHeading({
  eyebrow,
  title,
  description,
  action,
  align = "left",
  className,
}: SectionHeadingProps) {
  return (
    <div
      className={cn(
        "mb-8 flex flex-col gap-5 sm:flex-row sm:items-end sm:justify-between",
        align === "center" && "items-center text-center sm:flex-col sm:items-center",
        className,
      )}
    >
      <div className="max-w-2xl">
        <p className="text-xs font-bold uppercase tracking-[0.24em] text-ary-blue-700">
          {eyebrow}
        </p>
        <h2 className="mt-2 text-3xl font-black tracking-tight text-ary-blue-950 sm:text-4xl">
          {title}
        </h2>
        {description && <p className="mt-3 leading-7 text-ary-muted">{description}</p>}
      </div>
      {action}
    </div>
  );
}
