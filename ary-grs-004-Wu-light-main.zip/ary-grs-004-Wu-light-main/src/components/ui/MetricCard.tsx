import { cn } from "@/lib/utils";

export function MetricCard({
  label,
  value,
  hint,
  className,
}: {
  label: string;
  value: string | number;
  hint?: string;
  className?: string;
}) {
  return (
    <div className={cn("rounded-2xl border border-ary-line bg-white/70 p-4 backdrop-blur", className)}>
      <p className="text-xs font-semibold uppercase tracking-[0.12em] text-ary-muted">{label}</p>
      <p className="mt-1 text-2xl font-black text-ary-blue-950">{value}</p>
      {hint && <p className="mt-1 text-xs text-ary-muted">{hint}</p>}
    </div>
  );
}
