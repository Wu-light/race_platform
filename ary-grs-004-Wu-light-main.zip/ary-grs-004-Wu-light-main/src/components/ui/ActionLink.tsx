import Link from "next/link";
import { ArrowUpRight } from "lucide-react";
import { cn } from "@/lib/utils";

interface ActionLinkProps {
  href: string;
  children: React.ReactNode;
  variant?: "primary" | "secondary" | "quiet";
  className?: string;
  external?: boolean;
}

export function ActionLink({
  href,
  children,
  variant = "primary",
  className,
  external = false,
}: ActionLinkProps) {
  const classes = cn(
    "inline-flex min-h-11 items-center justify-center gap-2 rounded-xl px-5 py-2.5 text-sm font-semibold transition duration-200 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ary-blue-700 focus-visible:ring-offset-2",
    variant === "primary" &&
      "bg-gradient-to-br from-ary-blue-800 to-ary-blue-500 text-white shadow-[0_12px_30px_rgba(7,91,236,0.22)] hover:-translate-y-0.5 hover:shadow-[0_16px_34px_rgba(7,91,236,0.3)]",
    variant === "secondary" &&
      "border border-ary-line bg-white/80 text-ary-blue-900 shadow-sm backdrop-blur hover:-translate-y-0.5 hover:border-ary-line-strong hover:bg-white",
    variant === "quiet" && "px-1 text-ary-blue-700 hover:text-ary-blue-900",
    className,
  );

  if (external) {
    return (
      <a href={href} target="_blank" rel="noreferrer" className={classes}>
        {children}
        <ArrowUpRight className="h-4 w-4" aria-hidden="true" />
      </a>
    );
  }

  return (
    <Link href={href} className={classes}>
      {children}
    </Link>
  );
}
