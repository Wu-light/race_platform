import type { ReactNode } from "react";
import { cn } from "@/lib/utils";

function isListItem(line: string) {
  return /^[-*]\s+/.test(line) || /^\d+[.)]\s+/.test(line);
}

export function SafeMarkdown({ content, className }: { content: string; className?: string }) {
  const lines = content.replace(/\r\n/g, "\n").split("\n");
  const blocks: ReactNode[] = [];
  let index = 0;

  while (index < lines.length) {
    const line = lines[index].trim();
    if (!line) {
      index += 1;
      continue;
    }

    const heading = /^(#{1,3})\s+(.+)$/.exec(line);
    if (heading) {
      const level = heading[1].length;
      const text = heading[2];
      blocks.push(
        level === 1 ? (
          <h2 key={`h-${index}`} className="text-3xl font-black tracking-tight text-ary-blue-950">{text}</h2>
        ) : level === 2 ? (
          <h3 key={`h-${index}`} className="text-2xl font-black text-ary-blue-950">{text}</h3>
        ) : (
          <h4 key={`h-${index}`} className="text-lg font-black text-ary-blue-900">{text}</h4>
        ),
      );
      index += 1;
      continue;
    }

    if (isListItem(line)) {
      const ordered = /^\d+[.)]\s+/.test(line);
      const items: string[] = [];
      while (index < lines.length && isListItem(lines[index].trim())) {
        items.push(lines[index].trim().replace(ordered ? /^\d+[.)]\s+/ : /^[-*]\s+/, ""));
        index += 1;
      }
      const List = ordered ? "ol" : "ul";
      blocks.push(
        <List key={`list-${index}`} className={ordered ? "list-decimal space-y-2 pl-6" : "list-disc space-y-2 pl-6"}>
          {items.map((item, itemIndex) => <li key={`${item}-${itemIndex}`}>{item}</li>)}
        </List>,
      );
      continue;
    }

    const paragraph: string[] = [line];
    index += 1;
    while (index < lines.length) {
      const next = lines[index].trim();
      if (!next || /^(#{1,3})\s+/.test(next) || isListItem(next)) break;
      paragraph.push(next);
      index += 1;
    }
    blocks.push(<p key={`p-${index}`} className="leading-8">{paragraph.join(" ")}</p>);
  }

  return <div className={cn("space-y-5 text-ary-muted", className)}>{blocks}</div>;
}
