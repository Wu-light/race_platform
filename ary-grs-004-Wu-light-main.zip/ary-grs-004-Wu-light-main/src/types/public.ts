import type { RaceStatus } from "@/types";

export interface PublicRaceSchedule {
  registrationStart?: string;
  registrationEnd?: string;
  raceStart?: string;
  raceEnd?: string;
  submissionDeadline?: string;
  judgingEnd?: string;
}

export interface PublicSubmissionRequirements {
  fields: string[];
  format?: string;
  description?: string;
  note?: string;
}

export interface PublicRaceMetrics {
  riders: number;
  activeRiders: number | null;
  submittedWorks: number;
  publicWorks: number;
  sessionsStarted: number | null;
  averageProgress: number | null;
  totalCost: number | null;
  highRiskRiders: number | null;
  totalTokens: number | null;
}

export interface PublicRaceSummary {
  id: string;
  slug: string;
  title: string;
  subtitle: string | null;
  description: string;
  challenge: string;
  status: RaceStatus;
  schedule: PublicRaceSchedule;
  metrics: PublicRaceMetrics;
  publishedAwardCount: number;
  hasPublishedReview: boolean;
}

export interface PublicAwardSummary {
  id: string;
  name: string;
  rank: number;
  reason: string | null;
  riderName: string;
  workTitle: string | null;
  workSlug: string | null;
}

export interface PublicWorkSummary {
  id: string;
  slug: string;
  title: string;
  description: string;
  demoUrl: string | null;
  race: {
    slug: string;
    title: string;
  };
  author: {
    id: string;
    slug: string | null;
    name: string;
    avatar: string | null;
    affiliation: string | null;
  };
  awards: string[];
}

export interface PublicEvidenceSummary {
  id: string;
  type: string;
  title: string;
  summary: string | null;
  metrics?: {
    sessions?: number;
    totalTokens?: number;
    corrections?: number;
    progress?: number;
  };
}

export interface PublicWorkDetail extends PublicWorkSummary {
  githubUrl: string | null;
  videoUrl: string | null;
  techDescription: string | null;
  updatedAt: string;
  evidence: PublicEvidenceSummary[];
  awardDetails: PublicAwardSummary[];
  raceChallenge: string;
}

export interface PublicRiderSummary {
  id: string;
  slug: string | null;
  name: string;
  avatar: string | null;
  affiliation: string | null;
  representativeRace: string;
  representativeWork: string;
  workCount: number;
  awardCount: number;
  skillTags: string[];
}

export interface PublicResultSummary {
  race: PublicRaceSummary;
  topAward: PublicAwardSummary | null;
}

export interface HomeRaceFeature {
  race: PublicRaceSummary;
  work: PublicWorkSummary | null;
  rider: PublicRiderSummary | null;
}

export interface HomeGalleryData {
  featuredRaces: HomeRaceFeature[];
  openRaces: PublicRaceSummary[];
  latestResults: PublicResultSummary[];
  featuredWorks: PublicWorkSummary[];
  featuredRiders: PublicRiderSummary[];
  pastRaces: PublicRaceSummary[];
}

export interface PublicAnnouncement {
  id: string;
  title: string;
  body: string;
  publishedAt: string;
}

export interface PublicRaceDetail extends PublicRaceSummary {
  rules: string;
  awardSettings: string[];
  submissionRequirements: PublicSubmissionRequirements;
  organizerName: string;
  announcements: PublicAnnouncement[];
  awards: PublicAwardSummary[];
  works: PublicWorkSummary[];
  riders: PublicRiderSummary[];
}

export interface PublicWorksPageData {
  race: PublicRaceSummary;
  works: PublicWorkSummary[];
}

export interface PublicRaceResults {
  race: PublicRaceSummary;
  awards: PublicAwardSummary[];
  winningWorks: PublicWorkSummary[];
  riders: PublicRiderSummary[];
  hasPublishedReview: boolean;
}

export interface PublicRaceReview {
  race: PublicRaceSummary;
  content: string;
  publishedAt: string;
  awards: PublicAwardSummary[];
  featuredWorks: PublicWorkSummary[];
  evidence: PublicEvidenceSummary[];
}

export interface PublicRiderRaceSummary {
  slug: string;
  title: string;
  status: RaceStatus;
  workTitle: string;
  awardNames: string[];
}

export interface PublicRiderDetail extends PublicRiderSummary {
  bio: string | null;
  works: PublicWorkSummary[];
  races: PublicRiderRaceSummary[];
  awards: Array<PublicAwardSummary & { raceSlug: string; raceTitle: string }>;
  evidence: PublicEvidenceSummary[];
  performance: {
    sessions: number | null;
    totalTokens: number | null;
    corrections: number | null;
    averageProgress: number | null;
    totalCost: number | null;
    riskSignals: number | null;
  };
}

export interface PublicLiveLeaderboardEntry {
  rank: number;
  riderName: string;
  progress: number;
  cost: number;
  risk: "low" | "medium" | "high";
}

export interface PublicLiveEvent {
  id: string;
  type: "projection" | "announcement";
  title: string;
  description: string;
  occurredAt: string;
}

export interface PublicLiveHallData {
  race: PublicRaceDetail;
  leaderboard: PublicLiveLeaderboardEntry[];
  events: PublicLiveEvent[];
  projectionUpdatedAt: string | null;
}
