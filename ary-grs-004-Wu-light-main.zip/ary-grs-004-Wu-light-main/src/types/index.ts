import type { User, Race, Registration, RaceProject } from "@prisma/client";

export type Role = "rider" | "judge" | "organizer" | "admin";

export type RaceStatus =
  | "draft"
  | "published"
  | "registration"
  | "running"
  | "submitting"
  | "judging"
  | "completed"
  | "archived";

export type RegistrationStatus =
  | "submitted"
  | "approved"
  | "rejected"
  | "withdrawn";

export type IngestionStatus =
  | "not_configured"
  | "connected"
  | "active"
  | "failed";

export type CAType = "claude_code" | "codex" | "other";

export type WorkStatus = "draft" | "submitted" | "locked" | "hidden";

export type Visibility = "public" | "hidden" | "internal" | "unpublished";

export type EvidenceType =
  | "session_summary"
  | "work"
  | "commit_pr"
  | "screenshot"
  | "judge_comment"
  | "retrospective"
  | "video";

export type ReportType = "rider_report" | "race_report" | "review_summary";

export type ReportStatus = "draft" | "generated" | "reviewed" | "published";

export type ProjectionType =
  | "race_progress"
  | "registration_status"
  | "cost"
  | "risk"
  | "submission"
  | "judging"
  | "current_leaderboard"
  | "screen_feed";

export type ScreenMode =
  | "jumbotron"
  | "billboard"
  | "live"
  | "leaderboard"
  | "works"
  | "announcement";
