import type { NextAuthConfig } from "next-auth";
import GitHub from "next-auth/providers/github";
import { prisma } from "./db";
import { authAdapter } from "./auth-adapter";

export const authConfig: NextAuthConfig = {
  adapter: authAdapter(),
  providers: [
    GitHub({
      clientId: process.env.GITHUB_ID,
      clientSecret: process.env.GITHUB_SECRET,
    }),
  ],
  pages: {
    signIn: "/login",
    error: "/login",
  },
  callbacks: {
    async session({ session, user }) {
      if (session.user) {
        session.user.id = user.id;
        session.user.name = user.name;
        session.user.email = user.email;
        (session.user as any).image = (user as any).avatar;
        const dbUser = await prisma.user.findUnique({
          where: { id: user.id },
          select: { roles: true, profileCompleted: true },
        });
        if (dbUser) {
          try {
            (session.user as any).roles = JSON.parse(dbUser.roles);
          } catch {
            (session.user as any).roles = [];
          }
          (session.user as any).profileCompleted = dbUser.profileCompleted;
        }
      }
      return session;
    },
  },
  events: {
    async signIn({ user, account, profile }) {
      if (account?.provider !== "github" || !profile?.id || !user?.id) return;
      const githubId = parseInt(String(profile.id), 10);
      if (Number.isNaN(githubId)) return;
      await prisma.user.update({
        where: { id: user.id },
        data: { githubId },
      });
    },
  },
  session: {
    strategy: "database",
  },
};
