/**
 * CA Mock Data Generator — 第5棒 T5.1
 *
 * 为 MVP 阶段生成模拟的 CA Session 和 RidingMetrics 数据。
 * 不接入真实 CA (Claude Code / Codex)，而是生成逼真的模拟数据。
 */

import { prisma } from "@/lib/db";

// ---- 随机工具函数 ----

function randInt(min: number, max: number): number {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

function randFloat(min: number, max: number, decimals = 2): number {
  return parseFloat((Math.random() * (max - min) + min).toFixed(decimals));
}

/**
 * 正态分布采样（Box-Muller 变换）。
 * 生成符合 N(mean, stdDev²) 分布的随机数。
 *
 * 理论分布特征（mean=25500, stdDev=12000）：
 *   ┌─────────────┬──────────┬─────────────────────┐
 *   │     σ 范围   │  概率    │  tokenCost 范围      │
 *   ├─────────────┼──────────┼─────────────────────┤
 *   │  ±1σ (68%)  │  68.27%  │  13,500 ~ 37,500    │
 *   │  ±2σ (95%)  │  95.45%  │   1,500 ~ 49,500    │
 *   │  ±3σ (99.7%)│  99.73%  │       0 ~ 61,500    │
 *   └─────────────┴──────────┴─────────────────────┘
 *
 * 钳位到 [min, max] 后，大约 95%+ 的值落在 1,000~50,000 区间内，
 * 钳位裁剪掉两侧极端尾部（<1K 和 >50K 各约 2%），对模拟效果几乎无影响。
 */
function normalClamped(mean: number, stdDev: number, min: number, max: number): number {
  let u = 0;
  let v = 0;
  while (u === 0) u = Math.random();
  while (v === 0) v = Math.random();
  const z = Math.sqrt(-2.0 * Math.log(u)) * Math.cos(2.0 * Math.PI * v);
  const raw = z * stdDev + mean;
  return Math.round(Math.max(min, Math.min(max, raw)));
}

function randomPastHours(hours: number): Date {
  const ms = Math.random() * hours * 60 * 60 * 1000;
  return new Date(Date.now() - ms);
}

function pick<T>(arr: T[]): T {
  return arr[Math.floor(Math.random() * arr.length)];
}

// ---- 模拟数据生成 ----

const MODEL_NAMES = ["claude-sonnet-5", "claude-opus-4-8", "claude-fable-5", "deepseek-v4-pro"];
const STRENGTHS = [
  "目标拆解精准，模块边界清晰",
  "Agent prompt 工程熟练，首轮准确率高",
  "纠偏及时，能在 AI 偏离方向时快速调整",
  "成本控制出色，Token 使用效率高",
  "复盘表达清晰，骑行过程可追溯",
  "技术判断准确，架构决策合理",
];
const IMPROVEMENTS = [
  "建议细化 Agent prompt 模板以提高首轮准确率",
  "可尝试更激进的并行策略提升效率",
  "建议增加中间检查点，减少后期的返工",
  "可考虑使用更结构化的 commit message",
  "建议将大型任务进一步拆分为更小的子任务",
  "可尝试在 Session 间增加手动 review 环节",
];
const RISK_SIGNALS_POOL = [
  "连续 3 个 Session 无实质性代码产出",
  "Token 消耗异常增长（环比 +60%）",
  "大量工具调用失败重试",
  "作品仓库长时间无 commit",
  "RidingMetrics 进度停滞超过 24h",
  "CAConnection 心跳中断",
];

export interface IngestResult {
  sessionsCreated: number;
  connectionsUpdated: number;
}

export interface IngestOptions {
  /** 每个连接生成的 Session 数量，默认 20 */
  sessionsPerConnection?: number;
  /** tokenCost 正态分布均值，默认 25500 */
  tokenCostMean?: number;
  /** tokenCost 正态分布标准差，默认 12000 */
  tokenCostStdDev?: number;
  /** tokenCost 下限，默认 1000 */
  tokenCostMin?: number;
  /** tokenCost 上限，默认 50000 */
  tokenCostMax?: number;
}

const DEFAULT_OPTIONS: Required<IngestOptions> = {
  sessionsPerConnection: 20,
  tokenCostMean: 25500,
  tokenCostStdDev: 12000,
  tokenCostMin: 1000,
  tokenCostMax: 50000,
};

/**
 * 为单个 CAConnection 生成 CASession。
 *
 * tokenCost 使用正态分布 N(mean, stdDev²) 钳位到 [min, max]：
 *   - ~68% 落在 13,500~37,500（±1σ）
 *   - ~95% 落在 1,500~49,500（±2σ）
 *   - 超出 [1000, 50000] 的极端值（约 4%）被钳位到边界
 */
async function generateMockSessions(
  caConnectionId: string,
  count: number,
  opts: Required<IngestOptions>,
): Promise<number> {
  const sessions = [];

  for (let i = 0; i < count; i++) {
    const startedAt = randomPastHours(24);
    const durationMinutes = randInt(10, 120);
    const endedAt = new Date(startedAt.getTime() + durationMinutes * 60 * 1000);
    const messageCount = normalClamped(40, 25, 8, 200);
    const toolCallRatio = randFloat(0.3, 0.8);
    const toolCallCount = Math.max(2, Math.round(messageCount * toolCallRatio));
    const tokenCost = normalClamped(
      opts.tokenCostMean,
      opts.tokenCostStdDev,
      opts.tokenCostMin,
      opts.tokenCostMax,
    );

    sessions.push({
      caConnectionId,
      summary: JSON.stringify({
        totalMessages: messageCount,
        totalToolCalls: toolCallCount,
        peakConcurrency: randInt(1, 4),
        modelUsed: pick(MODEL_NAMES),
      }),
      startedAt,
      endedAt,
      messageCount,
      toolCallCount,
      tokenCost,
    });
  }

  await prisma.cASession.createMany({ data: sessions });
  return count;
}

/**
 * 更新单个 CAConnection 的 RidingMetrics（upsert）。
 */
async function updateRidingMetrics(caConnectionId: string): Promise<void> {
  const sessions = await prisma.cASession.findMany({
    where: { caConnectionId },
    select: { messageCount: true, toolCallCount: true, tokenCost: true },
  });

  const totalSessions = sessions.length;
  const totalMessages = sessions.reduce((s, r) => s + r.messageCount, 0);
  const totalToolCalls = sessions.reduce((s, r) => s + r.toolCallCount, 0);
  const totalTokenCost = sessions.reduce((s, r) => s + r.tokenCost, 0);
  const avgCostPerSession = totalSessions > 0
    ? parseFloat((totalTokenCost / totalSessions).toFixed(2))
    : 0;
  const estimatedUsdCost = parseFloat((totalTokenCost * 0.000015).toFixed(2));

  // 模拟进度（基于 session 数量）
  const progressBase = Math.min(0.95, totalSessions * 0.06 + Math.random() * 0.1);
  const completionPercent = Math.round(progressBase * 100);

  // 风险信号
  const riskSignals: string[] = [];
  if (totalTokenCost > 100000) riskSignals.push(RISK_SIGNALS_POOL[1]);
  if (totalToolCalls / Math.max(1, totalMessages) > 0.7) riskSignals.push(RISK_SIGNALS_POOL[2]);
  if (totalSessions < 3 && completionPercent < 20) riskSignals.push(RISK_SIGNALS_POOL[0]);
  if (riskSignals.length === 0 && Math.random() < 0.15) {
    riskSignals.push(pick(RISK_SIGNALS_POOL));
  }

  const riskLevel: "low" | "medium" | "high" =
    riskSignals.length >= 3 ? "high" : riskSignals.length >= 1 ? "medium" : "low";

  const costSummary = {
    totalTokenCost,
    estimatedUsdCost,
    avgCostPerSession,
    costEfficiency: estimatedUsdCost > 0
      ? pick(["高效", "正常", "偏高"])
      : "正常",
    trend: pick(["stable", "rising", "falling"]) as "stable" | "rising" | "falling",
  };

  const progressSummary = {
    completionPercent,
    milestonesCompleted: Math.floor(completionPercent / 20),
    totalMilestones: 5,
    estimatedRemaining: Math.max(0, Math.round((100 - completionPercent) * 0.6)),
  };

  const riskSummary = {
    level: riskLevel,
    signals: riskSignals,
    recommendation: riskLevel === "high"
      ? "建议主办方关注该选手，可能无法按时完成"
      : riskLevel === "medium"
        ? "持续观察，暂无阻塞风险"
        : "目前表现正常",
  };

  const skillSummary = {
    targetDecomposition: randInt(5, 10),
    agentCollaboration: randInt(5, 10),
    correctionAbility: randInt(5, 10),
    technicalJudgment: randInt(5, 10),
    costControl: randInt(5, 10),
    reviewExpression: randInt(5, 10),
  };

  const data = {
    costSummary: JSON.stringify(costSummary),
    progressSummary: JSON.stringify(progressSummary),
    riskSummary: JSON.stringify(riskSummary),
    skillSummary: JSON.stringify(skillSummary),
  };

  await prisma.ridingMetrics.upsert({
    where: { caConnectionId },
    create: { caConnectionId, ...data },
    update: data,
  });
}

/**
 * 为所有活跃的 CAConnection 生成模拟数据。
 *
 * 每个连接生成 sessionsPerConnection 条 CASession（默认 20），
 * tokenCost 按正态分布 N(tokenCostMean, tokenCostStdDev²) 钳位到 [tokenCostMin, tokenCostMax]。
 *
 * 可选通过 raceId 限定范围。
 */
export async function ingestMockData(
  raceId?: string,
  opts?: IngestOptions,
): Promise<IngestResult> {
  const options = { ...DEFAULT_OPTIONS, ...opts };

  const where: Record<string, unknown> = {
    ingestionStatus: { in: ["connected", "active"] },
    disabledAt: null,
  };

  if (raceId) {
    const raceProjects = await prisma.raceProject.findMany({
      where: { registration: { raceId } },
      select: { id: true },
    });
    const raceProjectIds = raceProjects.map((rp) => rp.id);
    if (raceProjectIds.length === 0) {
      return { sessionsCreated: 0, connectionsUpdated: 0 };
    }
    where.raceProjectId = { in: raceProjectIds };
  }

  const connections = await prisma.cAConnection.findMany({
    where: where as any,
    select: { id: true, raceProjectId: true },
  });

  let sessionsCreated = 0;

  for (const conn of connections) {
    const n = await generateMockSessions(
      conn.id,
      options.sessionsPerConnection,
      options,
    );
    sessionsCreated += n;
    await updateRidingMetrics(conn.id);

    await prisma.raceProject.update({
      where: { id: conn.raceProjectId },
      data: { lastSyncedAt: new Date() },
    });
  }

  return {
    sessionsCreated,
    connectionsUpdated: connections.length,
  };
}
