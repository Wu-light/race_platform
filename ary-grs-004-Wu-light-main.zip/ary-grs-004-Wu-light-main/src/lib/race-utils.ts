import type { RaceStatus } from "@/types";
import type { PublicRaceSummary } from "@/types/public";

export const raceStatusLabels: Record<RaceStatus, string> = {
  draft: "草稿",
  published: "即将开放",
  registration: "报名中",
  running: "进行中",
  submitting: "提交中",
  judging: "评审中",
  completed: "已结束",
  archived: "已归档",
};

const validStatuses = new Set<RaceStatus>(Object.keys(raceStatusLabels) as RaceStatus[]);

export function normalizeRaceStatus(status: string): RaceStatus {
  return validStatuses.has(status as RaceStatus) ? (status as RaceStatus) : "published";
}

export function getRacePrimaryAction(race: Pick<PublicRaceSummary, "slug" | "status">) {
  switch (race.status) {
    case "registration":
      return { label: "报名参赛", href: `/console/races/${race.slug}/rider` };
    case "running":
      return { label: "进入 Live Hall", href: `/races/${race.slug}/live` };
    case "submitting":
      return { label: "查看提交进展", href: `/races/${race.slug}/works` };
    case "judging":
      return { label: "查看参赛作品", href: `/races/${race.slug}/works` };
    case "completed":
    case "archived":
      return { label: "查看最终赛果", href: `/races/${race.slug}/results` };
    default:
      return { label: "查看赛事", href: `/races/${race.slug}` };
  }
}

export function getRaceSecondaryAction(race: Pick<PublicRaceSummary, "slug" | "status">) {
  if (race.status === "completed" || race.status === "archived") {
    return { label: "浏览优秀作品", href: `/races/${race.slug}/works` };
  }
  if (race.status === "registration" || race.status === "published") {
    return { label: "查看赛题", href: `/races/${race.slug}#challenge` };
  }
  return { label: "查看作品", href: `/races/${race.slug}/works` };
}

export function getRaceProgress(status: RaceStatus) {
  const positions: Record<RaceStatus, number> = {
    draft: 0,
    published: 5,
    registration: 18,
    running: 52,
    submitting: 70,
    judging: 84,
    completed: 100,
    archived: 100,
  };
  return positions[status];
}
