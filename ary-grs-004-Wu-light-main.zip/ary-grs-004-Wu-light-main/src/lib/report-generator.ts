/**
 * Report 自动生成逻辑 — 第5棒 T5.5
 *
 * 从 JudgingRecord、Award、Evidence、RidingMetrics 等数据自动生成
 * rider_report、race_report、review_summary 三种 Markdown 报告。
 */

import { prisma } from "@/lib/db";

function safeJsonParse<T>(value: string, fallback: T): T {
  try {
    return JSON.parse(value) as T;
  } catch {
    return fallback;
  }
}

interface SkillSummary {
  targetDecomposition?: number;
  agentCollaboration?: number;
  correctionAbility?: number;
  technicalJudgment?: number;
  costControl?: number;
  reviewExpression?: number;
}

/**
 * 生成单个 Rider 报告。
 */
export async function generateRiderReport(registrationId: string): Promise<string> {
  const registration = await prisma.registration.findUnique({
    where: { id: registrationId },
    include: {
      user: { select: { name: true, school: true, company: true } },
      race: { select: { id: true, title: true } },
      work: { select: { id: true, title: true, description: true, status: true } },
      raceProject: {
        select: {
          caConnections: {
            where: { disabledAt: null },
            select: {
              caSessions: true,
              ridingMetrics: { select: { costSummary: true, progressSummary: true, riskSummary: true, skillSummary: true } },
            },
          },
        },
      },
      awards: {
        where: { publishedAt: { not: null } },
        select: { awardName: true, rank: true, decisionReason: true },
      },
      evidence: {
        where: { visibility: { in: ["public", "internal"] } },
        select: { type: true, title: true, summary: true },
      },
    },
  });

  if (!registration) throw new Error(`Registration ${registrationId} not found`);

  const user = registration.user;
  const race = registration.race;
  const work = registration.work;

  // 汇总数据
  const allSessions = registration.raceProject?.caConnections.flatMap((c) => c.caSessions) ?? [];
  const totalSessions = allSessions.length;
  const totalTokens = allSessions.reduce((s, r) => s + r.tokenCost, 0);
  const totalMessages = allSessions.reduce((s, r) => s + r.messageCount, 0);
  const totalToolCalls = allSessions.reduce((s, r) => s + r.toolCallCount, 0);

  // 聚合 RidingMetrics
  let avgCompletionPercent = 0;
  let metricsCount = 0;
  const allSkills: SkillSummary[] = [];
  for (const conn of registration.raceProject?.caConnections ?? []) {
    if (conn.ridingMetrics[0]) {
      const progress = safeJsonParse<{ completionPercent?: number }>(conn.ridingMetrics[0]?.progressSummary, {});
      if (typeof progress.completionPercent === "number") {
        avgCompletionPercent += progress.completionPercent;
        metricsCount++;
      }
      const skills = safeJsonParse<SkillSummary>(conn.ridingMetrics[0]?.skillSummary, {});
      if (Object.keys(skills).length > 0) allSkills.push(skills);
    }
  }
  avgCompletionPercent = metricsCount > 0 ? avgCompletionPercent / metricsCount : 0;

  // 平均技能评分
  const avgSkills: SkillSummary = {};
  if (allSkills.length > 0) {
    for (const key of ["targetDecomposition", "agentCollaboration", "correctionAbility", "technicalJudgment", "costControl", "reviewExpression"] as const) {
      const vals = allSkills.map((s) => s[key]).filter((v): v is number => typeof v === "number");
      avgSkills[key] = vals.length > 0 ? Math.round(vals.reduce((a, b) => a + b, 0) / vals.length) : undefined;
    }
  }

  // 获取评审记录
  const judgingRecords = registration.work
    ? await prisma.judgingRecord.findMany({
        where: {
          assignment: { workId: registration.work.id },
          status: "submitted",
        },
        select: {
          scoreResult: true,
          scoreRiding: true,
          comments: true,
        },
      })
    : [];

  const avgScoreResult = judgingRecords.length > 0
    ? (judgingRecords.reduce((s, r) => s + (r.scoreResult ?? 0), 0) / judgingRecords.length).toFixed(1)
    : null;
  const avgScoreRiding = judgingRecords.length > 0
    ? (judgingRecords.reduce((s, r) => s + (r.scoreRiding ?? 0), 0) / judgingRecords.length).toFixed(1)
    : null;

  const lines: string[] = [
    `# 选手报告 - ${user.name || "匿名 Rider"}`,
    "",
    "## 基本信息",
    `- 赛事: ${race.title}`,
    `- 学校/单位: ${user.school || user.company || "未填写"}`,
    `- 作品: ${work?.title ?? "未提交"}`,
    "",
    "## 骑行表现",
    `- 总 Session 数: ${totalSessions}`,
    `- 总消息数: ${totalMessages}`,
    `- 总工具调用数: ${totalToolCalls}`,
    `- Token 消耗: ${totalTokens.toLocaleString()}`,
    `- 平均进度: ${Math.round(avgCompletionPercent)}%`,
    avgScoreResult ? `- 作品评分: ${avgScoreResult}/10` : null,
    avgScoreRiding ? `- 骑行评分: ${avgScoreRiding}/10` : null,
    "",
  ].filter((l) => l !== null) as string[];

  // 能力评估
  lines.push("## 能力评估");
  if (Object.keys(avgSkills).length > 0) {
    const labels: Record<string, string> = {
      targetDecomposition: "目标拆解",
      agentCollaboration: "Agent 协同",
      correctionAbility: "纠偏能力",
      technicalJudgment: "技术判断",
      costControl: "成本控制",
      reviewExpression: "复盘表达",
    };
    for (const [key, label] of Object.entries(labels)) {
      const v = avgSkills[key as keyof SkillSummary];
      if (typeof v === "number") {
        lines.push(`- ${label}: ${v}/10`);
      }
    }
  } else {
    lines.push("暂无能力评估数据。");
  }

  // 获奖情况
  lines.push("", "## 获奖情况");
  if (registration.awards.length > 0) {
    for (const a of registration.awards) {
      lines.push(`- ${a.awardName} 第 ${a.rank} 名${a.decisionReason ? `: ${a.decisionReason}` : ""}`);
    }
  } else {
    lines.push("暂无获奖记录。");
  }

  // 评语
  if (judgingRecords.length > 0) {
    lines.push("", "## 评委反馈");
    for (const r of judgingRecords) {
      if (r.comments) {
        lines.push(`> ${r.comments}`, "");
      }
    }
  }

  // 证据
  if (registration.evidence.length > 0) {
    lines.push("", "## 证据摘要");
    for (const e of registration.evidence) {
      lines.push(`- **${e.title}** (${e.type})${e.summary ? `: ${e.summary}` : ""}`);
    }
  }

  lines.push("", "---", `*报告自动生成于 ${new Date().toISOString()}*`);

  const content = lines.join("\n");

  // 写入 Report 表
  const existing = await prisma.report.findFirst({
    where: {
      raceId: race.id,
      type: "rider_report",
      subjectRegistrationId: registrationId,
    },
  });

  if (existing) {
    await prisma.report.update({
      where: { id: existing.id },
      data: { content, generatedAt: new Date(), status: "generated" },
    });
  } else {
    await prisma.report.create({
      data: {
        raceId: race.id,
        type: "rider_report",
        subjectRegistrationId: registrationId,
        content,
        status: "generated",
        generatedAt: new Date(),
      },
    });
  }

  return content;
}

/**
 * 生成赛事总报告。
 */
export async function generateRaceReport(raceId: string): Promise<string> {
  const race = await prisma.race.findUnique({
    where: { id: raceId },
    include: {
      registrations: {
        where: { status: "approved" },
        include: {
          user: { select: { name: true } },
          work: { select: { title: true, status: true, visibility: true } },
        },
      },
      awards: {
        where: { publishedAt: { not: null } },
        orderBy: [{ awardName: "asc" }, { rank: "asc" }],
        select: {
          awardName: true,
          rank: true,
          decisionReason: true,
          registration: { select: { user: { select: { name: true } } } },
          work: { select: { title: true } },
        },
      },
      projections: {
        where: { type: "race_progress" },
        orderBy: { lastRebuiltAt: "desc" },
        take: 1,
        select: { data: true },
      },
    },
  });

  if (!race) throw new Error(`Race ${raceId} not found`);

  const projection = race.projections[0]
    ? safeJsonParse<Record<string, unknown>>(race.projections[0].data, {})
    : {};

  const submittedWorks = race.registrations.filter(
    (r) => r.work && ["submitted", "locked"].includes(r.work.status),
  );
  const publicWorks = submittedWorks.filter((r) => r.work?.visibility === "public");

  const lines: string[] = [
    `# 赛事报告 - ${race.title}`,
    "",
    "## 赛事概览",
    `- 参赛人数: ${race.registrations.length}`,
    `- 提交作品: ${submittedWorks.length}`,
    `- 公开作品: ${publicWorks.length}`,
  ];

  // Projection 数据
  if (Object.keys(projection).length > 0) {
    lines.push(
      `- 活跃骑手: ${projection.activeRiders ?? "—"}`,
      `- 总 Session 数: ${projection.sessionsStarted ?? "—"}`,
      `- 平均进度: ${projection.averageProgress !== undefined ? projection.averageProgress + "%" : "—"}`,
      `- 总 Token: ${projection.totalTokens?.toLocaleString?.() ?? "—"}`,
      `- 高风险骑手: ${projection.highRiskRiders ?? "—"}`,
    );
  }

  // 获奖榜单
  lines.push("", "## 奖项榜单");
  if (race.awards.length > 0) {
    const byCategory = new Map<string, typeof race.awards>();
    for (const a of race.awards) {
      const list = byCategory.get(a.awardName) || [];
      list.push(a);
      byCategory.set(a.awardName, list);
    }
    byCategory.forEach((awards, name) => {
      lines.push(`### ${name}`, "");
      for (const a of awards) {
        const riderName = a.registration.user.name || "匿名";
        const workTitle = a.work?.title ?? "—";
        lines.push(`- 🏅 第 ${a.rank} 名: **${riderName}** - ${workTitle}${a.decisionReason ? ` (${a.decisionReason})` : ""}`);
      }
      lines.push("");
    });
  } else {
    lines.push("暂无已发布奖项。");
  }

  // 作品列表
  lines.push("## 作品列表");
  if (publicWorks.length > 0) {
    for (const r of publicWorks) {
      lines.push(`- **${r.work!.title}** by ${r.user.name || "匿名"}`);
    }
  } else {
    lines.push("暂无公开作品。");
  }

  lines.push("", "## 关键发现", "");
  lines.push("1. 赛事整体参赛情况良好");
  lines.push("2. AI 辅助开发已成为参赛者的主要工作方式");
  lines.push("3. 骑行过程数据为评审提供了重要参考维度");

  lines.push("", "---", `*报告自动生成于 ${new Date().toISOString()}*`);

  const content = lines.join("\n");

  const existing = await prisma.report.findFirst({
    where: { raceId, type: "race_report" },
  });

  if (existing) {
    await prisma.report.update({
      where: { id: existing.id },
      data: { content, generatedAt: new Date(), status: "generated" },
    });
  } else {
    await prisma.report.create({
      data: {
        raceId,
        type: "race_report",
        content,
        status: "generated",
        generatedAt: new Date(),
      },
    });
  }

  return content;
}

/**
 * 生成评审总结。
 */
export async function generateReviewSummary(raceId: string): Promise<string> {
  const race = await prisma.race.findUnique({
    where: { id: raceId },
    select: { id: true, title: true },
  });
  if (!race) throw new Error(`Race ${raceId} not found`);

  const [judgingRecords, awards] = await Promise.all([
    prisma.judgingRecord.findMany({
      where: {
        status: "submitted",
        assignment: { work: { registration: { raceId, status: "approved" } } },
      },
      select: {
        scoreResult: true,
        scoreRiding: true,
        comments: true,
        assignment: {
          select: {
            judge: { select: { name: true } },
            work: { select: { title: true } },
          },
        },
      },
    }),
    prisma.award.findMany({
      where: { raceId, publishedAt: { not: null } },
      orderBy: [{ awardName: "asc" }, { rank: "asc" }],
      select: {
        awardName: true,
        rank: true,
        decisionReason: true,
        registration: { select: { user: { select: { name: true } } } },
        work: { select: { title: true } },
      },
    }),
  ]);

  const totalWorks = new Set(judgingRecords.map((r) => r.assignment.work.title)).size;
  const totalJudges = new Set(judgingRecords.map((r) => r.assignment.judge.name)).size;
  const avgScoreResult = judgingRecords.length > 0
    ? (judgingRecords.reduce((s, r) => s + (r.scoreResult ?? 0), 0) / judgingRecords.length).toFixed(1)
    : null;
  const avgScoreRiding = judgingRecords.length > 0
    ? (judgingRecords.reduce((s, r) => s + (r.scoreRiding ?? 0), 0) / judgingRecords.length).toFixed(1)
    : null;

  // 精选评语（取最长的 3 条）
  const comments = judgingRecords
    .filter((r) => r.comments && r.comments.length > 30)
    .sort((a, b) => (b.comments?.length ?? 0) - (a.comments?.length ?? 0))
    .slice(0, 3);

  const lines: string[] = [
    `# 评审总结 - ${race.title}`,
    "",
    "## 评审概况",
    `- 评审作品数: ${totalWorks}`,
    `- 评委人数: ${totalJudges}`,
    `- 评审记录数: ${judgingRecords.length}`,
    avgScoreResult ? `- 平均作品评分: ${avgScoreResult}/10` : null,
    avgScoreRiding ? `- 平均骑行评分: ${avgScoreRiding}/10` : null,
    "",
  ].filter((l) => l !== null) as string[];

  // 评分分布
  lines.push("## 评分分布");
  const resultBins = { "0-3": 0, "4-6": 0, "7-8": 0, "9-10": 0 };
  for (const r of judgingRecords) {
    const s = r.scoreResult ?? 0;
    if (s <= 3) resultBins["0-3"]++;
    else if (s <= 6) resultBins["4-6"]++;
    else if (s <= 8) resultBins["7-8"]++;
    else resultBins["9-10"]++;
  }
  for (const [range, count] of Object.entries(resultBins)) {
    lines.push(`- ${range}分: ${count} 条`);
  }

  // 获奖说明
  lines.push("", "## 获奖说明");
  if (awards.length > 0) {
    const byCat = new Map<string, typeof awards>();
    for (const a of awards) {
      const list = byCat.get(a.awardName) || [];
      list.push(a);
      byCat.set(a.awardName, list);
    }
    byCat.forEach((items, name) => {
      lines.push(`### ${name}`);
      for (const a of items) {
        lines.push(`- 第 ${a.rank} 名: ${a.registration.user.name} - ${a.work?.title ?? "—"}`);
      }
      lines.push("");
    });
  }

  // 评语精选
  if (comments.length > 0) {
    lines.push("## 评委评语精选");
    for (const c of comments) {
      lines.push(`> "${c.comments}"`);
      lines.push(`> — ${c.assignment.judge.name} 评《${c.assignment.work.title}》`);
      lines.push("");
    }
  }

  lines.push("## 关键洞察", "");
  lines.push("1. 参赛作品整体质量超出预期");
  lines.push("2. Agent 骑行方法论开始形成共识");
  lines.push("3. 纠偏能力是区分优秀骑手的关键指标");
  lines.push("4. 过程数据为评审提供了有价值的参考维度");

  lines.push("", "---", `*报告自动生成于 ${new Date().toISOString()}*`);

  const content = lines.join("\n");

  const existing = await prisma.report.findFirst({
    where: { raceId, type: "review_summary" },
  });

  if (existing) {
    await prisma.report.update({
      where: { id: existing.id },
      data: { content, generatedAt: new Date(), status: "generated" },
    });
  } else {
    await prisma.report.create({
      data: {
        raceId,
        type: "review_summary",
        content,
        status: "generated",
        generatedAt: new Date(),
      },
    });
  }

  return content;
}

/**
 * 为 Race 生成全部三种 Report（每个 approved rider + race_report + review_summary）。
 */
export async function generateAllReportsForRace(raceId: string): Promise<{
  riderReports: number;
  raceReport: boolean;
  reviewSummary: boolean;
}> {
  const registrations = await prisma.registration.findMany({
    where: { raceId, status: "approved" },
    select: { id: true },
  });

  let riderReports = 0;
  for (const reg of registrations) {
    try {
      await generateRiderReport(reg.id);
      riderReports++;
    } catch (e) {
      console.error(`[report-gen] Rider report failed for ${reg.id}:`, e);
    }
  }

  let raceReport = false;
  try {
    await generateRaceReport(raceId);
    raceReport = true;
  } catch (e) {
    console.error(`[report-gen] Race report failed for ${raceId}:`, e);
  }

  let reviewSummary = false;
  try {
    await generateReviewSummary(raceId);
    reviewSummary = true;
  } catch (e) {
    console.error(`[report-gen] Review summary failed for ${raceId}:`, e);
  }

  return { riderReports, raceReport, reviewSummary };
}
