import { auth } from "./auth";
import type { Role } from "@/types";

/** Get the current user's session, or null if not authenticated. */
export async function getSession() {
  return await auth();
}

/** Get the current user's roles as a string array. Returns empty array if not logged in. */
export async function getCurrentUserRoles(): Promise<Role[]> {
  const session = await auth();
  if (!session?.user) return [];
  try {
    return (session.user as any).roles ?? [];
  } catch {
    return [];
  }
}

/** Check if the current user has at least one of the specified roles. */
export async function hasRole(...required: Role[]): Promise<boolean> {
  const roles = await getCurrentUserRoles();
  return required.some((r) => roles.includes(r));
}

/** Get the current user's database ID. */
export async function getCurrentUserId(): Promise<string | null> {
  const session = await auth();
  return session?.user?.id ?? null;
}

/** Check if the current user's profile is complete. */
export async function isProfileComplete(): Promise<boolean> {
  const session = await auth();
  return (session?.user as any)?.profileCompleted === true;
}
