/**
 * 大屏数据查询 — 第5棒 T5.4
 *
 * 从 Projection 表读取大屏展示所需数据。
 * 所有数据来自 Projection，不直接读取 CASession。
 */

import "server-only";
import { cache } from "react";
import { prisma } from "@/lib/db";
import type { ScreenMode } from "@/types";

export interface ScreenRace {
  slug: string;
  title: string;
  status: string;
}

export interface ScreenData {
  race: ScreenRace;
  mode: ScreenMode;
  projections: {
    race_progress: Record<string, unknown> | null;
    current_leaderboard: Record<string, unknown> | null;
    screen_feed: Record<string, unknown> | null;
    cost: Record<string, unknown> | null;
    risk: Record<string, unknown> | null;
  };
  announcements: {
    id: string;
    title: string;
    body: string;
    publishedAt: string;
  }[];
  /** 公开作品列表（供 Screen Works 模式使用） */
  works: {
    title: string;
    authorName: string;
    description: string;
  }[];
  /** 诊断信息 */
  diagnostics: {
    hasRace: boolean;
    hasProjections: boolean;
    hasRaceProgress: boolean;
    hasLeaderboard: boolean;
    hasScreenFeed: boolean;
    hasCost: boolean;
    hasRisk: boolean;
    hasAnnouncements: boolean;
    /** 损坏的 projection 类型（JSON 解析失败） */
    corruptedTypes: string[];
    /** 该 race 下是否有已批准的 registration */
    hasApprovedRiders: boolean;
    /** 该 race 下是否有活跃的 CAConnection */
    hasActiveCAConnections: boolean;
    /** 该 race 下所有 CAConnection 的 aggregateIngestionStatus */
    caConnectionSummary: string[];
  };
}

export const getScreenData = cache(async (slug: string): Promise<ScreenData | null> => {
  const race = await prisma.race.findFirst({
    where: { slug, visibility: "public" },
    select: { id: true, slug: true, title: true, status: true },
  });
  if (!race) return null;

  const [projections, announcements, registrations, connections, works] = await Promise.all([
    prisma.projection.findMany({
      where: {
        raceId: race.id,
        type: {
          in: ["race_progress", "current_leaderboard", "screen_feed", "cost", "risk"],
        },
      },
      orderBy: { lastRebuiltAt: "desc" },
      select: { type: true, data: true },
    }),
    prisma.announcement.findMany({
      where: { raceId: race.id, visibility: "public" },
      orderBy: { publishedAt: "desc" },
      take: 5,
      select: { id: true, title: true, body: true, publishedAt: true },
    }),
    prisma.registration.findMany({
      where: { raceId: race.id, status: "approved" },
      select: { id: true },
    }),
    prisma.cAConnection.findMany({
      where: {
        disabledAt: null,
        raceProject: { registration: { raceId: race.id, status: "approved" } },
      },
      select: { ingestionStatus: true },
    }),
    prisma.work.findMany({
      where: {
        visibility: "public",
        status: { in: ["submitted", "locked"] },
        registration: { raceId: race.id, status: "approved" },
      },
      select: {
        title: true,
        description: true,
        registration: { select: { user: { select: { name: true } } } },
      },
      take: 10,
    }),
  ]);

  const projectionMap: ScreenData["projections"] = {
    race_progress: null,
    current_leaderboard: null,
    screen_feed: null,
    cost: null,
    risk: null,
  };

  const corruptedTypes: string[] = [];

  for (const p of projections) {
    try {
      projectionMap[p.type as keyof ScreenData["projections"]] = JSON.parse(p.data);
    } catch {
      // JSON 解析失败 → 标记为损坏
      corruptedTypes.push(p.type);
      projectionMap[p.type as keyof ScreenData["projections"]] = null;
    }
  }

  const caStatuses = connections.map((c) => c.ingestionStatus);

  return {
    race: {
      slug: race.slug,
      title: race.title,
      status: race.status,
    },
    mode: "jumbotron", // default, overridden by query param client-side
    projections: projectionMap,
    announcements: announcements.map((a) => ({
      id: a.id,
      title: a.title,
      body: a.body,
      publishedAt: a.publishedAt.toISOString(),
    })),
    works: works.map((w) => ({
      title: w.title,
      authorName: w.registration.user.name || "匿名 Rider",
      description: w.description,
    })),
    diagnostics: {
      hasRace: true,
      hasProjections: projections.length > 0,
      hasRaceProgress: projectionMap.race_progress !== null,
      hasLeaderboard: projectionMap.current_leaderboard !== null,
      hasScreenFeed: projectionMap.screen_feed !== null,
      hasCost: projectionMap.cost !== null,
      hasRisk: projectionMap.risk !== null,
      hasAnnouncements: announcements.length > 0,
      corruptedTypes,
      hasApprovedRiders: registrations.length > 0,
      hasActiveCAConnections: caStatuses.some(
        (s) => s === "active" || s === "connected",
      ),
      caConnectionSummary: caStatuses,
    },
  };
});

/** 获取用户可管理的 Race 列表（用于 Screen Console 选择器） */
export async function getManagedRacesForScreen(userId: string): Promise<ScreenRace[]> {
  // Admin 看全部公开 Race
  const user = await prisma.user.findUnique({
    where: { id: userId },
    select: { roles: true },
  });
  const roles: string[] = user ? safeParse(user.roles) : [];

  if (roles.includes("admin")) {
    const races = await prisma.race.findMany({
      where: { visibility: "public" },
      select: { slug: true, title: true, status: true },
      orderBy: { updatedAt: "desc" },
    });
    return races;
  }

  // Organizer 看自己管理的 Race
  const races = await prisma.race.findMany({
    where: { organizerId: userId, visibility: "public" },
    select: { slug: true, title: true, status: true },
    orderBy: { updatedAt: "desc" },
  });
  return races;
}

function safeParse(rolesJson: string): string[] {
  try {
    return JSON.parse(rolesJson);
  } catch {
    return [];
  }
}
