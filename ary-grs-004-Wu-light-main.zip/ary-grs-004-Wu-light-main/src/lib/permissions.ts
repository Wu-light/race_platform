/**
 * ARY MVP Permission System.
 *
 * Based on docs/ary-permission-matrix.md. Each function checks whether the
 * current user is authorized to perform an action on a resource.
 *
 * Usage in an API route or Server Component:
 *   const userId = await requireAuth();           // throws if not logged in
 *   await requireRole("admin");                    // throws if missing role
 *   await requireOrganizerOfRace(raceId);           // throws if not organizer
 *   await requireOwnRegistration(registrationId);  // throws if not owner
 */

import { auth } from "./auth";
import { prisma } from "./db";
import type { Role } from "@/types";

// ---- Errors ----

export class PermissionError extends Error {
  constructor(
    message: string,
    public statusCode: number = 403,
  ) {
    super(message);
    this.name = "PermissionError";
  }
}

// ---- Base checks ----

/** Ensure user is logged in. Returns the user's database ID. */
export async function requireAuth(): Promise<string> {
  const session = await auth();
  if (!session?.user?.id) {
    throw new PermissionError("请先登录", 401);
  }
  return session.user.id;
}

/** Ensure current user has at least one of the given roles. */
export async function requireRole(...roles: Role[]): Promise<string> {
  const userId = await requireAuth();
  const user = await prisma.user.findUnique({
    where: { id: userId },
    select: { roles: true },
  });
  if (!user) throw new PermissionError("用户不存在", 404);

  let userRoles: string[] = [];
  try {
    userRoles = JSON.parse(user.roles);
  } catch { /* empty */ }

  const hasMatch = roles.some((r) => userRoles.includes(r));
  if (!hasMatch) {
    throw new PermissionError(
      `需要以下角色之一: ${roles.join(", ")}`,
      403,
    );
  }
  return userId;
}

// ---- Resource-specific checks ----

/** Ensure the current user is the organizer of the given race. */
export async function requireOrganizerOfRace(raceId: string): Promise<string> {
  const userId = await requireAuth();
  const race = await prisma.race.findUnique({
    where: { id: raceId },
    select: { organizerId: true },
  });
  if (!race) throw new PermissionError("赛事不存在", 404);

  // Admin can also manage
  const user = await prisma.user.findUnique({
    where: { id: userId },
    select: { roles: true },
  });
  const userRoles: string[] = user ? safeParseRoles(user.roles) : [];

  if (race.organizerId !== userId && !userRoles.includes("admin")) {
    throw new PermissionError("只有赛事主办方或管理员可以执行此操作", 403);
  }
  return userId;
}

/** Ensure the current user owns the given registration. */
export async function requireOwnRegistration(registrationId: string): Promise<string> {
  const userId = await requireAuth();
  const reg = await prisma.registration.findUnique({
    where: { id: registrationId },
    select: { userId: true },
  });
  if (!reg) throw new PermissionError("报名记录不存在", 404);
  if (reg.userId !== userId) {
    throw new PermissionError("只能管理自己的报名记录", 403);
  }
  return userId;
}

/** Ensure the current user is assigned as judge for the given work. */
export async function requireJudgeAssignedToWork(workId: string): Promise<string> {
  const userId = await requireAuth();
  const assignment = await prisma.judgeAssignment.findFirst({
    where: { workId, judgeId: userId },
  });
  if (!assignment) {
    throw new PermissionError("你没有被分配评审此作品", 403);
  }
  return userId;
}

/** Ensure the current user is the assigned judge for the given judging record. */
export async function requireOwnJudgingRecord(judgingRecordId: string): Promise<string> {
  const userId = await requireAuth();
  const record = await prisma.judgingRecord.findUnique({
    where: { id: judgingRecordId },
    include: {
      assignment: { select: { judgeId: true } },
    },
  });
  if (!record) throw new PermissionError("评审记录不存在", 404);
  if (record.assignment.judgeId !== userId) {
    throw new PermissionError("只能管理自己的评审记录", 403);
  }
  return userId;
}

// ---- Race-scoped resource checks (T3.4) ----

/** Ensure current user has an approved registration for the given race. */
export async function requireRiderForRace(raceId: string): Promise<string> {
  const userId = await requireAuth();
  const reg = await prisma.registration.findFirst({
    where: { raceId, userId, status: "approved" },
  });
  if (!reg) {
    throw new PermissionError("你不是该赛事的已批准参赛者", 403);
  }
  return userId;
}

/** Ensure current user has a judge assignment for any work in the given race. */
export async function requireJudgeForRace(raceId: string): Promise<string> {
  const userId = await requireAuth();
  const assignment = await prisma.judgeAssignment.findFirst({
    where: {
      judgeId: userId,
      work: { registration: { raceId } },
    },
  });
  if (!assignment) {
    throw new PermissionError("你没有被分配评审该赛事的作品", 403);
  }
  return userId;
}

// ---- Utility queries ----

/** Get races managed by the current user (as organizer). */
export async function getManagedRaceIds(userId: string): Promise<string[]> {
  const races = await prisma.race.findMany({
    where: { organizerId: userId },
    select: { id: true },
  });
  return races.map((r) => r.id);
}

/** Check if the given user has a specific role. */
export function userHasRole(rolesJson: string, role: Role): boolean {
  try {
    const roles: string[] = JSON.parse(rolesJson);
    return roles.includes(role);
  } catch {
    return false;
  }
}

/** Safely parse roles JSON string to array. */
export function safeParseRoles(rolesJson: string): string[] {
  try {
    return JSON.parse(rolesJson);
  } catch {
    return [];
  }
}

/** Parse user roles from JSON string and return as typed array. */
export function getUserRoles(rolesJson: string): Role[] {
  const raw = safeParseRoles(rolesJson);
  const validRoles: Role[] = ["rider", "judge", "organizer", "admin"];
  return raw.filter((r): r is Role => validRoles.includes(r as Role));
}
