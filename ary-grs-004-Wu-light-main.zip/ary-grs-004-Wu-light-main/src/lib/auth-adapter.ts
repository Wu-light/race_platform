import { PrismaAdapter } from "@auth/prisma-adapter";
import type { Adapter } from "next-auth/adapters";
import { prisma } from "./db";

/**
 * Wrap PrismaAdapter to translate NextAuth's standard `image` field to our schema's `avatar` field.
 *
 * Background: First relay's User schema uses `avatar` (domain naming), but NextAuth's
 * PrismaAdapter expects NextAuth's standard field names (e.g. `image`). Without this
 * mapping, `prisma.user.create` fails with `Unknown argument 'image'`.
 *
 * This wrapper is the minimum-invasive fix: zero schema change, zero migration.
 */
export function authAdapter(): Adapter {
  const base = PrismaAdapter(prisma) as any;
  return {
    ...base,
    async createUser(user: any) {
      const { image, ...rest } = user;
      return base.createUser({
        ...rest,
        avatar: image ?? null,
      });
    },
    async updateUser(user: any) {
      const { image, ...rest } = user;
      return base.updateUser({
        ...rest,
        ...(image !== undefined ? { avatar: image } : {}),
      });
    },
  };
}
