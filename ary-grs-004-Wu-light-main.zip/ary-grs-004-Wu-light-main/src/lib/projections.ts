/**
 * Projection 聚合生成逻辑 — 第5棒 T5.2
 *
 * 从 CASession、RidingMetrics、Registration、Work 等事实数据
 * 聚合生成各种类型的 Projection。Projection 失败不污染源数据。
 */

import { prisma } from "@/lib/db";

// ---- 辅助 ----

function safeJsonParse<T>(value: string, fallback: T): T {
  try {
    return JSON.parse(value) as T;
  } catch {
    return fallback;
  }
}

function jsonString(obj: unknown): string {
  return JSON.stringify(obj);
}

// ---- Race Progress Projection ----

interface RaceProgressData {
  totalRiders: number;
  activeRiders: number;
  sessionsStarted: number;
  worksSubmitted: number;
  averageProgress: number;
  totalTokens: number;
  totalCost: number;
  highRiskRiders: number;
}

async function generateRaceProgress(raceId: string): Promise<void> {
  const registrations = await prisma.registration.findMany({
    where: { raceId, status: "approved" },
    select: {
      id: true,
      raceProject: {
        select: {
          aggregateIngestionStatus: true,
          caConnections: {
            where: { disabledAt: null },
            select: {
              id: true,
              ingestionStatus: true,
              caSessions: { select: { tokenCost: true } },
              ridingMetrics: { select: { progressSummary: true, riskSummary: true } },
            },
          },
        },
      },
      work: { select: { status: true } },
    },
  });

  const totalRiders = registrations.length;

  let activeRiders = 0;
  let sessionsStarted = 0;
  let totalTokens = 0;
  let totalCost = 0;
  let highRiskRiders = 0;
  const progressValues: number[] = [];

  for (const reg of registrations) {
    const rp = reg.raceProject;
    if (!rp) continue;

    const isActive = rp.aggregateIngestionStatus === "active" || rp.aggregateIngestionStatus === "connected";
    if (isActive) activeRiders++;

    for (const conn of rp.caConnections) {
      sessionsStarted += conn.caSessions.length;
      for (const s of conn.caSessions) {
        totalTokens += s.tokenCost;
      }

      if (conn.ridingMetrics[0]) {
        const progress = safeJsonParse<{ completionPercent?: number }>(
          conn.ridingMetrics[0].progressSummary,
          {},
        );
        if (typeof progress.completionPercent === "number") {
          progressValues.push(progress.completionPercent);
        }
        const risk = safeJsonParse<{ level?: string }>(
          conn.ridingMetrics[0].riskSummary,
          {},
        );
        if (risk.level === "high") highRiskRiders++;
      }
    }
  }

  // 去重：一个 Rider 可能有多条 connection，按 Rider 计 highRiskRiders
  const uniqueHighRiskRiders = new Set<string>();
  for (const reg of registrations) {
    const rp = reg.raceProject;
    if (!rp) continue;
    for (const conn of rp.caConnections) {
      if (conn.ridingMetrics[0]) {
        const risk = safeJsonParse<{ level?: string }>(conn.ridingMetrics[0].riskSummary, {});
        if (risk.level === "high") {
          uniqueHighRiskRiders.add(reg.id);
        }
      }
    }
  }

  totalCost = parseFloat((totalTokens * 0.000015).toFixed(2));

  const averageProgress = progressValues.length > 0
    ? Math.round(progressValues.reduce((a, b) => a + b, 0) / progressValues.length)
    : 0;

  const worksSubmitted = registrations.filter(
    (r) => r.work && ["submitted", "locked"].includes(r.work.status),
  ).length;

  const data: RaceProgressData = {
    totalRiders,
    activeRiders,
    sessionsStarted,
    worksSubmitted,
    averageProgress,
    totalTokens: Math.round(totalTokens),
    totalCost,
    highRiskRiders: uniqueHighRiskRiders.size,
  };

  await prisma.projection.upsert({
    where: { id: await findProjectionId(raceId, "race_progress") ?? "new" },
    create: {
      raceId,
      type: "race_progress",
      data: jsonString(data),
      lastRebuiltAt: new Date(),
    },
    update: {
      data: jsonString(data),
      lastRebuiltAt: new Date(),
    },
  });
}

async function findProjectionId(raceId: string, type: string): Promise<string | null> {
  const p = await prisma.projection.findFirst({
    where: { raceId, type },
    select: { id: true },
  });
  return p?.id ?? null;
}

// ---- Current Leaderboard Projection ----

interface LeaderboardEntry {
  riderName: string;
  progress: number;
  cost: number;
  risk: "low" | "medium" | "high";
}

interface LeaderboardData {
  rankings: LeaderboardEntry[];
}

async function generateCurrentLeaderboard(raceId: string): Promise<void> {
  const registrations = await prisma.registration.findMany({
    where: { raceId, status: "approved" },
    select: {
      user: { select: { name: true } },
      raceProject: {
        select: {
          caConnections: {
            where: { disabledAt: null },
            select: {
              caSessions: { select: { tokenCost: true } },
              ridingMetrics: { select: { progressSummary: true, riskSummary: true, costSummary: true } },
            },
          },
        },
      },
    },
  });

  const rankings: LeaderboardEntry[] = [];

  for (const reg of registrations) {
    const rp = reg.raceProject;
    if (!rp) continue;

    let totalProgress = 0;
    let totalCost = 0;
    let progressCount = 0;
    let worstRisk: "low" | "medium" | "high" = "low";

    for (const conn of rp.caConnections) {
      for (const s of conn.caSessions) {
        totalCost += s.tokenCost;
      }

      if (conn.ridingMetrics[0]) {
        const progress = safeJsonParse<{ completionPercent?: number }>(
          conn.ridingMetrics[0].progressSummary,
          {},
        );
        if (typeof progress.completionPercent === "number") {
          totalProgress += progress.completionPercent;
          progressCount++;
        }
        const risk = safeJsonParse<{ level?: string }>(conn.ridingMetrics[0].riskSummary, {});
        if (risk.level === "high") worstRisk = "high";
        else if (risk.level === "medium" && worstRisk === "low") worstRisk = "medium";
      }
    }

    if (progressCount > 0) {
      rankings.push({
        riderName: reg.user.name || "匿名 Rider",
        progress: Math.min(100, totalProgress / progressCount),
        cost: parseFloat((totalCost * 0.000015).toFixed(2)),
        risk: worstRisk,
      });
    }
  }

  // 按进度降序排列
  rankings.sort((a, b) => b.progress - a.progress);

  const data: LeaderboardData = { rankings };

  const existingId = await findProjectionId(raceId, "current_leaderboard");
  if (existingId) {
    await prisma.projection.update({
      where: { id: existingId },
      data: { data: jsonString(data), lastRebuiltAt: new Date() },
    });
  } else {
    await prisma.projection.create({
      data: {
        raceId,
        type: "current_leaderboard",
        data: jsonString(data),
        lastRebuiltAt: new Date(),
      },
    });
  }
}

// ---- Cost Projection ----

async function generateCostProjection(raceId: string): Promise<void> {
  const registrations = await prisma.registration.findMany({
    where: { raceId, status: "approved" },
    select: {
      user: { select: { name: true } },
      raceProject: {
        select: {
          caConnections: {
            where: { disabledAt: null },
            select: {
              caSessions: { select: { tokenCost: true } },
              ridingMetrics: { select: { costSummary: true } },
            },
          },
        },
      },
    },
  });

  const riderCosts: { riderName: string; tokenCost: number; usdCost: number }[] = [];
  let totalTokens = 0;

  for (const reg of registrations) {
    const rp = reg.raceProject;
    if (!rp) continue;

    let riderTokens = 0;
    for (const conn of rp.caConnections) {
      for (const s of conn.caSessions) {
        riderTokens += s.tokenCost;
      }
    }
    if (riderTokens > 0) {
      totalTokens += riderTokens;
      riderCosts.push({
        riderName: reg.user.name || "匿名 Rider",
        tokenCost: Math.round(riderTokens),
        usdCost: parseFloat((riderTokens * 0.000015).toFixed(2)),
      });
    }
  }

  riderCosts.sort((a, b) => b.tokenCost - a.tokenCost);

  const data = {
    totalTokenCost: Math.round(totalTokens),
    totalUsdCost: parseFloat((totalTokens * 0.000015).toFixed(2)),
    averageTokenCost: riderCosts.length > 0
      ? Math.round(totalTokens / riderCosts.length)
      : 0,
    perRider: riderCosts,
  };

  const existingId = await findProjectionId(raceId, "cost");
  if (existingId) {
    await prisma.projection.update({
      where: { id: existingId },
      data: { data: jsonString(data), lastRebuiltAt: new Date() },
    });
  } else {
    await prisma.projection.create({
      data: {
        raceId,
        type: "cost",
        data: jsonString(data),
        lastRebuiltAt: new Date(),
      },
    });
  }
}

// ---- Risk Projection ----

async function generateRiskProjection(raceId: string): Promise<void> {
  const registrations = await prisma.registration.findMany({
    where: { raceId, status: "approved" },
    select: {
      user: { select: { name: true } },
      raceProject: {
        select: {
          caConnections: {
            where: { disabledAt: null },
            select: {
              ridingMetrics: { select: { riskSummary: true, progressSummary: true } },
            },
          },
        },
      },
    },
  });

  let lowCount = 0;
  let mediumCount = 0;
  let highCount = 0;
  const highRiskDetails: { riderName: string; signals: string[]; progress: number }[] = [];

  for (const reg of registrations) {
    const rp = reg.raceProject;
    if (!rp) continue;

    for (const conn of rp.caConnections) {
      if (conn.ridingMetrics[0]) {
        const risk = safeJsonParse<{ level?: string; signals?: string[] }>(
          conn.ridingMetrics[0].riskSummary,
          {},
        );
        const progress = safeJsonParse<{ completionPercent?: number }>(
          conn.ridingMetrics[0].progressSummary,
          {},
        );

        if (risk.level === "high") {
          highCount++;
          highRiskDetails.push({
            riderName: reg.user.name || "匿名 Rider",
            signals: risk.signals || [],
            progress: progress.completionPercent ?? 0,
          });
        } else if (risk.level === "medium") {
          mediumCount++;
        } else {
          lowCount++;
        }
      }
    }
  }

  const data = {
    summary: { low: lowCount, medium: mediumCount, high: highCount, total: lowCount + mediumCount + highCount },
    highRiskDetails,
  };

  const existingId = await findProjectionId(raceId, "risk");
  if (existingId) {
    await prisma.projection.update({
      where: { id: existingId },
      data: { data: jsonString(data), lastRebuiltAt: new Date() },
    });
  } else {
    await prisma.projection.create({
      data: {
        raceId,
        type: "risk",
        data: jsonString(data),
        lastRebuiltAt: new Date(),
      },
    });
  }
}

// ---- Screen Feed Projection ----

async function generateScreenFeed(raceId: string): Promise<void> {
  const [announcements, sessions] = await Promise.all([
    prisma.announcement.findMany({
      where: { raceId, visibility: "public" },
      orderBy: { publishedAt: "desc" },
      take: 10,
      select: { id: true, title: true, body: true, publishedAt: true },
    }),
    prisma.cASession.findMany({
      where: {
        caConnection: {
          disabledAt: null,
          raceProject: { registration: { raceId, status: "approved" } },
        },
      },
      orderBy: { startedAt: "desc" },
      take: 10,
      select: {
        id: true,
        summary: true,
        startedAt: true,
        caConnection: {
          select: {
            raceProject: {
              select: { registration: { select: { user: { select: { name: true } } } } },
            },
          },
        },
      },
    }),
  ]);

  const events: {
    id: string;
    type: "announcement" | "session";
    title: string;
    description: string;
    occurredAt: string;
  }[] = [];

  for (const a of announcements) {
    events.push({
      id: a.id,
      type: "announcement",
      title: a.title,
      description: a.body,
      occurredAt: a.publishedAt.toISOString(),
    });
  }

  for (const s of sessions) {
    const riderName = s.caConnection.raceProject.registration.user.name || "匿名";
    const summary = safeJsonParse<{ totalMessages?: number; totalToolCalls?: number }>(s.summary, {});
    events.push({
      id: s.id,
      type: "session",
      title: `${riderName} 完成了一次骑行`,
      description: `消息: ${summary.totalMessages ?? "?"}, 工具调用: ${summary.totalToolCalls ?? "?"}`,
      occurredAt: s.startedAt.toISOString(),
    });
  }

  events.sort((a, b) => new Date(b.occurredAt).getTime() - new Date(a.occurredAt).getTime());

  const data = { events: events.slice(0, 20) };

  const existingId = await findProjectionId(raceId, "screen_feed");
  if (existingId) {
    await prisma.projection.update({
      where: { id: existingId },
      data: { data: jsonString(data), lastRebuiltAt: new Date() },
    });
  } else {
    await prisma.projection.create({
      data: {
        raceId,
        type: "screen_feed",
        data: jsonString(data),
        lastRebuiltAt: new Date(),
      },
    });
  }
}

// ---- 聚合入口 ----

export interface RebuildResult {
  types: string[];
  rebuiltAt: string;
  failed: string[];
}

/**
 * 重建指定 Race 的所有 Projection。
 * 每种类型独立 try/catch，单类型失败不影响其他类型。
 */
export async function rebuildAllProjections(raceId: string): Promise<RebuildResult> {
  const types: string[] = [];
  const failed: string[] = [];

  const tasks: { type: string; fn: () => Promise<void> }[] = [
    { type: "race_progress", fn: () => generateRaceProgress(raceId) },
    { type: "current_leaderboard", fn: () => generateCurrentLeaderboard(raceId) },
    { type: "cost", fn: () => generateCostProjection(raceId) },
    { type: "risk", fn: () => generateRiskProjection(raceId) },
    { type: "screen_feed", fn: () => generateScreenFeed(raceId) },
  ];

  for (const task of tasks) {
    try {
      await task.fn();
      types.push(task.type);
    } catch (error) {
      console.error(`[projections] ${task.type} failed:`, error);
      failed.push(task.type);
    }
  }

  return {
    types,
    rebuiltAt: new Date().toISOString(),
    failed,
  };
}
