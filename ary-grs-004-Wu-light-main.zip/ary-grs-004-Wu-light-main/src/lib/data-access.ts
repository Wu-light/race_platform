import "server-only";

import { cache } from "react";
import { Prisma } from "@prisma/client";
import { z } from "zod";
import { prisma } from "@/lib/db";
import { normalizeRaceStatus } from "@/lib/race-utils";
import type {
  HomeGalleryData,
  PublicAwardSummary,
  PublicEvidenceSummary,
  PublicLiveHallData,
  PublicRaceDetail,
  PublicRaceMetrics,
  PublicRaceResults,
  PublicRaceReview,
  PublicRaceSchedule,
  PublicRaceSummary,
  PublicRiderDetail,
  PublicRiderSummary,
  PublicSubmissionRequirements,
  PublicWorkDetail,
  PublicWorkSummary,
  PublicWorksPageData,
} from "@/types/public";

const PUBLIC_RACE_STATUSES = [
  "published",
  "registration",
  "running",
  "submitting",
  "judging",
  "completed",
  "archived",
] as const;

const PUBLIC_WORK_STATUSES = ["submitted", "locked"] as const;
const RESULT_RACE_STATUSES = new Set(["completed", "archived"]);

const scheduleSchema = z
  .object({
    registrationStart: z.string().max(64).optional(),
    registrationEnd: z.string().max(64).optional(),
    raceStart: z.string().max(64).optional(),
    raceEnd: z.string().max(64).optional(),
    submissionDeadline: z.string().max(64).optional(),
    judgingEnd: z.string().max(64).optional(),
  })
  .strict();

const submissionRequirementsSchema = z
  .object({
    fields: z.array(z.string().min(1).max(80)).max(20).default([]),
    format: z.string().max(80).optional(),
    description: z.string().max(1000).optional(),
    note: z.string().max(500).optional(),
  })
  .strict();

const awardSettingsSchema = z.array(z.string().min(1).max(80)).max(20);

const raceProgressSchema = z
  .object({
    totalRiders: z.number().finite().nonnegative().optional(),
    activeRiders: z.number().finite().nonnegative().optional(),
    sessionsStarted: z.number().finite().nonnegative().optional(),
    worksSubmitted: z.number().finite().nonnegative().optional(),
    averageProgress: z.number().finite().nonnegative().optional(),
    totalCost: z.number().finite().nonnegative().optional(),
    highRiskRiders: z.number().finite().nonnegative().optional(),
    totalTokens: z.number().finite().nonnegative().optional(),
  })
  .strip();

const currentLeaderboardSchema = z
  .object({
    rankings: z
      .array(
        z
          .object({
            riderName: z.string().min(1).max(80),
            progress: z.number().finite().nonnegative(),
            cost: z.number().finite().nonnegative(),
            risk: z.enum(["low", "medium", "high"]),
          })
          .strip(),
      )
      .max(100),
  })
  .strip();

const publicEvidenceMetricsSchema = z
  .object({
    sessions: z.number().finite().nonnegative().optional(),
    totalTokens: z.number().finite().nonnegative().optional(),
    corrections: z.number().finite().nonnegative().optional(),
    progress: z.number().finite().nonnegative().optional(),
  })
  .strip();

function parseJson<T>(
  value: string,
  schema: z.ZodType<T, z.ZodTypeDef, any>,
  fallback: T,
  context: string,
): T {
  try {
    const parsed = schema.safeParse(JSON.parse(value));
    if (parsed.success) return parsed.data;
  } catch {
    // A malformed optional JSON field should not make the public page unavailable.
  }

  if (process.env.NODE_ENV !== "production") {
    console.warn(`[public-data] Invalid ${context}; using a safe fallback.`);
  }
  return fallback;
}

function safePublicUrl(value: string | null): string | null {
  if (!value) return null;
  try {
    const url = new URL(value);
    return url.protocol === "https:" || url.protocol === "http:" ? url.toString() : null;
  } catch {
    return null;
  }
}

function affiliation(user: { school: string | null; company: string | null }) {
  return user.school || user.company || null;
}

function isPublishedNow(date: Date | null) {
  return date !== null && date.getTime() <= Date.now();
}

const publicRaceInclude = {
  organizer: { select: { name: true } },
  registrations: {
    where: { status: "approved" },
    select: {
      id: true,
      work: { select: { visibility: true, status: true } },
    },
  },
  awards: {
    where: { publishedAt: { not: null } },
    orderBy: [{ awardName: "asc" }, { rank: "asc" }],
    select: {
      id: true,
      awardName: true,
      rank: true,
      decisionReason: true,
      publishedAt: true,
      registration: {
        select: { user: { select: { name: true } } },
      },
      work: {
        select: { slug: true, title: true, visibility: true, status: true },
      },
    },
  },
  reports: {
    where: {
      status: "published",
      type: { in: ["race_report", "review_summary"] },
      publishedAt: { not: null },
    },
    select: { type: true, publishedAt: true },
  },
  projections: {
    where: { type: "race_progress" },
    orderBy: { lastRebuiltAt: "desc" },
    take: 1,
    select: { data: true, lastRebuiltAt: true },
  },
  announcements: {
    where: { visibility: "public" },
    orderBy: { publishedAt: "desc" },
    take: 5,
    select: { id: true, title: true, body: true, publishedAt: true },
  },
} satisfies Prisma.RaceInclude;

type PublicRaceRecord = Prisma.RaceGetPayload<{ include: typeof publicRaceInclude }>;

const publicWorkInclude = {
  registration: {
    select: {
      status: true,
      user: {
        select: {
          id: true,
          name: true,
          avatar: true,
          bio: true,
          school: true,
          company: true,
        },
      },
      race: { select: { slug: true, title: true, challenge: true, visibility: true, status: true } },
      evidence: {
        where: { visibility: "public" },
        select: { id: true, type: true, title: true, summary: true, sourceRef: true },
      },
    },
  },
  awards: {
    where: { publishedAt: { not: null } },
    select: {
      id: true,
      awardName: true,
      rank: true,
      decisionReason: true,
      publishedAt: true,
      registration: { select: { user: { select: { name: true } } } },
      race: { select: { slug: true, title: true, status: true, visibility: true } },
    },
  },
} satisfies Prisma.WorkInclude;

type PublicWorkRecord = Prisma.WorkGetPayload<{ include: typeof publicWorkInclude }>;

function getMetrics(race: PublicRaceRecord): PublicRaceMetrics {
  const publicWorks = race.registrations.filter(
    ({ work }) =>
      work?.visibility === "public" &&
      PUBLIC_WORK_STATUSES.includes(work.status as (typeof PUBLIC_WORK_STATUSES)[number]),
  ).length;

  const projection =
    race.status === "running" && race.projections[0]
      ? parseJson(race.projections[0].data, raceProgressSchema, {}, "race_progress projection")
      : {};

  const hasProjection = Object.keys(projection).length > 0;

  const rawProgress = projection.averageProgress ?? 0;
  const averageProgress = Math.min(100, rawProgress <= 1 ? rawProgress * 100 : rawProgress);

  return {
    riders: race.registrations.length,
    activeRiders: hasProjection ? Math.round(projection.activeRiders ?? 0) : null,
    submittedWorks: Math.round(projection.worksSubmitted ?? publicWorks),
    publicWorks,
    sessionsStarted: hasProjection ? Math.round(projection.sessionsStarted ?? 0) : null,
    averageProgress: hasProjection ? Math.round(averageProgress) : null,
    totalCost: hasProjection ? Math.round((projection.totalCost ?? 0) * 100) / 100 : null,
    highRiskRiders: hasProjection ? Math.round(projection.highRiskRiders ?? 0) : null,
    totalTokens: hasProjection ? Math.round(projection.totalTokens ?? 0) : null,
  };
}

function toRaceSummary(race: PublicRaceRecord): PublicRaceSummary {
  const resultIsPublic = RESULT_RACE_STATUSES.has(race.status);
  const publishedAwards = race.awards.filter((award) => isPublishedNow(award.publishedAt));
  return {
    id: race.id,
    slug: race.slug,
    title: race.title,
    subtitle: race.subtitle,
    description: race.description,
    challenge: race.challenge,
    status: normalizeRaceStatus(race.status),
    schedule: parseJson<PublicRaceSchedule>(race.schedule, scheduleSchema, {}, "race schedule"),
    metrics: getMetrics(race),
    publishedAwardCount: resultIsPublic ? publishedAwards.length : 0,
    hasPublishedReview:
      resultIsPublic &&
      race.reports.some(
        (report) => report.type === "review_summary" && isPublishedNow(report.publishedAt),
      ),
  };
}

function toWorkSummary(work: PublicWorkRecord): PublicWorkSummary {
  const user = work.registration.user;
  return {
    id: work.id,
    slug: work.slug,
    title: work.title,
    description: work.description,
    demoUrl: safePublicUrl(work.demoUrl),
    race: {
      slug: work.registration.race.slug,
      title: work.registration.race.title,
    },
    author: {
      id: user.id,
      // User.slug does not exist yet; the stable opaque id is used as the public route segment.
      slug: user.id,
      name: user.name || "匿名 Rider",
      avatar: safePublicUrl(user.avatar),
      affiliation: affiliation(user),
    },
    awards: Array.from(
      new Set(
        work.awards
          .filter(isPublicResultAward)
          .map((award) => award.awardName),
      ),
    ),
  };
}

function skillTagsFor(work: PublicWorkRecord) {
  const tags = new Set<string>();
  if (work.registration.evidence.some((evidence) => evidence.type === "session_summary")) {
    tags.add("骑行过程");
  }
  for (const award of work.awards.filter((candidate) => isPublishedNow(candidate.publishedAt))) {
    if (award.awardName.includes("领域")) tags.add("目标拆解");
    if (award.awardName.includes("复盘")) tags.add("复盘表达");
    if (award.awardName.includes("成本")) tags.add("成本控制");
    if (award.awardName.includes("纠偏")) tags.add("纠偏能力");
  }
  if (tags.size === 0) tags.add("作品交付");
  return Array.from(tags).slice(0, 3);
}

function buildRiders(workRecords: PublicWorkRecord[]): PublicRiderSummary[] {
  const riders = new Map<string, PublicRiderSummary>();

  for (const work of workRecords) {
    const summary = toWorkSummary(work);
    const current = riders.get(summary.author.id);
    if (!current) {
      riders.set(summary.author.id, {
        id: summary.author.id,
        slug: summary.author.slug,
        name: summary.author.name,
        avatar: summary.author.avatar,
        affiliation: summary.author.affiliation,
        representativeRace: summary.race.title,
        representativeWork: summary.title,
        workCount: 1,
        awardCount: work.awards.filter(isPublicResultAward).length,
        skillTags: skillTagsFor(work),
      });
      continue;
    }

    current.workCount += 1;
    current.awardCount += work.awards.filter(isPublicResultAward).length;
    current.skillTags = Array.from(
      new Set([...current.skillTags, ...skillTagsFor(work)]),
    ).slice(0, 3);
    if (work.awards.some(isPublicResultAward)) {
      current.representativeRace = summary.race.title;
      current.representativeWork = summary.title;
    }
  }

  return Array.from(riders.values()).sort(
    (a, b) => b.awardCount - a.awardCount || b.workCount - a.workCount,
  );
}

function toAwardSummary(award: PublicRaceRecord["awards"][number]): PublicAwardSummary {
  const workIsPublic =
    award.work?.visibility === "public" &&
    PUBLIC_WORK_STATUSES.includes(
      award.work.status as (typeof PUBLIC_WORK_STATUSES)[number],
    );

  return {
    id: award.id,
    name: award.awardName,
    rank: award.rank,
    reason: award.decisionReason,
    riderName: award.registration.user.name || "匿名 Rider",
    workTitle: workIsPublic ? award.work?.title ?? null : null,
    workSlug: workIsPublic ? award.work?.slug ?? null : null,
  };
}

function racePriority(status: string) {
  return {
    running: 0,
    registration: 1,
    published: 2,
    submitting: 3,
    judging: 4,
    completed: 5,
    archived: 6,
  }[status] ?? 99;
}

async function queryPublicWorks(raceId?: string) {
  return prisma.work.findMany({
    where: {
      visibility: "public",
      status: { in: [...PUBLIC_WORK_STATUSES] },
      registration: {
        status: "approved",
        ...(raceId ? { raceId } : {}),
        race: {
          visibility: "public",
          status: { in: [...PUBLIC_RACE_STATUSES] },
        },
      },
    },
    include: publicWorkInclude,
    orderBy: { updatedAt: "desc" },
  });
}

export const getHomeGalleryData = cache(async (): Promise<HomeGalleryData> => {
  const [raceRecords, workRecords] = await Promise.all([
    prisma.race.findMany({
      where: {
        visibility: "public",
        status: { in: [...PUBLIC_RACE_STATUSES] },
      },
      include: publicRaceInclude,
      orderBy: { updatedAt: "desc" },
    }),
    queryPublicWorks(),
  ]);

  const orderedRaces = [...raceRecords].sort(
    (a, b) => racePriority(a.status) - racePriority(b.status),
  );
  const races = orderedRaces.map(toRaceSummary);
  const works = workRecords.map(toWorkSummary);
  const riders = buildRiders(workRecords);
  const liveRaces = races.filter((race) => race.status === "running");
  const fallbackRaces = races.filter((race) => race.status !== "draft");
  const featured = (liveRaces.length > 0 ? liveRaces : fallbackRaces).slice(0, 3);

  const featuredRaces = featured.map((race) => {
    const work = works.find((candidate) => candidate.race.slug === race.slug) ?? works[0] ?? null;
    return {
      race,
      work,
      rider: work ? riders.find((candidate) => candidate.id === work.author.id) ?? null : null,
    };
  });

  const resultRecords = raceRecords
    .filter(
      (race) =>
        RESULT_RACE_STATUSES.has(race.status) &&
        race.awards.some((award) => isPublishedNow(award.publishedAt)),
    )
    .sort((a, b) => {
      const aDate = Math.max(
        ...a.awards.filter((award) => isPublishedNow(award.publishedAt)).map((award) => award.publishedAt!.getTime()),
      );
      const bDate = Math.max(
        ...b.awards.filter((award) => isPublishedNow(award.publishedAt)).map((award) => award.publishedAt!.getTime()),
      );
      return bDate - aDate;
    });
  const latestResultRecords = resultRecords.slice(0, 1);
  const latestResultIds = new Set(latestResultRecords.map((race) => race.id));

  return {
    featuredRaces,
    openRaces: races.filter((race) => race.status === "registration").slice(0, 3),
    latestResults: latestResultRecords.map((race) => ({
      race: toRaceSummary(race),
      topAward: race.awards.find((award) => isPublishedNow(award.publishedAt))
        ? toAwardSummary(race.awards.find((award) => isPublishedNow(award.publishedAt))!)
        : null,
    })),
    featuredWorks: works
      .sort((a, b) => b.awards.length - a.awards.length)
      .slice(0, 3),
    featuredRiders: riders.slice(0, 3),
    pastRaces: resultRecords
      .filter((race) => !latestResultIds.has(race.id))
      .map(toRaceSummary)
      .slice(0, 3),
  };
});

export const getPublicRaceBySlug = cache(
  async (slug: string): Promise<PublicRaceDetail | null> => {
    const race = await prisma.race.findFirst({
      where: {
        slug,
        visibility: "public",
        status: { in: [...PUBLIC_RACE_STATUSES] },
      },
      include: publicRaceInclude,
    });
    if (!race) return null;

    const workRecords = await queryPublicWorks(race.id);
    const works = workRecords.map(toWorkSummary);
    const summary = toRaceSummary(race);
    const resultIsPublic = RESULT_RACE_STATUSES.has(race.status);

    return {
      ...summary,
      rules: race.rules,
      awardSettings: parseJson(race.awardSettings, awardSettingsSchema, [], "award settings"),
      submissionRequirements: parseJson<PublicSubmissionRequirements>(
        race.submissionRequirements,
        submissionRequirementsSchema,
        { fields: [] },
        "submission requirements",
      ),
      organizerName: race.organizer.name || "ARY Organizer",
      announcements: race.announcements
        .filter((announcement) => announcement.publishedAt <= new Date())
        .map((announcement) => ({
          id: announcement.id,
          title: announcement.title,
          body: announcement.body,
          publishedAt: announcement.publishedAt.toISOString(),
        })),
      awards: resultIsPublic
        ? race.awards.filter((award) => isPublishedNow(award.publishedAt)).map(toAwardSummary)
        : [],
      works,
      riders: buildRiders(workRecords),
    };
  },
);

function toEvidenceSummary(evidence: {
  id: string;
  type: string;
  title: string;
  summary: string | null;
  sourceRef: string;
}): PublicEvidenceSummary {
  const metrics = parseJson(evidence.sourceRef, publicEvidenceMetricsSchema, {}, "public evidence metrics");
  return {
    id: evidence.id,
    type: evidence.type,
    title: evidence.title,
    summary: evidence.summary,
    ...(Object.keys(metrics).length > 0 ? { metrics } : {}),
  };
}

function isPublicResultAward(award: PublicWorkRecord["awards"][number]) {
  return (
    isPublishedNow(award.publishedAt) &&
    award.race.visibility === "public" &&
    RESULT_RACE_STATUSES.has(award.race.status)
  );
}

function toWorkDetail(work: PublicWorkRecord): PublicWorkDetail {
  const summary = toWorkSummary(work);
  return {
    ...summary,
    githubUrl: safePublicUrl(work.githubUrl),
    videoUrl: safePublicUrl(work.videoUrl),
    techDescription: work.techDescription,
    updatedAt: work.updatedAt.toISOString(),
    evidence: work.registration.evidence.map(toEvidenceSummary),
    awardDetails: work.awards.filter(isPublicResultAward).map((award) => ({
      id: award.id,
      name: award.awardName,
      rank: award.rank,
      reason: award.decisionReason,
      riderName: award.registration.user.name || summary.author.name,
      workTitle: summary.title,
      workSlug: summary.slug,
    })),
    raceChallenge: work.registration.race.challenge,
  };
}

export const getPublicWorksByRaceSlug = cache(
  async (slug: string): Promise<PublicWorksPageData | null> => {
    const race = await getPublicRaceBySlug(slug);
    if (!race) return null;
    return { race, works: race.works };
  },
);

export const getPublicWorkBySlug = cache(
  async (slug: string): Promise<PublicWorkDetail | null> => {
    const work = await prisma.work.findFirst({
      where: {
        slug,
        visibility: "public",
        status: { in: [...PUBLIC_WORK_STATUSES] },
        registration: {
          status: "approved",
          race: {
            visibility: "public",
            status: { in: [...PUBLIC_RACE_STATUSES] },
          },
        },
      },
      include: publicWorkInclude,
    });
    return work ? toWorkDetail(work) : null;
  },
);

export const getPublicRaceResults = cache(
  async (slug: string): Promise<PublicRaceResults | null> => {
    const race = await getPublicRaceBySlug(slug);
    if (!race || !RESULT_RACE_STATUSES.has(race.status) || race.awards.length === 0) {
      return null;
    }

    const winningSlugs = new Set(
      race.awards.flatMap((award) => (award.workSlug ? [award.workSlug] : [])),
    );
    return {
      race,
      awards: [...race.awards].sort(
        (a, b) => a.name.localeCompare(b.name, "zh-CN") || a.rank - b.rank,
      ),
      winningWorks: race.works.filter((work) => winningSlugs.has(work.slug)),
      riders: race.riders,
      hasPublishedReview: race.hasPublishedReview,
    };
  },
);

export const getPublicRaceReview = cache(
  async (slug: string): Promise<PublicRaceReview | null> => {
    const race = await getPublicRaceBySlug(slug);
    if (!race || !RESULT_RACE_STATUSES.has(race.status)) return null;

    const report = await prisma.report.findFirst({
      where: {
        raceId: race.id,
        type: "review_summary",
        status: "published",
        publishedAt: { not: null, lte: new Date() },
      },
      orderBy: { publishedAt: "desc" },
      select: { content: true, publishedAt: true },
    });
    if (!report?.publishedAt) return null;

    const workRecords = await queryPublicWorks(race.id);
    const evidence = new Map<string, PublicEvidenceSummary>();
    for (const work of workRecords) {
      for (const item of work.registration.evidence) {
        evidence.set(item.id, toEvidenceSummary(item));
      }
    }
    const evidenceItems = Array.from(evidence.values());

    return {
      race,
      content: report.content,
      publishedAt: report.publishedAt.toISOString(),
      awards: race.awards,
      featuredWorks: race.works.filter((work) => work.awards.length > 0).slice(0, 3),
      evidence: evidenceItems,
    };
  },
);

export const getPublicRiderBySlug = cache(
  async (slug: string): Promise<PublicRiderDetail | null> => {
    const workRecords = (await queryPublicWorks()).filter(
      (work) => work.registration.user.id === slug,
    );
    if (workRecords.length === 0) return null;

    const base = buildRiders(workRecords)[0];
    if (!base) return null;
    const works = workRecords.map(toWorkSummary);
    const awardRecords = await prisma.award.findMany({
      where: {
        publishedAt: { not: null },
        registration: { status: "approved", userId: slug },
        race: {
          visibility: "public",
          status: { in: ["completed", "archived"] },
        },
      },
      orderBy: [{ publishedAt: "desc" }, { rank: "asc" }],
      select: {
        id: true,
        awardName: true,
        rank: true,
        decisionReason: true,
        publishedAt: true,
        registration: { select: { user: { select: { name: true } } } },
        race: { select: { slug: true, title: true } },
        work: { select: { slug: true, title: true, visibility: true, status: true } },
      },
    });
    const awards = awardRecords
      .filter((award) => isPublishedNow(award.publishedAt))
      .map((award) => {
        const workIsPublic =
          award.work?.visibility === "public" &&
          PUBLIC_WORK_STATUSES.includes(
            award.work.status as (typeof PUBLIC_WORK_STATUSES)[number],
          );
        return {
          id: award.id,
          name: award.awardName,
          rank: award.rank,
          reason: award.decisionReason,
          riderName: award.registration.user.name || base.name,
          workTitle: workIsPublic ? award.work?.title ?? null : null,
          workSlug: workIsPublic ? award.work?.slug ?? null : null,
          raceSlug: award.race.slug,
          raceTitle: award.race.title,
        };
      });

    const evidence = new Map<string, PublicEvidenceSummary>();
    for (const work of workRecords) {
      for (const item of work.registration.evidence) {
        evidence.set(item.id, toEvidenceSummary(item));
      }
    }
    const evidenceItems = Array.from(evidence.values());
    const metricItems = evidenceItems.flatMap((item) => (item.metrics ? [item.metrics] : []));
    const sumMetric = (key: "sessions" | "totalTokens" | "corrections") => {
      const values = metricItems.flatMap((item) =>
        typeof item[key] === "number" ? [item[key] as number] : [],
      );
      return values.length > 0 ? Math.round(values.reduce((sum, value) => sum + value, 0)) : null;
    };
    const progressValues = metricItems.flatMap((item) =>
      typeof item.progress === "number" ? [item.progress] : [],
    );
    const averageProgress =
      progressValues.length > 0
        ? Math.round(
            progressValues.reduce(
              (sum, value) => sum + Math.min(100, value <= 1 ? value * 100 : value),
              0,
            ) / progressValues.length,
          )
        : null;

    return {
      ...base,
      awardCount: awards.length,
      bio: workRecords[0].registration.user.bio,
      works,
      races: workRecords.map((work) => ({
        slug: work.registration.race.slug,
        title: work.registration.race.title,
        status: normalizeRaceStatus(work.registration.race.status),
        workTitle: work.title,
        awardNames: work.awards
          .filter(isPublicResultAward)
          .map((award) => award.awardName),
      })),
      awards,
      evidence: evidenceItems,
      performance: {
        sessions: sumMetric("sessions"),
        totalTokens: sumMetric("totalTokens"),
        corrections: sumMetric("corrections"),
        averageProgress,
        totalCost: null,
        riskSignals: null,
      },
    };
  },
);

export const getPublicLiveHall = cache(
  async (slug: string): Promise<PublicLiveHallData | null> => {
    const race = await getPublicRaceBySlug(slug);
    if (!race || race.status !== "running") return null;

    const projections = await prisma.projection.findMany({
      where: {
        raceId: race.id,
        type: { in: ["race_progress", "current_leaderboard"] },
      },
      orderBy: { lastRebuiltAt: "desc" },
      select: { id: true, type: true, data: true, lastRebuiltAt: true },
    });
    const leaderboardProjection = projections.find(
      (projection) => projection.type === "current_leaderboard",
    );
    const leaderboardData = leaderboardProjection
      ? parseJson(
          leaderboardProjection.data,
          currentLeaderboardSchema,
          { rankings: [] },
          "current leaderboard projection",
        )
      : { rankings: [] };
    const projectionUpdatedAt = projections[0]?.lastRebuiltAt ?? null;
    const leaderboard = leaderboardData.rankings.map((entry, index) => ({
      rank: index + 1,
      riderName: entry.riderName,
      progress: Math.round(Math.min(100, entry.progress <= 1 ? entry.progress * 100 : entry.progress)),
      cost: Math.round(entry.cost * 100) / 100,
      risk: entry.risk,
    }));

    const events: PublicLiveHallData["events"] = race.announcements.map((announcement) => ({
      id: announcement.id,
      type: "announcement" as const,
      title: announcement.title,
      description: announcement.body,
      occurredAt: announcement.publishedAt,
    }));
    if (projectionUpdatedAt) {
      events.push({
        id: `projection-${projections[0].id}`,
        type: "projection",
        title: "公开赛况投影已更新",
        description: `当前公开过程榜包含 ${leaderboard.length} 位 Rider；这是过程投影，不是最终赛果。`,
        occurredAt: projectionUpdatedAt.toISOString(),
      });
    }

    return {
      race,
      leaderboard,
      events: events.sort(
        (a, b) => new Date(b.occurredAt).getTime() - new Date(a.occurredAt).getTime(),
      ),
      projectionUpdatedAt: projectionUpdatedAt?.toISOString() ?? null,
    };
  },
);
