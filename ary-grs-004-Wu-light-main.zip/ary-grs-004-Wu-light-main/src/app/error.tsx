"use client";

import { useEffect } from "react";
import { AlertTriangle, RotateCcw } from "lucide-react";

export default function GlobalError({
  error,
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  useEffect(() => {
    console.error("[ARY GlobalError]", error);
  }, [error]);

  return (
    <div className="flex min-h-screen items-center justify-center bg-ary-canvas px-6">
      <div className="max-w-lg text-center">
        <AlertTriangle className="mx-auto h-14 w-14 text-amber-500" />
        <h1 className="mt-6 text-2xl font-black text-ary-blue-950">
          页面加载异常
        </h1>
        <p className="mt-3 text-sm leading-relaxed text-ary-muted">
          很抱歉，页面渲染时发生了意外错误。请尝试刷新页面。
        </p>
        <button
          onClick={reset}
          className="mt-6 inline-flex items-center gap-2 rounded-xl bg-ary-blue-800 px-6 py-3 text-sm font-bold text-white transition hover:bg-ary-blue-700"
        >
          <RotateCcw className="h-4 w-4" />
          重试
        </button>
        {process.env.NODE_ENV !== "production" && (
          <details className="mt-6 text-left">
            <summary className="cursor-pointer text-xs font-bold text-ary-muted">
              错误详情（仅开发环境可见）
            </summary>
            <pre className="mt-2 max-h-64 overflow-auto rounded-xl bg-gray-100 p-4 text-xs leading-relaxed">
              {error.message}
              {"\n"}
              {error.stack}
            </pre>
          </details>
        )}
      </div>
    </div>
  );
}
