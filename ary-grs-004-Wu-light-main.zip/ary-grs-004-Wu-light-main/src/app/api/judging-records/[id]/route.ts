import { NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import { requireOwnJudgingRecord } from "@/lib/permissions";

/** PUT /api/judging-records/[id] — update a judging record */
export async function PUT(
  request: Request,
  { params }: { params: { id: string } },
) {
  try {
    await requireOwnJudgingRecord(params.id);

    const record = await prisma.judgingRecord.findUnique({
      where: { id: params.id },
    });

    if (!record) {
      return NextResponse.json({ error: "评审记录不存在" }, { status: 404 });
    }

    // Only allow update if status is "draft"
    if (record.status !== "draft") {
      return NextResponse.json(
        { error: "只能编辑草稿状态的评审记录" },
        { status: 400 },
      );
    }

    const body = await request.json();
    const { scoreResult, scoreRiding, comments, action } = body;

    // Validate scores
    if (scoreResult !== undefined) {
      if (typeof scoreResult !== "number" || scoreResult < 1 || scoreResult > 10) {
        return NextResponse.json(
          { error: "scoreResult 必须在 1-10 之间" },
          { status: 400 },
        );
      }
    }

    if (scoreRiding !== undefined) {
      if (typeof scoreRiding !== "number" || scoreRiding < 1 || scoreRiding > 10) {
        return NextResponse.json(
          { error: "scoreRiding 必须在 1-10 之间" },
          { status: 400 },
        );
      }
    }

    const updateData: Record<string, any> = {};
    if (scoreResult !== undefined) updateData.scoreResult = scoreResult;
    if (scoreRiding !== undefined) updateData.scoreRiding = scoreRiding;
    if (comments !== undefined) updateData.comments = comments;

    // Handle submit action
    if (action === "submit") {
      updateData.status = "submitted";
      updateData.submittedAt = new Date();
    } else if (action && action !== "submit") {
      return NextResponse.json(
        { error: "action 必须为 submit" },
        { status: 400 },
      );
    }

    const updated = await prisma.judgingRecord.update({
      where: { id: params.id },
      data: updateData,
    });

    return NextResponse.json(updated);
  } catch (error: any) {
    if (error.name === "PermissionError") {
      return NextResponse.json(
        { error: error.message },
        { status: error.statusCode },
      );
    }
    console.error("PUT /api/judging-records/[id] error:", error);
    return NextResponse.json({ error: "更新评审记录失败" }, { status: 500 });
  }
}
