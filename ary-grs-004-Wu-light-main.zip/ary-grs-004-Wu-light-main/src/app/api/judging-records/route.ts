import { NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import { requireAuth } from "@/lib/permissions";

/** POST /api/judging-records — create or update a judging record */
export async function POST(request: Request) {
  try {
    const userId = await requireAuth();

    const body = await request.json();
    const { assignmentId, scoreResult, scoreRiding, comments, action } = body;

    if (!assignmentId) {
      return NextResponse.json({ error: "assignmentId 为必填项" }, { status: 400 });
    }

    // Verify the assignment exists and that the user is the assigned judge
    const assignment = await prisma.judgeAssignment.findUnique({
      where: { id: assignmentId },
      include: { judgingRecord: true },
    });

    if (!assignment) {
      return NextResponse.json({ error: "评审分配记录不存在" }, { status: 404 });
    }

    if (assignment.judgeId !== userId) {
      return NextResponse.json({ error: "你不是被分配的评审员" }, { status: 403 });
    }

    const isSubmit = action === "submit";

    // Validate scores
    if (scoreResult !== undefined && scoreResult !== null) {
      const numScore = Number(scoreResult);
      if (isNaN(numScore) || numScore < 1 || numScore > 10) {
        return NextResponse.json({ error: "作品结果评分必须在 1-10 之间" }, { status: 400 });
      }
    }
    if (isSubmit && (scoreResult === undefined || scoreResult === null)) {
      return NextResponse.json({ error: "提交时需要填写作品结果评分" }, { status: 400 });
    }

    if (scoreRiding !== undefined && scoreRiding !== null) {
      const numScore = Number(scoreRiding);
      if (isNaN(numScore) || numScore < 1 || numScore > 10) {
        return NextResponse.json({ error: "骑行能力评分必须在 1-10 之间" }, { status: 400 });
      }
    }
    if (isSubmit && (scoreRiding === undefined || scoreRiding === null)) {
      return NextResponse.json({ error: "提交时需要填写骑行能力评分" }, { status: 400 });
    }

    const recordStatus = isSubmit ? "submitted" : "draft";

    if (assignment.judgingRecord) {
      // If already submitted, don't allow further edits
      if (assignment.judgingRecord.status === "submitted") {
        return NextResponse.json({ error: "该评审记录已经提交，无法修改" }, { status: 409 });
      }

      // Update existing draft
      const updateData: Record<string, any> = {};
      if (scoreResult !== undefined) updateData.scoreResult = Number(scoreResult);
      if (scoreRiding !== undefined) updateData.scoreRiding = Number(scoreRiding);
      if (comments !== undefined) updateData.comments = comments;
      updateData.status = recordStatus;
      if (isSubmit) updateData.submittedAt = new Date();

      const updated = await prisma.judgingRecord.update({
        where: { id: assignment.judgingRecord.id },
        data: updateData,
      });

      return NextResponse.json(updated);
    }

    // Create new record
    const record = await prisma.judgingRecord.create({
      data: {
        assignmentId,
        scoreResult: scoreResult !== undefined ? Number(scoreResult) : null,
        scoreRiding: scoreRiding !== undefined ? Number(scoreRiding) : null,
        comments: comments ?? null,
        status: recordStatus,
        submittedAt: isSubmit ? new Date() : null,
      },
    });

    return NextResponse.json(record, { status: 201 });
  } catch (error: any) {
    if (error.name === "PermissionError") {
      return NextResponse.json({ error: error.message }, { status: error.statusCode });
    }
    console.error("POST /api/judging-records error:", error);
    return NextResponse.json({ error: "保存评审记录失败" }, { status: 500 });
  }
}
