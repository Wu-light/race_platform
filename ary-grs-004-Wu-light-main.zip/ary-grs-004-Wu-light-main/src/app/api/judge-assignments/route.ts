import { NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import { requireAuth, requireOrganizerOfRace } from "@/lib/permissions";

/** GET /api/judge-assignments — get assignments for current judge */
export async function GET(request: Request) {
  try {
    const userId = await requireAuth();
    const { searchParams } = new URL(request.url);
    const workId = searchParams.get("workId");

    const where: any = { judgeId: userId };
    if (workId) where.workId = workId;

    const assignments = await prisma.judgeAssignment.findMany({
      where,
      include: {
        work: {
          include: {
            registration: {
              include: {
                user: {
                  select: { id: true, name: true, avatar: true, school: true, company: true },
                },
                race: {
                  select: { id: true, slug: true, title: true },
                },
              },
            },
          },
        },
        judgingRecord: true,
      },
      orderBy: { assignedAt: "desc" },
    });

    return NextResponse.json(assignments);
  } catch (error: any) {
    if (error.name === "PermissionError") {
      return NextResponse.json({ error: error.message }, { status: error.statusCode });
    }
    console.error("GET /api/judge-assignments error:", error);
    return NextResponse.json({ error: "获取评审分配失败" }, { status: 500 });
  }
}

/** POST /api/judge-assignments — create a judge assignment */
export async function POST(request: Request) {
  try {
    const userId = await requireAuth();

    const body = await request.json();
    const { workId, judgeId } = body;

    if (!workId || !judgeId) {
      return NextResponse.json(
        { error: "workId 和 judgeId 为必填项" },
        { status: 400 },
      );
    }

    // Get the work to find the race
    const work = await prisma.work.findUnique({
      where: { id: workId },
      include: {
        registration: {
          select: { raceId: true },
        },
      },
    });

    if (!work) {
      return NextResponse.json({ error: "作品不存在" }, { status: 404 });
    }

    // Require organizer of the race
    await requireOrganizerOfRace(work.registration.raceId);

    // Verify judge has "judge" role
    const judge = await prisma.user.findUnique({
      where: { id: judgeId },
    });

    if (!judge) {
      return NextResponse.json({ error: "评审员不存在" }, { status: 404 });
    }

    const judgeRoles: string[] = JSON.parse(judge.roles);
    if (!judgeRoles.includes("judge")) {
      return NextResponse.json(
        { error: "目标用户没有 judge 角色" },
        { status: 400 },
      );
    }

    // Check if assignment already exists
    const existingAssignment = await prisma.judgeAssignment.findFirst({
      where: { workId, judgeId },
    });

    if (existingAssignment) {
      return NextResponse.json(
        { error: "该评审员已经被分配评审此作品了" },
        { status: 409 },
      );
    }

    const assignment = await prisma.judgeAssignment.create({
      data: {
        workId,
        judgeId,
        assignedByUserId: userId,
      },
    });

    return NextResponse.json(assignment, { status: 201 });
  } catch (error: any) {
    if (error.name === "PermissionError") {
      return NextResponse.json(
        { error: error.message },
        { status: error.statusCode },
      );
    }
    console.error("POST /api/judge-assignments error:", error);
    return NextResponse.json({ error: "创建评审分配失败" }, { status: 500 });
  }
}
