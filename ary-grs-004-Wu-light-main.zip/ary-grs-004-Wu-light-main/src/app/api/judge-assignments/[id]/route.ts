import { NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import { requireOrganizerOfRace } from "@/lib/permissions";

/** DELETE /api/judge-assignments/[id] — delete a judge assignment */
export async function DELETE(
  _req: Request,
  { params }: { params: { id: string } },
) {
  try {
    const assignment = await prisma.judgeAssignment.findUnique({
      where: { id: params.id },
      include: {
        work: {
          include: {
            registration: {
              select: { raceId: true },
            },
          },
        },
      },
    });

    if (!assignment) {
      return NextResponse.json({ error: "评审分配记录不存在" }, { status: 404 });
    }

    // Require organizer of the race
    await requireOrganizerOfRace(assignment.work.registration.raceId);

    await prisma.judgeAssignment.delete({
      where: { id: params.id },
    });

    return NextResponse.json({ message: "评审分配已删除" });
  } catch (error: any) {
    if (error.name === "PermissionError") {
      return NextResponse.json(
        { error: error.message },
        { status: error.statusCode },
      );
    }
    console.error("DELETE /api/judge-assignments/[id] error:", error);
    return NextResponse.json({ error: "删除评审分配失败" }, { status: 500 });
  }
}
