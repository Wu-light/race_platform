import { NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import { requireOrganizerOfRace } from "@/lib/permissions";

/** PUT /api/awards/[id] — update/publish/unpublish an award */
export async function PUT(
  request: Request,
  { params }: { params: { id: string } },
) {
  try {
    const award = await prisma.award.findUnique({
      where: { id: params.id },
    });

    if (!award) {
      return NextResponse.json({ error: "奖项不存在" }, { status: 404 });
    }

    await requireOrganizerOfRace(award.raceId);

    const body = await request.json();
    const { action, awardName, rank, decisionReason, registrationId, workId } = body;

    // Handle publish/unpublish actions
    if (action) {
      if (action === "publish") {
        const updated = await prisma.award.update({
          where: { id: params.id },
          data: { publishedAt: new Date() },
        });
        return NextResponse.json(updated);
      }

      if (action === "unpublish") {
        const updated = await prisma.award.update({
          where: { id: params.id },
          data: { publishedAt: null },
        });
        return NextResponse.json(updated);
      }

      return NextResponse.json(
        { error: "action 必须为 publish 或 unpublish" },
        { status: 400 },
      );
    }

    // Regular field updates
    const updateData: Record<string, any> = {};
    if (awardName !== undefined) updateData.awardName = awardName;
    if (rank !== undefined) updateData.rank = rank;
    if (decisionReason !== undefined) updateData.decisionReason = decisionReason;
    if (registrationId !== undefined) updateData.registrationId = registrationId;
    if (workId !== undefined) updateData.workId = workId;

    const updated = await prisma.award.update({
      where: { id: params.id },
      data: updateData,
    });

    return NextResponse.json(updated);
  } catch (error: any) {
    if (error.name === "PermissionError") {
      return NextResponse.json(
        { error: error.message },
        { status: error.statusCode },
      );
    }
    console.error("PUT /api/awards/[id] error:", error);
    return NextResponse.json({ error: "更新奖项失败" }, { status: 500 });
  }
}
