import { NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import { requireOrganizerOfRace } from "@/lib/permissions";

/** POST /api/awards — create/publish awards */
export async function POST(request: Request) {
  try {
    const body = await request.json();
    const { raceId, awards } = body;

    if (!raceId || !awards || !Array.isArray(awards) || awards.length === 0) {
      return NextResponse.json(
        { error: "raceId 和 awards 数组为必填项" },
        { status: 400 },
      );
    }

    await requireOrganizerOfRace(raceId);

    const createdAwards = [];

    for (const award of awards) {
      const { registrationId, workId, awardName, rank, decisionReason } = award;

      if (!registrationId || !awardName || rank === undefined) {
        return NextResponse.json(
          { error: "每个奖项必须包含 registrationId、awardName 和 rank" },
          { status: 400 },
        );
      }

      // Use upsert for idempotent creation
      const created = await prisma.award.upsert({
        where: {
          raceId_awardName_rank: {
            raceId,
            awardName,
            rank,
          },
        },
        update: {
          registrationId,
          workId: workId ?? null,
          decisionReason: decisionReason ?? null,
        },
        create: {
          raceId,
          registrationId,
          workId: workId ?? null,
          awardName,
          rank,
          decisionReason: decisionReason ?? null,
        },
      });

      createdAwards.push(created);
    }

    return NextResponse.json(createdAwards, { status: 201 });
  } catch (error: any) {
    if (error.name === "PermissionError") {
      return NextResponse.json(
        { error: error.message },
        { status: error.statusCode },
      );
    }
    console.error("POST /api/awards error:", error);
    return NextResponse.json({ error: "创建奖项失败" }, { status: 500 });
  }
}
