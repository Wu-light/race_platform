import { NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import { requireAuth, requireRole } from "@/lib/permissions";

/** GET /api/registrations?raceSlug=xxx — get current user's registration for a race */
export async function GET(request: Request) {
  try {
    const userId = await requireAuth();
    const { searchParams } = new URL(request.url);
    const raceSlug = searchParams.get("raceSlug");

    if (!raceSlug) {
      return NextResponse.json(
        { error: "缺少 raceSlug 参数" },
        { status: 400 },
      );
    }

    const race = await prisma.race.findUnique({
      where: { slug: raceSlug },
      select: { id: true },
    });

    if (!race) {
      return NextResponse.json({ error: "赛事不存在" }, { status: 404 });
    }

    const registration = await prisma.registration.findUnique({
      where: {
        userId_raceId: { userId, raceId: race.id },
      },
      include: {
        work: true,
        raceProject: {
          include: {
            caConnections: {
              orderBy: { registeredAt: "desc" },
            },
          },
        },
      },
    });

    if (!registration) {
      return NextResponse.json({ registration: null });
    }

    return NextResponse.json({ registration });
  } catch (error: any) {
    if (error.name === "PermissionError") {
      return NextResponse.json(
        { error: error.message },
        { status: error.statusCode },
      );
    }
    console.error("GET /api/registrations error:", error);
    return NextResponse.json({ error: "获取报名信息失败" }, { status: 500 });
  }
}

/** POST /api/registrations — submit a registration */
export async function POST(request: Request) {
  try {
    const userId = await requireRole("rider");

    const body = await request.json();
    const { raceId } = body;

    if (!raceId) {
      return NextResponse.json(
        { error: "raceId 为必填项" },
        { status: 400 },
      );
    }

    // Check race exists and status allows registration
    const race = await prisma.race.findUnique({
      where: { id: raceId },
    });

    if (!race) {
      return NextResponse.json({ error: "赛事不存在" }, { status: 404 });
    }

    if (race.status !== "registration" && race.status !== "published") {
      return NextResponse.json(
        { error: "当前赛事状态不允许报名" },
        { status: 400 },
      );
    }

    // Check for existing registration (the @@unique constraint will also catch this)
    const existing = await prisma.registration.findUnique({
      where: { userId_raceId: { userId, raceId } },
    });

    if (existing) {
      return NextResponse.json(
        { error: "你已经报名过该赛事了" },
        { status: 409 },
      );
    }

    const registration = await prisma.registration.create({
      data: {
        userId,
        raceId,
        status: "submitted",
      },
    });

    return NextResponse.json(registration, { status: 201 });
  } catch (error: any) {
    if (error.name === "PermissionError") {
      return NextResponse.json(
        { error: error.message },
        { status: error.statusCode },
      );
    }
    // Handle Prisma unique constraint violation
    if (error.code === "P2002") {
      return NextResponse.json(
        { error: "你已经报名过该赛事了" },
        { status: 409 },
      );
    }
    console.error("POST /api/registrations error:", error);
    return NextResponse.json({ error: "报名失败" }, { status: 500 });
  }
}
