import { NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import { requireOrganizerOfRace } from "@/lib/permissions";

/** PUT /api/registrations/[id] — approve/reject registration */
export async function PUT(
  request: Request,
  { params }: { params: { id: string } },
) {
  try {
    const registration = await prisma.registration.findUnique({
      where: { id: params.id },
    });

    if (!registration) {
      return NextResponse.json({ error: "报名记录不存在" }, { status: 404 });
    }

    await requireOrganizerOfRace(registration.raceId);

    const body = await request.json();
    const { action } = body;

    if (!action || !["approve", "reject"].includes(action)) {
      return NextResponse.json(
        { error: "action 必须为 approve 或 reject" },
        { status: 400 },
      );
    }

    if (registration.status !== "submitted") {
      return NextResponse.json(
        { error: "只能审核状态为 submitted 的报名" },
        { status: 400 },
      );
    }

    let updatedRegistration;

    if (action === "approve") {
      updatedRegistration = await prisma.registration.update({
        where: { id: params.id },
        data: {
          status: "approved",
          approvedAt: new Date(),
        },
      });

      // Idempotently create RaceProject if it doesn't exist
      const existingProject = await prisma.raceProject.findUnique({
        where: { registrationId: params.id },
      });

      if (!existingProject) {
        await prisma.raceProject.create({
          data: {
            registrationId: params.id,
          },
        });
      }
    } else {
      updatedRegistration = await prisma.registration.update({
        where: { id: params.id },
        data: {
          status: "rejected",
        },
      });
    }

    return NextResponse.json(updatedRegistration);
  } catch (error: any) {
    if (error.name === "PermissionError") {
      return NextResponse.json(
        { error: error.message },
        { status: error.statusCode },
      );
    }
    console.error("PUT /api/registrations/[id] error:", error);
    return NextResponse.json({ error: "审核报名失败" }, { status: 500 });
  }
}
