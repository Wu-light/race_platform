import { NextResponse } from "next/server";
import { z } from "zod";
import { requireRole, PermissionError } from "@/lib/permissions";
import { ingestMockData } from "@/lib/ca-mock";

const bodySchema = z.object({
  raceId: z.string().optional(),
  /** 每个连接生成的 Session 数量，默认 20 */
  sessionsPerConnection: z.number().int().min(1).max(100).optional(),
  /** tokenCost 正态分布均值，默认 25500 */
  tokenCostMean: z.number().min(0).optional(),
  /** tokenCost 正态分布标准差，默认 12000 */
  tokenCostStdDev: z.number().min(0).optional(),
  /** tokenCost 下限，默认 1000 */
  tokenCostMin: z.number().min(0).optional(),
  /** tokenCost 上限，默认 50000 */
  tokenCostMax: z.number().min(0).optional(),
});

/** POST /api/internal/ca-mock/ingest — 为活跃 CAConnection 生成模拟 Session 数据 */
export async function POST(request: Request) {
  try {
    await requireRole("admin");
    const body = await request.json().catch(() => ({}));
    const parsed = bodySchema.safeParse(body);
    if (!parsed.success) {
      return NextResponse.json(
        { error: "Invalid body", details: parsed.error.issues },
        { status: 400 },
      );
    }

    const { raceId, ...opts } = parsed.data;
    const result = await ingestMockData(raceId, opts);
    return NextResponse.json(result);
  } catch (error) {
    if (error instanceof PermissionError) {
      return NextResponse.json(
        { error: error.message },
        { status: error.statusCode },
      );
    }
    console.error("[ca-mock/ingest]", error);
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 },
    );
  }
}
