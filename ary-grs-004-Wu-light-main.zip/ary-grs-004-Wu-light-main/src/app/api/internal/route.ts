import { NextResponse } from "next/server";

/** POST /api/internal — 内部操作入口，请使用子路由 */
export async function POST() {
  return NextResponse.json(
    {
      message: "请使用子路由",
      available: [
        "POST /api/internal/ca-mock/ingest — 生成模拟 CA Session 数据",
        "POST /api/internal/projections/rebuild — 重建 Projection",
        "GET /api/internal/projections?raceId=&type= — 查询 Projection",
      ],
    },
    { status: 400 },
  );
}
