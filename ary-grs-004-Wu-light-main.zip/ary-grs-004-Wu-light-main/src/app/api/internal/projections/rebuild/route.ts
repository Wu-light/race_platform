import { NextResponse } from "next/server";
import { z } from "zod";
import { requireOrganizerOfRace, requireRole, PermissionError } from "@/lib/permissions";
import { rebuildAllProjections } from "@/lib/projections";
import { prisma } from "@/lib/db";

const bodySchema = z.object({
  raceId: z.string().min(1),
});

/** POST /api/internal/projections/rebuild — 重建指定 Race 的所有 Projection */
export async function POST(request: Request) {
  try {
    const body = await request.json().catch(() => ({}));
    const parsed = bodySchema.safeParse(body);
    if (!parsed.success) {
      return NextResponse.json(
        { error: "Invalid body", details: parsed.error.issues },
        { status: 400 },
      );
    }

    const { raceId } = parsed.data;

    // 验证 Race 存在
    const race = await prisma.race.findUnique({
      where: { id: raceId },
      select: { id: true, slug: true },
    });
    if (!race) {
      return NextResponse.json({ error: "赛事不存在" }, { status: 404 });
    }

    // 权限：organizer 或 admin
    try {
      await requireRole("admin");
    } catch {
      await requireOrganizerOfRace(raceId);
    }

    const result = await rebuildAllProjections(raceId);
    return NextResponse.json(result);
  } catch (error) {
    if (error instanceof PermissionError) {
      return NextResponse.json(
        { error: error.message },
        { status: error.statusCode },
      );
    }
    console.error("[projections/rebuild]", error);
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 },
    );
  }
}
