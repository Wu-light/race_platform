import { NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import { PermissionError } from "@/lib/permissions";
import { auth } from "@/lib/auth";

/** GET /api/internal/projections?raceId=&type= — 查询 Projection 数据 */
export async function GET(request: Request) {
  try {
    const session = await auth();
    if (!session?.user?.id) {
      return NextResponse.json({ error: "请先登录" }, { status: 401 });
    }

    const { searchParams } = new URL(request.url);
    const raceId = searchParams.get("raceId");
    const type = searchParams.get("type");

    if (!raceId) {
      return NextResponse.json({ error: "缺少 raceId 参数" }, { status: 400 });
    }

    const where: Record<string, unknown> = { raceId };
    if (type) where.type = type;

    const projections = await prisma.projection.findMany({
      where: where as any,
      orderBy: { lastRebuiltAt: "desc" },
      select: { id: true, type: true, data: true, lastRebuiltAt: true },
    });

    // 如果指定了 type，返回单条
    if (type) {
      const p = projections[0] ?? null;
      return NextResponse.json(p ? { ...p, data: JSON.parse(p.data) } : null);
    }

    // 否则返回全部
    return NextResponse.json(
      projections.map((p) => ({ ...p, data: JSON.parse(p.data) })),
    );
  } catch (error) {
    if (error instanceof PermissionError) {
      return NextResponse.json(
        { error: error.message },
        { status: error.statusCode },
      );
    }
    console.error("[projections]", error);
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 },
    );
  }
}
