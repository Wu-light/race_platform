import { NextRequest, NextResponse } from "next/server";
import { requireRole, PermissionError } from "@/lib/permissions";
import { prisma } from "@/lib/db";

export async function PUT(request: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    await requireRole("admin");

    const { id } = await params;
    const body = await request.json();
    const roles: string[] = body.roles ?? [];

    const validRoles = ["rider", "judge", "organizer", "admin"];
    const filtered = roles.filter((r) => validRoles.includes(r));

    const user = await prisma.user.findUnique({ where: { id } });
    if (!user) {
      return NextResponse.json({ error: "User not found" }, { status: 404 });
    }

    await prisma.user.update({
      where: { id },
      data: { roles: JSON.stringify(filtered) },
    });

    return NextResponse.json({ success: true, roles: filtered });
  } catch (e) {
    if (e instanceof PermissionError) {
      return NextResponse.json({ error: e.message }, { status: e.statusCode });
    }
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}
