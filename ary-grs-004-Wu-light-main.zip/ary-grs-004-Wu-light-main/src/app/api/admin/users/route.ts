import { NextRequest, NextResponse } from "next/server";
import { requireRole, PermissionError } from "@/lib/permissions";
import { prisma } from "@/lib/db";

export async function GET(request: NextRequest) {
  try {
    await requireRole("admin");

    const url = new URL(request.url);
    const page = Math.max(1, parseInt(url.searchParams.get("page") ?? "1", 10));
    const pageSize = Math.min(50, Math.max(1, parseInt(url.searchParams.get("pageSize") ?? "20", 10)));
    const skip = (page - 1) * pageSize;

    const [users, total] = await Promise.all([
      prisma.user.findMany({
        orderBy: { createdAt: "desc" },
        skip,
        take: pageSize,
        select: {
          id: true,
          githubId: true,
          name: true,
          email: true,
          avatar: true,
          roles: true,
          profileCompleted: true,
          createdAt: true,
          sessions: {
            orderBy: { expires: "desc" },
            take: 1,
            select: { expires: true },
          },
        },
      }),
      prisma.user.count(),
    ]);

    return NextResponse.json({
      users: users.map((u) => {
        const lastSession = u.sessions[0];
        const lastSignInAt = lastSession
          ? new Date(lastSession.expires.getTime() - 30 * 24 * 60 * 60 * 1000)
          : null;
        const { sessions, ...rest } = u;
        return {
          ...rest,
          roles: JSON.parse(u.roles),
          lastSignInAt: lastSignInAt?.toISOString() ?? null,
        };
      }),
      pagination: {
        page,
        pageSize,
        total,
        totalPages: Math.ceil(total / pageSize),
      },
    });
  } catch (e) {
    if (e instanceof PermissionError) {
      return NextResponse.json({ error: e.message }, { status: e.statusCode });
    }
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}
