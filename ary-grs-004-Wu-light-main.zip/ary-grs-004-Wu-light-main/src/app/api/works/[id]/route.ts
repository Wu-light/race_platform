import { NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import { requireAuth, requireOwnRegistration } from "@/lib/permissions";

/** GET /api/works/[id] — get work detail */
export async function GET(
  _req: Request,
  { params }: { params: { id: string } },
) {
  try {
    const work = await prisma.work.findUnique({
      where: { id: params.id },
      include: {
        registration: {
          include: {
            user: {
              select: { id: true, name: true, avatar: true, bio: true },
            },
            race: {
              select: { id: true, slug: true, title: true },
            },
          },
        },
      },
    });

    if (!work) {
      return NextResponse.json({ error: "作品不存在" }, { status: 404 });
    }

    return NextResponse.json(work);
  } catch (error) {
    console.error("GET /api/works/[id] error:", error);
    return NextResponse.json({ error: "获取作品失败" }, { status: 500 });
  }
}

/** PUT /api/works/[id] — update work */
export async function PUT(
  request: Request,
  { params }: { params: { id: string } },
) {
  try {
    const userId = await requireAuth();

    const work = await prisma.work.findUnique({
      where: { id: params.id },
      include: {
        registration: {
          select: { userId: true, raceId: true },
        },
      },
    });

    if (!work) {
      return NextResponse.json({ error: "作品不存在" }, { status: 404 });
    }

    // Check if user is owner or organizer/admin
    const isOwner = work.registration.userId === userId;
    const user = await prisma.user.findUnique({
      where: { id: userId },
      select: { roles: true },
    });
    const userRoles: string[] = user ? JSON.parse(user.roles) : [];
    const isOrganizerOrAdmin =
      userRoles.includes("organizer") || userRoles.includes("admin");

    // Verify organizer status if not owner
    let isOrganizerOfRace = false;
    if (!isOwner && isOrganizerOrAdmin) {
      const race = await prisma.race.findUnique({
        where: { id: work.registration.raceId },
        select: { organizerId: true },
      });
      isOrganizerOfRace = race?.organizerId === userId || userRoles.includes("admin");
    }

    const canEdit = isOwner || isOrganizerOfRace;

    if (!canEdit) {
      return NextResponse.json(
        { error: "无权修改该作品" },
        { status: 403 },
      );
    }

    const body = await request.json();
    const { action, title, description, demoUrl, githubUrl, videoUrl, techDescription } = body;

    // Handle actions: lock, hide, submit
    if (action) {
      if (!["lock", "hide", "submit"].includes(action)) {
        return NextResponse.json(
          { error: "action 必须为 lock、hide 或 submit" },
          { status: 400 },
        );
      }

      if (action === "submit") {
        if (work.status !== "draft") {
          return NextResponse.json(
            { error: "只有草稿状态的作品可以提交" },
            { status: 400 },
          );
        }

        const updated = await prisma.work.update({
          where: { id: params.id },
          data: { status: "submitted" },
        });
        return NextResponse.json(updated);
      }

      // lock/hide actions - only organizer can do these
      if (!isOrganizerOfRace) {
        return NextResponse.json(
          { error: "只有主办方可以锁定或隐藏作品" },
          { status: 403 },
        );
      }

      if (action === "lock") {
        const updated = await prisma.work.update({
          where: { id: params.id },
          data: { status: "locked" },
        });
        return NextResponse.json(updated);
      }

      if (action === "hide") {
        const updated = await prisma.work.update({
          where: { id: params.id },
          data: { status: "hidden" },
        });
        return NextResponse.json(updated);
      }
    }

    // Regular field updates - only allow if status is draft or user is organizer
    if (work.status !== "draft" && !isOrganizerOfRace) {
      return NextResponse.json(
        { error: "当前作品状态不允许修改" },
        { status: 400 },
      );
    }

    const updateData: Record<string, any> = {};
    if (title !== undefined) updateData.title = title;
    if (description !== undefined) updateData.description = description;
    if (demoUrl !== undefined) updateData.demoUrl = demoUrl;
    if (githubUrl !== undefined) updateData.githubUrl = githubUrl;
    if (videoUrl !== undefined) updateData.videoUrl = videoUrl;
    if (techDescription !== undefined) updateData.techDescription = techDescription;

    if (Object.keys(updateData).length === 0) {
      return NextResponse.json({ error: "没有需要更新的字段" }, { status: 400 });
    }

    const updated = await prisma.work.update({
      where: { id: params.id },
      data: updateData,
    });

    return NextResponse.json(updated);
  } catch (error: any) {
    if (error.name === "PermissionError") {
      return NextResponse.json(
        { error: error.message },
        { status: error.statusCode },
      );
    }
    console.error("PUT /api/works/[id] error:", error);
    return NextResponse.json({ error: "更新作品失败" }, { status: 500 });
  }
}
