import { NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import { requireAuth, requireOwnRegistration } from "@/lib/permissions";
import { slugify } from "@/lib/utils";

/** POST /api/works — create a work */
export async function POST(request: Request) {
  try {
    const userId = await requireAuth();

    const body = await request.json();
    const {
      registrationId,
      title,
      description,
      demoUrl,
      githubUrl,
      videoUrl,
      techDescription,
    } = body;

    if (!registrationId || !title || !description) {
      return NextResponse.json(
        { error: "registrationId、标题和描述为必填项" },
        { status: 400 },
      );
    }

    // Verify user owns the registration
    await requireOwnRegistration(registrationId);

    // Check if work already exists for this registration
    const existingWork = await prisma.work.findUnique({
      where: { registrationId },
    });

    if (existingWork) {
      return NextResponse.json(
        { error: "该报名记录已经创建过作品了" },
        { status: 409 },
      );
    }

    // Auto-generate slug from title
    let slug = slugify(title);
    if (!slug) {
      return NextResponse.json({ error: "无法从标题生成slug" }, { status: 400 });
    }

    // Ensure slug uniqueness
    const slugExists = await prisma.work.findUnique({ where: { slug } });
    if (slugExists) {
      slug = `${slug}-${Date.now()}`;
    }

    const work = await prisma.work.create({
      data: {
        slug,
        registrationId,
        title,
        description,
        demoUrl,
        githubUrl,
        videoUrl,
        techDescription,
        status: "draft",
      },
    });

    return NextResponse.json(work, { status: 201 });
  } catch (error: any) {
    if (error.name === "PermissionError") {
      return NextResponse.json(
        { error: error.message },
        { status: error.statusCode },
      );
    }
    if (error.code === "P2002") {
      return NextResponse.json(
        { error: "该报名记录已经创建过作品了" },
        { status: 409 },
      );
    }
    console.error("POST /api/works error:", error);
    return NextResponse.json({ error: "创建作品失败" }, { status: 500 });
  }
}
