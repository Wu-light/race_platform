import { NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import { requireAuth } from "@/lib/permissions";

/** PUT /api/ca-connections/[id] — update CA connection */
export async function PUT(
  request: Request,
  { params }: { params: { id: string } },
) {
  try {
    const userId = await requireAuth();

    // Find the CA connection and verify ownership through race project -> registration
    const connection = await prisma.cAConnection.findUnique({
      where: { id: params.id },
      include: {
        raceProject: {
          include: {
            registration: {
              select: { userId: true },
            },
          },
        },
      },
    });

    if (!connection) {
      return NextResponse.json({ error: "CA连接不存在" }, { status: 404 });
    }

    // User must own the registration
    if (connection.raceProject.registration.userId !== userId) {
      return NextResponse.json(
        { error: "只能管理自己的CA连接" },
        { status: 403 },
      );
    }

    const body = await request.json();
    const { connectorId, externalProjectRef, action } = body;

    const updateData: Record<string, any> = {};

    if (connectorId !== undefined) updateData.connectorId = connectorId;
    if (externalProjectRef !== undefined) updateData.externalProjectRef = externalProjectRef;

    // Handle actions
    if (action) {
      if (action === "register") {
        updateData.ingestionStatus = "not_configured";
      } else if (action === "handshake") {
        updateData.ingestionStatus = "connected";
        updateData.handshakeAt = new Date();
      } else if (action === "disable") {
        updateData.ingestionStatus = "failed";
        updateData.disabledAt = new Date();
      } else {
        return NextResponse.json(
          { error: "action 必须为 register、handshake 或 disable" },
          { status: 400 },
        );
      }
    }

    const updated = await prisma.cAConnection.update({
      where: { id: params.id },
      data: updateData,
    });

    return NextResponse.json(updated);
  } catch (error: any) {
    if (error.name === "PermissionError") {
      return NextResponse.json(
        { error: error.message },
        { status: error.statusCode },
      );
    }
    console.error("PUT /api/ca-connections/[id] error:", error);
    return NextResponse.json({ error: "更新CA连接失败" }, { status: 500 });
  }
}
