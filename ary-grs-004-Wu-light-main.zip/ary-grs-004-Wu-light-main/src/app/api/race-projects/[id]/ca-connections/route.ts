import { NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import { requireAuth } from "@/lib/permissions";

/** POST /api/race-projects/[id]/ca-connections — register a CA connection */
export async function POST(
  request: Request,
  { params }: { params: { id: string } },
) {
  try {
    const userId = await requireAuth();

    // Find the race project and verify ownership
    const raceProject = await prisma.raceProject.findUnique({
      where: { id: params.id },
      include: {
        registration: {
          select: { userId: true },
        },
      },
    });

    if (!raceProject) {
      return NextResponse.json({ error: "赛事项目不存在" }, { status: 404 });
    }

    // User must own the registration
    if (raceProject.registration.userId !== userId) {
      return NextResponse.json(
        { error: "只能管理自己的赛事项目" },
        { status: 403 },
      );
    }

    const body = await request.json();
    const { caType, connectorId, externalProjectRef } = body;

    const connection = await prisma.cAConnection.create({
      data: {
        raceProjectId: params.id,
        caType: caType || "other",
        connectorId: connectorId ?? null,
        externalProjectRef: externalProjectRef ?? null,
        ingestionStatus: "not_configured",
      },
    });

    return NextResponse.json(connection, { status: 201 });
  } catch (error: any) {
    if (error.name === "PermissionError") {
      return NextResponse.json(
        { error: error.message },
        { status: error.statusCode },
      );
    }
    console.error("POST /api/race-projects/[id]/ca-connections error:", error);
    return NextResponse.json({ error: "创建CA连接失败" }, { status: 500 });
  }
}
