import { NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import { requireOrganizerOfRace } from "@/lib/permissions";
import { slugify } from "@/lib/utils";

/** GET /api/races/[slug] — get a single race by slug */
export async function GET(
  _req: Request,
  { params }: { params: { slug: string } },
) {
  const race = await prisma.race.findUnique({
    where: { slug: params.slug },
    include: {
      organizer: { select: { id: true, name: true, avatar: true } },
      _count: { select: { registrations: true, awards: true } },
    },
  });
  if (!race) {
    return NextResponse.json({ error: "赛事不存在" }, { status: 404 });
  }
  return NextResponse.json(race);
}

/** PUT /api/races/[slug] — update a race */
export async function PUT(
  request: Request,
  { params }: { params: { slug: string } },
) {
  try {
    // Look up race by slug to get raceId
    const race = await prisma.race.findUnique({
      where: { slug: params.slug },
    });
    if (!race) {
      return NextResponse.json({ error: "赛事不存在" }, { status: 404 });
    }

    await requireOrganizerOfRace(race.id);

    const body = await request.json();
    const allowedFields = [
      "title",
      "subtitle",
      "description",
      "challenge",
      "rules",
      "schedule",
      "status",
      "visibility",
      "awardSettings",
      "submissionRequirements",
    ];

    const updateData: Record<string, any> = {};
    for (const field of allowedFields) {
      if (body[field] !== undefined) {
        if (field === "schedule" || field === "submissionRequirements" || field === "awardSettings") {
          updateData[field] =
            typeof body[field] === "string"
              ? body[field]
              : JSON.stringify(body[field]);
        } else {
          updateData[field] = body[field];
        }
      }
    }

    // If title changed, also update slug
    if (body.title) {
      updateData.slug = slugify(body.title);
    }

    const updatedRace = await prisma.race.update({
      where: { id: race.id },
      data: updateData,
    });

    return NextResponse.json(updatedRace);
  } catch (error: any) {
    if (error.name === "PermissionError") {
      return NextResponse.json(
        { error: error.message },
        { status: error.statusCode },
      );
    }
    console.error("PUT /api/races/[slug] error:", error);
    return NextResponse.json({ error: "更新赛事失败" }, { status: 500 });
  }
}
