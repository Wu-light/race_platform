import { NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import { requireRole } from "@/lib/permissions";
import { slugify } from "@/lib/utils";

/** GET /api/races — list public races */
export async function GET() {
  const races = await prisma.race.findMany({
    where: { visibility: { not: "hidden" } },
    orderBy: { createdAt: "desc" },
    include: {
      organizer: { select: { id: true, name: true, avatar: true } },
      _count: { select: { registrations: true } },
    },
  });
  return NextResponse.json(races);
}

/** POST /api/races — create a race (organizer/admin only) */
export async function POST(request: Request) {
  try {
    const userId = await requireRole("organizer", "admin");

    const body = await request.json();
    const {
      title,
      subtitle,
      description,
      challenge,
      rules,
      schedule,
      status,
      visibility,
      awardSettings,
      submissionRequirements,
    } = body;

    if (!title || !description || !challenge) {
      return NextResponse.json(
        { error: "标题、描述和赛题说明为必填项" },
        { status: 400 },
      );
    }

    // Auto-generate slug from title
    let slug = slugify(title);
    if (!slug) {
      return NextResponse.json({ error: "无法从标题生成slug" }, { status: 400 });
    }

    // Ensure slug uniqueness
    const existingRace = await prisma.race.findUnique({ where: { slug } });
    if (existingRace) {
      slug = `${slug}-${Date.now()}`;
    }

    const race = await prisma.race.create({
      data: {
        slug,
        title,
        subtitle,
        description,
        challenge,
        rules: rules || "",
        schedule: schedule ? JSON.stringify(schedule) : "{}",
        status: status || "draft",
        visibility: visibility || "hidden",
        awardSettings: awardSettings ? JSON.stringify(awardSettings) : "[]",
        submissionRequirements: submissionRequirements
          ? JSON.stringify(submissionRequirements)
          : "{}",
        organizerId: userId,
      },
    });

    return NextResponse.json(race, { status: 201 });
  } catch (error: any) {
    if (error.name === "PermissionError") {
      return NextResponse.json(
        { error: error.message },
        { status: error.statusCode },
      );
    }
    console.error("POST /api/races error:", error);
    return NextResponse.json({ error: "创建赛事失败" }, { status: 500 });
  }
}
