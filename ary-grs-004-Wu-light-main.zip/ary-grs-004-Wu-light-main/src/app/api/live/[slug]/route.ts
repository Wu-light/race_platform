import { NextResponse } from "next/server";
import { getPublicLiveHall } from "@/lib/data-access";

/** GET /api/live/[slug] — Live Hall 公开数据端点（用于客户端轮询） */
export async function GET(
  _request: Request,
  { params }: { params: { slug: string } },
) {
  try {
    const data = await getPublicLiveHall(params.slug);
    if (!data) {
      return NextResponse.json({ error: "Not found" }, { status: 404 });
    }
    return NextResponse.json(data, {
      headers: {
        "Cache-Control": "no-cache, no-store, must-revalidate",
      },
    });
  } catch (error) {
    console.error("[live/api]", error);
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 },
    );
  }
}
