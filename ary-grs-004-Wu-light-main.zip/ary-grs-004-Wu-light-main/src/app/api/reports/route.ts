import { NextResponse } from "next/server";
import { z } from "zod";
import { requireOrganizerOfRace, PermissionError } from "@/lib/permissions";
import {
  generateRiderReport,
  generateRaceReport,
  generateReviewSummary,
  generateAllReportsForRace,
} from "@/lib/report-generator";

const bodySchema = z.object({
  raceId: z.string().min(1),
  type: z.enum(["rider_report", "race_report", "review_summary", "all"]),
  registrationId: z.string().optional(),
});

/** POST /api/reports — 生成报告 */
export async function POST(request: Request) {
  try {
    const body = await request.json().catch(() => ({}));
    const parsed = bodySchema.safeParse(body);
    if (!parsed.success) {
      return NextResponse.json(
        { error: "Invalid body", details: parsed.error.issues },
        { status: 400 },
      );
    }

    const { raceId, type, registrationId } = parsed.data;
    await requireOrganizerOfRace(raceId);

    switch (type) {
      case "rider_report": {
        if (!registrationId) {
          return NextResponse.json(
            { error: "rider_report 需要 registrationId" },
            { status: 400 },
          );
        }
        await generateRiderReport(registrationId);
        return NextResponse.json({ success: true, type: "rider_report" });
      }
      case "race_report": {
        await generateRaceReport(raceId);
        return NextResponse.json({ success: true, type: "race_report" });
      }
      case "review_summary": {
        await generateReviewSummary(raceId);
        return NextResponse.json({ success: true, type: "review_summary" });
      }
      case "all": {
        const result = await generateAllReportsForRace(raceId);
        return NextResponse.json(result);
      }
    }
  } catch (error) {
    if (error instanceof PermissionError) {
      return NextResponse.json(
        { error: error.message },
        { status: error.statusCode },
      );
    }
    console.error("[reports]", error);
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 },
    );
  }
}
