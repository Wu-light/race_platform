import { NextResponse } from "next/server";
import { z } from "zod";
import { prisma } from "@/lib/db";
import { requireOrganizerOfRace, PermissionError } from "@/lib/permissions";
import {
  generateRiderReport,
  generateRaceReport,
  generateReviewSummary,
} from "@/lib/report-generator";

const bodySchema = z.object({
  action: z.enum(["review", "publish", "unpublish", "regenerate"]),
});

/** PUT /api/reports/[id] — 报告状态转换 */
export async function PUT(
  request: Request,
  { params }: { params: { id: string } },
) {
  try {
    const report = await prisma.report.findUnique({
      where: { id: params.id },
      select: { id: true, raceId: true, type: true, status: true, subjectRegistrationId: true },
    });
    if (!report) {
      return NextResponse.json({ error: "报告不存在" }, { status: 404 });
    }

    await requireOrganizerOfRace(report.raceId);

    const body = await request.json().catch(() => ({}));
    const parsed = bodySchema.safeParse(body);
    if (!parsed.success) {
      return NextResponse.json(
        { error: "Invalid body", details: parsed.error.issues },
        { status: 400 },
      );
    }

    const { action } = parsed.data;

    switch (action) {
      case "review": {
        if (report.status !== "generated") {
          return NextResponse.json(
            { error: "只能审阅 generated 状态的报告" },
            { status: 400 },
          );
        }
        await prisma.report.update({
          where: { id: params.id },
          data: { status: "reviewed" },
        });
        return NextResponse.json({ success: true, status: "reviewed" });
      }

      case "publish": {
        if (!["generated", "reviewed"].includes(report.status)) {
          return NextResponse.json(
            { error: "只能发布 generated/reviewed 状态的报告" },
            { status: 400 },
          );
        }
        await prisma.report.update({
          where: { id: params.id },
          data: { status: "published", publishedAt: new Date() },
        });
        return NextResponse.json({ success: true, status: "published" });
      }

      case "unpublish": {
        if (report.status !== "published") {
          return NextResponse.json(
            { error: "只能取消发布 published 状态的报告" },
            { status: 400 },
          );
        }
        await prisma.report.update({
          where: { id: params.id },
          data: { status: "generated", publishedAt: null },
        });
        return NextResponse.json({ success: true, status: "generated" });
      }

      case "regenerate": {
        // 根据报告类型重新生成
        switch (report.type) {
          case "rider_report": {
            if (!report.subjectRegistrationId) {
              return NextResponse.json(
                { error: "缺少 subjectRegistrationId" },
                { status: 400 },
              );
            }
            await generateRiderReport(report.subjectRegistrationId);
            break;
          }
          case "race_report":
            await generateRaceReport(report.raceId);
            break;
          case "review_summary":
            await generateReviewSummary(report.raceId);
            break;
        }
        return NextResponse.json({ success: true, status: "regenerated" });
      }
    }
  } catch (error) {
    if (error instanceof PermissionError) {
      return NextResponse.json(
        { error: error.message },
        { status: error.statusCode },
      );
    }
    console.error("[reports/[id]]", error);
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 },
    );
  }
}
