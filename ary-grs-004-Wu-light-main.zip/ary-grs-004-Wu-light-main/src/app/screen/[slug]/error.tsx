"use client";

import { useEffect } from "react";
import { RotateCcw, MonitorOff } from "lucide-react";

export default function ScreenError({
  error,
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  useEffect(() => {
    console.error("[ARY ScreenError]", error);
  }, [error]);

  return (
    <div className="flex h-full items-center justify-center bg-ary-blue-950 px-20">
      <div className="max-w-2xl text-center">
        <MonitorOff className="mx-auto h-20 w-20 text-red-400/60" />
        <h1 className="mt-8 text-[36px] font-black text-white">
          大屏加载异常
        </h1>
        <p className="mt-4 text-2xl leading-relaxed text-white/40">
          大屏渲染时发生意外错误。请刷新页面重试。
        </p>
        <button
          onClick={reset}
          className="mt-8 inline-flex items-center gap-3 rounded-2xl bg-white/10 px-8 py-4 text-xl font-bold text-white transition hover:bg-white/20"
        >
          <RotateCcw className="h-6 w-6" />
          重试
        </button>
        <p className="mt-16 text-lg font-semibold uppercase tracking-[0.2em] text-white/15">
          Agent Racing Yard · Screen Display
        </p>
      </div>
    </div>
  );
}
