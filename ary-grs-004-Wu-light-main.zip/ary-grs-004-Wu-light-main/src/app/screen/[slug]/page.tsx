import { notFound } from "next/navigation";
import { getScreenData } from "@/lib/screen-data";
import { ScreenJumbotron } from "@/components/screen/ScreenJumbotron";
import { ScreenBillboard } from "@/components/screen/ScreenBillboard";
import { ScreenLive } from "@/components/screen/ScreenLive";
import { ScreenLeaderboard } from "@/components/screen/ScreenLeaderboard";
import { ScreenWorks } from "@/components/screen/ScreenWorks";
import { ScreenAnnouncement } from "@/components/screen/ScreenAnnouncement";
import { ScreenClient } from "@/components/screen/ScreenClient";
import { ScreenFallback } from "@/components/screen/ScreenFallback";
import type { FallbackType } from "@/components/screen/ScreenFallback";
import type { ScreenMode } from "@/types";

interface Props {
  params: { slug: string };
  searchParams: { mode?: string };
}

const VALID_MODES: ScreenMode[] = [
  "jumbotron",
  "billboard",
  "live",
  "leaderboard",
  "works",
  "announcement",
];

/**
 * 根据 diagnostics 和 mode 判断应该显示哪个 fallback（如有）。
 * 返回 null 表示数据完好，可以正常渲染。
 */
function diagnoseFallback(
  mode: ScreenMode,
  diagnostics: Awaited<ReturnType<typeof getScreenData>> extends infer D
    ? D extends { diagnostics: infer Diag } ? Diag : never
    : never,
): FallbackType | null {
  // 1. 没有任何 Projection 数据
  if (!diagnostics.hasProjections) return "no-data";

  // 2. JSON 解析损坏
  if (diagnostics.corruptedTypes.length > 0) return "corrupted-json";

  // 3. 按模式检查所需数据
  switch (mode) {
    case "jumbotron":
      if (!diagnostics.hasRaceProgress) return "no-projection";
      break;
    case "billboard":
    case "leaderboard":
      if (!diagnostics.hasLeaderboard) return "no-projection";
      break;
    case "live":
      if (!diagnostics.hasLeaderboard) return "no-projection";
      // screen_feed 缺失不阻塞，用空事件流展示
      break;
    case "announcement":
      if (!diagnostics.hasAnnouncements) return "no-announcements";
      break;
    case "works":
      // Works 优先使用真实数据，为空时自动显示占位
      break;
  }

  // 4. 有 Projection 但内容为空（leaderboard rankings 为空）
  if (
    (mode === "billboard" || mode === "live" || mode === "leaderboard") &&
    diagnostics.hasLeaderboard &&
    !diagnostics.hasApprovedRiders
  ) {
    return "empty-rankings";
  }

  // 5. 没有活跃的 CA 连接（jumbotron/live 模式下提示）
  if (
    (mode === "jumbotron" || mode === "live") &&
    !diagnostics.hasActiveCAConnections &&
    diagnostics.hasApprovedRiders
  ) {
    return "no-ca-connections";
  }

  return null;
}

export default async function ScreenDisplayPage({ params, searchParams }: Props) {
  const data = await getScreenData(params.slug);
  if (!data) notFound();

  const mode: ScreenMode = (searchParams.mode as ScreenMode) || "jumbotron";
  const resolvedMode = VALID_MODES.includes(mode) ? mode : "jumbotron";

  const fallbackType = diagnoseFallback(resolvedMode, data.diagnostics);

  // 严重错误 → 全屏 fallback
  if (fallbackType) {
    return (
      <ScreenClient
        slug={params.slug}
        mode={resolvedMode}
        initialFallback={fallbackType}
      >
        <ScreenFallback
          type={fallbackType}
          raceSlug={params.slug}
        />
      </ScreenClient>
    );
  }

  // 正常渲染
  const content = (() => {
    switch (resolvedMode) {
      case "jumbotron":
        return <ScreenJumbotron data={data} />;
      case "billboard":
        return <ScreenBillboard data={data} />;
      case "live":
        return <ScreenLive data={data} />;
      case "leaderboard":
        return <ScreenLeaderboard data={data} />;
      case "works":
        return <ScreenWorks data={data} />;
      case "announcement":
        return <ScreenAnnouncement data={data} />;
      default:
        return <ScreenJumbotron data={data} />;
    }
  })();

  return (
    <ScreenClient slug={params.slug} mode={resolvedMode}>
      {content}
    </ScreenClient>
  );
}
