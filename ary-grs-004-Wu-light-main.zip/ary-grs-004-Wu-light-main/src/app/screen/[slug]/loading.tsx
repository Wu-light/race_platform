export default function ScreenLoading() {
  return (
    <div className="flex h-full items-center justify-center bg-ary-blue-950">
      <div className="text-center">
        <div className="mx-auto h-20 w-20 animate-pulse rounded-full bg-ary-cyan/20" />
        <div className="mt-8 h-10 w-96 animate-pulse rounded-xl bg-white/10" />
        <div className="mt-4 h-6 w-64 animate-pulse rounded-lg bg-white/5" />
        <p className="mt-12 text-2xl font-black text-white/20">加载中...</p>
      </div>
    </div>
  );
}
