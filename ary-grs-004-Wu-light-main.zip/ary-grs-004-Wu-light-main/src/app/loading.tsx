export default function HomeLoading() {
  return (
    <div className="min-h-screen bg-ary-canvas">
      {/* Header skeleton */}
      <div className="h-16 border-b border-ary-line bg-white/60" />

      <main className="mx-auto max-w-[1400px] px-6 py-12">
        {/* Hero skeleton */}
        <div className="mb-12 space-y-4">
          <div className="h-10 w-64 animate-pulse rounded-xl bg-ary-blue-100" />
          <div className="h-14 w-[600px] animate-pulse rounded-xl bg-ary-blue-100" />
          <div className="h-6 w-96 animate-pulse rounded-lg bg-ary-blue-50" />
        </div>

        {/* Card grid skeleton */}
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {Array.from({ length: 6 }).map((_, i) => (
            <div
              key={i}
              className="h-48 animate-pulse rounded-3xl bg-white/70"
            />
          ))}
        </div>
      </main>
    </div>
  );
}
