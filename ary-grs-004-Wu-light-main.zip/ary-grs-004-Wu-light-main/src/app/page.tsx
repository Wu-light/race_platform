import { Building2, GraduationCap, Handshake, PlayCircle } from "lucide-react";
import { PublicPageShell } from "@/components/layout/PublicPageShell";
import { RaceGalleryHero } from "@/components/home/RaceGalleryHero";
import { WorkCard } from "@/components/work/WorkCard";
import { RiderCard } from "@/components/rider/RiderCard";
import { RaceCard } from "@/components/race/RaceCard";
import { ActionLink } from "@/components/ui/ActionLink";
import { EmptyState } from "@/components/ui/EmptyState";
import { SectionHeading } from "@/components/ui/SectionHeading";
import { getHomeGalleryData } from "@/lib/data-access";

export const dynamic = "force-dynamic";

export default async function HomePage() {
  const data = await getHomeGalleryData();
  const galleryRaces = [...data.openRaces, ...data.pastRaces].slice(0, 6);

  return (
    <PublicPageShell>
      <main id="main-content">
        <RaceGalleryHero data={data} />

        <section id="works" className="ary-section ary-content border-t border-ary-line/70">
          <SectionHeading
            eyebrow="03 · Works Showcase"
            title="冲线之后，作品留在这里"
            description="公开作品连接真实赛题、Demo、作者和已发布奖项。它们既是比赛结果，也是可复用的课程与案例资产。"
            action={<ActionLink href={data.featuredWorks[0] ? `/races/${data.featuredWorks[0].race.slug}/works` : "#works"} variant="secondary">浏览作品墙</ActionLink>}
          />
          {data.featuredWorks.length > 0 ? (
            <div className="grid gap-5 md:grid-cols-2 xl:grid-cols-3">
              {data.featuredWorks.map((work, index) => (
                <WorkCard key={work.id} work={work} featured={index === 0} />
              ))}
            </div>
          ) : (
            <EmptyState title="作品正在冲线" description="第一批公开作品提交后，会在这里形成可浏览的作品墙。" />
          )}
        </section>

        <section id="riders" className="ary-section relative border-y border-ary-line/70 bg-white/35">
          <div className="ary-content">
            <SectionHeading
              eyebrow="04 · Rider Assets"
              title="能力不是一句自我介绍"
              description="骑手卡片只使用公开作品、已发布奖项和公开 Evidence 推导，避免把报名资料或原始骑行数据带到公开端。"
            />
            {data.featuredRiders.length > 0 ? (
              <div className="grid gap-5 md:grid-cols-2 xl:grid-cols-3">
                {data.featuredRiders.map((rider) => <RiderCard key={rider.id} rider={rider} />)}
              </div>
            ) : (
              <EmptyState title="骑手档案正在形成" description="当公开作品与能力证据就绪后，代表 Rider 会出现在这里。" />
            )}
          </div>
        </section>

        <section className="ary-section ary-content">
          <SectionHeading
            eyebrow="05 · Race Gallery"
            title="选择下一条赛道"
            description="从开放报名到往届复盘，每场 Race 都保留清晰状态和对应入口。"
          />
          {galleryRaces.length > 0 ? (
            <div className="grid gap-5 md:grid-cols-2 xl:grid-cols-3">
              {galleryRaces.map((race) => <RaceCard key={race.id} race={race} />)}
            </div>
          ) : (
            <EmptyState title="下一场 Race 正在准备" description="开放报名或归档赛事出现后，赛道画廊会自动更新。" />
          )}
        </section>

        <section className="ary-section ary-content">
          <div className="overflow-hidden rounded-[32px] bg-gradient-to-br from-ary-blue-950 via-ary-blue-900 to-ary-blue-700 p-7 text-white shadow-[0_30px_70px_rgba(6,22,74,0.25)] sm:p-10 lg:p-14">
            <div className="grid gap-10 lg:grid-cols-[1.1fr_1fr] lg:items-end">
              <div>
                <p className="text-xs font-black uppercase tracking-[0.22em] text-ary-cyan">Join the next race</p>
                <h2 className="mt-4 max-w-2xl text-3xl font-black tracking-tight sm:text-5xl">
                  参赛、办赛、赞助，让真实挑战成为下一条赛道
                </h2>
                <p className="mt-5 max-w-xl leading-7 text-white/68">
                  学生获得真实 Agentic Development 实战，老师和组织方获得可观察的过程，企业看到作品与人才证据。
                </p>
                <ActionLink href="/cooperation" className="mt-7 bg-white text-ary-blue-900 shadow-none hover:bg-ary-blue-100">
                  查看合作方式
                </ActionLink>
              </div>
              <div className="grid grid-cols-2 gap-3">
                {[
                  [PlayCircle, "报名参赛", "进入真实赛题"],
                  [GraduationCap, "课程办赛", "观察协作过程"],
                  [Building2, "企业命题", "发现作品人才"],
                  [Handshake, "赞助合作", "沉淀赛事资产"],
                ].map(([Icon, title, subtitle]) => {
                  const ItemIcon = Icon as typeof PlayCircle;
                  return (
                    <div key={String(title)} className="rounded-2xl border border-white/12 bg-white/8 p-4 backdrop-blur">
                      <ItemIcon className="h-5 w-5 text-ary-cyan" aria-hidden="true" />
                      <p className="mt-3 font-black">{String(title)}</p>
                      <p className="mt-1 text-xs text-white/55">{String(subtitle)}</p>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        </section>
      </main>
    </PublicPageShell>
  );
}
