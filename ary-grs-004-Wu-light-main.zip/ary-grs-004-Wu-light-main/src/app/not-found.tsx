import Link from "next/link";
import { FileQuestion, Home, Search } from "lucide-react";

export default function NotFound() {
  return (
    <div className="flex min-h-screen items-center justify-center bg-ary-canvas px-6">
      <div className="max-w-lg text-center">
        <FileQuestion className="mx-auto h-16 w-16 text-ary-muted/40" />
        <h1 className="mt-6 text-5xl font-black text-ary-blue-950">404</h1>
        <p className="mt-3 text-lg font-bold text-ary-blue-800">
          页面未找到
        </p>
        <p className="mt-2 text-sm leading-relaxed text-ary-muted">
          你访问的页面不存在或已被移除。检查 URL 是否正确，或返回首页浏览赛事。
        </p>
        <div className="mt-8 flex items-center justify-center gap-3">
          <Link
            href="/"
            className="inline-flex items-center gap-2 rounded-xl bg-ary-blue-800 px-5 py-3 text-sm font-bold text-white transition hover:bg-ary-blue-700"
          >
            <Home className="h-4 w-4" />
            返回首页
          </Link>
          <Link
            href="/races/bay-area-happy-trip"
            className="inline-flex items-center gap-2 rounded-xl border border-ary-line bg-white px-5 py-3 text-sm font-bold text-ary-blue-800 transition hover:border-ary-blue-800"
          >
            <Search className="h-4 w-4" />
            浏览赛事
          </Link>
        </div>
      </div>
    </div>
  );
}
