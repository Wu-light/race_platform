import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "ARY - Agent Racing Yard",
  description:
    "Watch Agent Racing live. See how developers ride coding agents to build amazing things.",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="zh-CN">
      <body className="min-h-screen bg-background antialiased">
        {children}
      </body>
    </html>
  );
}
