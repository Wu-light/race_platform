import Link from "next/link";
import { ArrowRight, BriefcaseBusiness, Building2, Handshake, Route, School, Sparkles, Trophy, Users } from "lucide-react";
import { PublicPageShell } from "@/components/layout/PublicPageShell";
import { ActionLink } from "@/components/ui/ActionLink";
import { SectionHeading } from "@/components/ui/SectionHeading";

const audiences = [
  { icon: Users, title: "学生 / 开发者", text: "在真实赛题中交付作品，留下可验证的 Agent Riding Skill 证据。" },
  { icon: School, title: "老师 / 学校", text: "把课程、实训和比赛串成一个可观察、可复盘的教学过程。" },
  { icon: BriefcaseBusiness, title: "企业", text: "通过命题、奖项与作品发现具备真实 Agentic Development 能力的人才。" },
  { icon: Handshake, title: "社区", text: "共创赛题、组织活动，让优秀作品和经验持续流动。" },
];

const paths = [
  { index: "01", title: "参赛", text: "选择开放 Race，理解赛题与交付要求，登录后提交报名。", href: "/", label: "查看开放赛事" },
  { index: "02", title: "办赛", text: "将课程、企业问题或社区议题整理成可执行的 Agent Race。", href: "/login", label: "进入组织入口" },
  { index: "03", title: "命题 / 赞助", text: "提供真实挑战、奖项、导师资源或人才机会，参与结果共建。", href: "/login", label: "进入合作入口" },
];

export default function CooperationPage() {
  return (
    <PublicPageShell>
      <main id="main-content">
        <section className="relative overflow-hidden pt-[72px]"><div className="ary-content pb-16 pt-16 text-center sm:pb-20 sm:pt-24"><p className="text-xs font-black uppercase tracking-[0.22em] text-ary-blue-700">Cooperation · Build the next track</p><h1 className="mx-auto mt-4 max-w-5xl text-[clamp(3.2rem,7vw,6.8rem)] font-black leading-[0.92] tracking-[-0.055em] text-ary-blue-950">让真实挑战成为<br /><span className="bg-gradient-to-r from-ary-blue-800 to-ary-cyan bg-clip-text text-transparent">Agent 的下一条赛道</span></h1><p className="mx-auto mt-7 max-w-3xl text-base leading-8 text-ary-muted sm:text-lg">Agent Racing Yard 连接学生、老师、企业和社区，用可观看的开发过程、公开作品与已发布结果，沉淀真实 Agentic Development 能力。</p><div className="mt-8 flex flex-col justify-center gap-3 sm:flex-row"><ActionLink href="/">查看当前赛事 <ArrowRight className="h-4 w-4" /></ActionLink><ActionLink href="#paths" variant="secondary">选择合作方式</ActionLink></div></div><div className="ary-content pb-8"><div className="ary-track min-h-[210px]" aria-hidden="true"><span className="ary-rider-marker" data-label="Challenge" style={{left:"16%",top:"68%"}} /><span className="ary-rider-marker bg-ary-cyan" data-label="Riding" style={{left:"50%",top:"48%"}} /><span className="ary-rider-marker bg-amber-400" data-label="Evidence" style={{left:"82%",top:"62%"}} /></div></div></section>

        <section className="ary-section ary-content"><SectionHeading eyebrow="01 · What is ARY" title="不是一次演示，而是一条能力证据链" description="Race 把真实问题、Agent 协作、作品交付、公开结果和复盘串在同一个上下文中。" /><div className="grid gap-5 lg:grid-cols-3"><article className="ary-glass rounded-3xl p-7"><Route className="h-8 w-8 text-ary-blue-700" /><h2 className="mt-5 text-2xl font-black text-ary-blue-950">Agent Racing</h2><p className="mt-3 text-sm leading-7 text-ary-muted">围绕真实赛题，在明确赛程与交付要求中骑行 Coding Agent，并让过程可以被观看。</p></article><article className="ary-glass rounded-3xl p-7"><Sparkles className="h-8 w-8 text-cyan-600" /><h2 className="mt-5 text-2xl font-black text-ary-blue-950">Riding Skill</h2><p className="mt-3 text-sm leading-7 text-ary-muted">不只看最终代码，还关注目标拆解、过程纠偏、成本意识、技术判断和复盘表达。</p></article><article className="ary-glass rounded-3xl p-7"><Trophy className="h-8 w-8 text-amber-500" /><h2 className="mt-5 text-2xl font-black text-ary-blue-950">Public Assets</h2><p className="mt-3 text-sm leading-7 text-ary-muted">公开作品、已发布 Award、Review 与 Evidence 摘要成为课程案例、人才证据和合作资产。</p></article></div></section>

        <section className="ary-section border-y border-ary-line/70 bg-white/35"><div className="ary-content"><SectionHeading eyebrow="02 · Who joins" title="四类参与者，共建同一条赛道" /><div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">{audiences.map(({icon:Icon,title,text}) => <article key={title} className="ary-glass rounded-3xl p-6"><span className="grid h-12 w-12 place-items-center rounded-2xl bg-ary-blue-100 text-ary-blue-700"><Icon className="h-6 w-6" /></span><h3 className="mt-5 text-xl font-black text-ary-blue-950">{title}</h3><p className="mt-3 text-sm leading-6 text-ary-muted">{text}</p></article>)}</div></div></section>

        <section id="paths" className="ary-section ary-content scroll-mt-24"><SectionHeading eyebrow="03 · Cooperation Paths" title="选择你的参与方式" description="所有入口都保留清晰下一步，不要求用户先理解平台内部角色模型。" /><div className="space-y-4">{paths.map((path) => <article key={path.index} className="ary-glass grid gap-5 rounded-3xl p-6 sm:grid-cols-[72px_minmax(0,1fr)_auto] sm:items-center sm:p-7"><span className="grid h-14 w-14 place-items-center rounded-2xl bg-ary-blue-100 text-lg font-black text-ary-blue-700">{path.index}</span><div><h3 className="text-2xl font-black text-ary-blue-950">{path.title}</h3><p className="mt-2 text-sm leading-6 text-ary-muted">{path.text}</p></div><Link href={path.href} className="inline-flex min-h-11 items-center gap-2 text-sm font-black text-ary-blue-700 hover:text-ary-blue-950">{path.label}<ArrowRight className="h-4 w-4" /></Link></article>)}</div></section>

        <section id="contact" className="ary-section border-t border-ary-line/70 bg-white/35"><div className="ary-content"><div className="rounded-[34px] bg-gradient-to-br from-ary-blue-950 to-ary-blue-700 p-8 text-white shadow-[0_26px_60px_rgba(6,22,74,0.24)] sm:p-12"><div className="grid gap-8 lg:grid-cols-[minmax(0,1fr)_auto] lg:items-center"><div><Building2 className="h-9 w-9 text-ary-cyan" /><p className="mt-6 text-xs font-black uppercase tracking-[0.18em] text-white/55">Contact & Next Step</p><h2 className="mt-3 text-3xl font-black sm:text-4xl">准备好下一条 Race 的主题与目标</h2><p className="mt-4 max-w-2xl leading-7 text-white/65">当前仓库未配置公开邮箱，避免展示虚假联系方式。组织方可通过登录入口进入现有工作台；公开联系方式配置后可在此无缝补充。</p></div><div className="flex flex-col gap-3"><ActionLink href="/login" className="bg-white text-ary-blue-900 shadow-none">登录 / 进入 Console</ActionLink><ActionLink href="/" variant="secondary" className="border-white/20 bg-white/10 text-white">先浏览 Race Gallery</ActionLink></div></div></div></div></section>
      </main>
    </PublicPageShell>
  );
}
