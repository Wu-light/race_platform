import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowRight, Award, FileCheck2, Layers3, Sparkles, Trophy } from "lucide-react";
import { PublicPageShell } from "@/components/layout/PublicPageShell";
import { PublicSubpageHero } from "@/components/layout/PublicSubpageHero";
import { MetricCard } from "@/components/ui/MetricCard";
import { StatusBadge } from "@/components/ui/StatusBadge";
import { SectionHeading } from "@/components/ui/SectionHeading";
import { WorkCard } from "@/components/work/WorkCard";
import { getPublicRiderBySlug } from "@/lib/data-access";

function initials(name: string) {
  return name.split(/\s+/).map((part) => part[0]).join("").slice(0, 2).toUpperCase();
}

function compactNumber(value: number | null) {
  return value === null ? "未公开" : new Intl.NumberFormat("zh-CN", { notation: "compact", maximumFractionDigits: 1 }).format(value);
}

export default async function RiderProfilePage({ params }: { params: { slug: string } }) {
  const rider = await getPublicRiderBySlug(params.slug);
  if (!rider) notFound();
  const representativeWork =
    rider.works.find((work) => work.title === rider.representativeWork) || rider.works[0];

  return (
    <PublicPageShell>
      <main id="main-content">
        <PublicSubpageHero eyebrow="Rider Profile · Public Evidence" title={rider.name} description={rider.bio || "通过公开作品、赛事、奖项与 Evidence 形成的 Agent Riding Skill 档案。"} backHref="/#riders" backLabel="返回 Rider Gallery" meta={<>{rider.skillTags.map((tag) => <span key={tag} className="inline-flex min-h-8 items-center rounded-full border border-ary-line bg-white/75 px-3 text-xs font-bold text-ary-blue-800">{tag}</span>)}</>} actions={<Link href={`/works/${representativeWork.slug}`} className="inline-flex min-h-11 items-center justify-center gap-2 rounded-xl bg-gradient-to-br from-ary-blue-800 to-ary-blue-500 px-5 py-2.5 text-sm font-black text-white shadow-ary">查看代表作品 <ArrowRight className="h-4 w-4" /></Link>} />

        <section className="ary-section ary-content"><div className="grid gap-5 lg:grid-cols-[320px_minmax(0,1fr)]"><aside className="ary-glass rounded-3xl p-7"><div className="grid h-24 w-24 place-items-center rounded-[28px] bg-gradient-to-br from-ary-blue-800 to-ary-blue-500 text-3xl font-black text-white shadow-ary">{initials(rider.name)}</div><p className="mt-6 text-xs font-black uppercase tracking-[0.16em] text-ary-blue-600">Affiliation</p><p className="mt-2 text-lg font-black text-ary-blue-950">{rider.affiliation || "独立开发者"}</p><div className="mt-7 grid grid-cols-2 gap-3"><div className="rounded-2xl bg-ary-blue-100/70 p-4"><Layers3 className="h-5 w-5 text-ary-blue-700" /><p className="mt-3 text-2xl font-black text-ary-blue-950">{rider.workCount}</p><p className="text-xs font-semibold text-ary-muted">公开作品</p></div><div className="rounded-2xl bg-amber-50 p-4"><Award className="h-5 w-5 text-amber-600" /><p className="mt-3 text-2xl font-black text-ary-blue-950">{rider.awardCount}</p><p className="text-xs font-semibold text-ary-muted">已发布奖项</p></div></div></aside><div className="ary-glass rounded-3xl p-6 sm:p-8"><SectionHeading eyebrow="01 · Race History" title="参赛记录" description="只展示存在公开作品的赛事记录。" /><div className="space-y-3">{rider.races.map((race) => <article key={race.slug} className="flex flex-col gap-4 rounded-2xl border border-ary-line bg-white/70 p-5 sm:flex-row sm:items-center sm:justify-between"><div><div className="flex flex-wrap items-center gap-2"><StatusBadge status={race.status} /><h3 className="font-black text-ary-blue-950">{race.title}</h3></div><p className="mt-2 text-sm text-ary-muted">提交作品：{race.workTitle}</p>{race.awardNames.length > 0 && <p className="mt-2 text-xs font-bold text-amber-700">{race.awardNames.join(" · ")}</p>}</div><Link href={`/races/${race.slug}`} className="inline-flex min-h-11 items-center gap-2 text-sm font-bold text-ary-blue-700">查看赛事 <ArrowRight className="h-4 w-4" /></Link></article>)}</div></div></div></section>

        <section className="ary-section border-y border-ary-line/70 bg-white/35"><div className="ary-content"><SectionHeading eyebrow="02 · Riding Summary" title="公开骑行数据摘要" description="只从 public Evidence 的白名单字段聚合。成本与风险没有公开 Evidence 时明确显示“未公开”。" /><div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6"><MetricCard label="Sessions" value={rider.performance.sessions ?? "未公开"} hint="public Evidence" /><MetricCard label="Tokens" value={compactNumber(rider.performance.totalTokens)} hint="public Evidence" /><MetricCard label="Corrections" value={rider.performance.corrections ?? "未公开"} hint="public Evidence" /><MetricCard label="Progress" value={rider.performance.averageProgress === null ? "未公开" : `${rider.performance.averageProgress}%`} hint="public Evidence" /><MetricCard label="Cost" value={rider.performance.totalCost === null ? "未公开" : `$${rider.performance.totalCost}`} hint="no public summary" /><MetricCard label="Risk" value={rider.performance.riskSignals ?? "未公开"} hint="no public summary" /></div></div></section>

        <section className="ary-section"><div className="ary-content"><SectionHeading eyebrow="03 · Public Works" title="作品记录" description="每个作品都可以回到对应 Race 上下文。" /><div className="grid gap-5 md:grid-cols-2 xl:grid-cols-3">{rider.works.map((work) => <WorkCard key={work.id} work={work} featured={work.awards.length > 0} />)}</div></div></section>

        <section className="ary-section ary-content"><SectionHeading eyebrow="03 · Awards" title="获奖记录" description="只展示已发布 Award，不读取评审草稿或原始评分表。" /><div className="grid gap-4 lg:grid-cols-2">{rider.awards.map((award) => <article key={award.id} className="ary-glass rounded-3xl p-6"><div className="flex items-start gap-4"><span className="grid h-12 w-12 shrink-0 place-items-center rounded-2xl bg-amber-50 text-amber-700"><Trophy className="h-5 w-5" /></span><div><p className="text-xs font-black uppercase tracking-[0.13em] text-amber-700">{award.name} · #{award.rank}</p><h3 className="mt-2 text-lg font-black text-ary-blue-950">{award.raceTitle}</h3>{award.reason && <p className="mt-2 text-sm leading-6 text-ary-muted">{award.reason}</p>}<div className="mt-4 flex flex-wrap gap-4 text-sm font-bold"><Link href={`/races/${award.raceSlug}/results`} className="text-ary-blue-700">查看赛果</Link>{award.workSlug && <Link href={`/works/${award.workSlug}`} className="text-ary-blue-700">查看作品</Link>}</div></div></div></article>)}</div></section>

        <section className="ary-section border-y border-ary-line/70 bg-white/35"><div className="ary-content"><SectionHeading eyebrow="04 · Evidence" title="能力证据摘要" description="仅使用 public Evidence 的标题与摘要；原始 sourceRef、Session 和成本明细保持非公开。" />{rider.evidence.length > 0 ? <div className="grid gap-4 md:grid-cols-2">{rider.evidence.map((evidence) => <article key={evidence.id} className="ary-glass rounded-3xl p-6"><FileCheck2 className="h-6 w-6 text-ary-blue-600" /><p className="mt-5 text-xs font-black uppercase tracking-[0.14em] text-ary-blue-600">{evidence.type.replaceAll("_", " ")}</p><h3 className="mt-2 text-lg font-black text-ary-blue-950">{evidence.title}</h3>{evidence.summary && <p className="mt-3 text-sm leading-6 text-ary-muted">{evidence.summary}</p>}</article>)}</div> : <div className="rounded-3xl border border-dashed border-ary-line p-9 text-center"><Sparkles className="mx-auto h-7 w-7 text-ary-blue-500" /><p className="mt-4 font-black text-ary-blue-950">暂无公开 Evidence</p><p className="mt-2 text-sm text-ary-muted">作品与奖项仍构成当前档案的公开事实。</p></div>}</div></section>
      </main>
    </PublicPageShell>
  );
}
