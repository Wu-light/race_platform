import { notFound } from "next/navigation";
import { ArrowRight, Flag, Users } from "lucide-react";
import { PublicPageShell } from "@/components/layout/PublicPageShell";
import { PublicSubpageHero } from "@/components/layout/PublicSubpageHero";
import { ActionLink } from "@/components/ui/ActionLink";
import { StatusBadge } from "@/components/ui/StatusBadge";
import { WorksExplorer } from "@/components/work/WorksExplorer";
import { getPublicWorksByRaceSlug } from "@/lib/data-access";

export default async function WorksPage({ params }: { params: { slug: string } }) {
  const data = await getPublicWorksByRaceSlug(params.slug);
  if (!data) notFound();

  return (
    <PublicPageShell>
      <main id="main-content">
        <PublicSubpageHero
          eyebrow="Public Works · Race Collection"
          title={`${data.race.title} 作品墙`}
          description="浏览本场 Race 已公开、已提交或锁定的作品。筛选发生在浏览器本地，不会读取隐藏作品或报名资料。"
          backHref={`/races/${data.race.slug}`}
          backLabel="返回 Race Page"
          meta={<><StatusBadge status={data.race.status} /><span className="inline-flex min-h-8 items-center gap-2 rounded-full border border-ary-line bg-white/75 px-3 text-xs font-bold text-ary-muted"><Flag className="h-3.5 w-3.5 text-ary-blue-600" />{data.works.length} Works</span><span className="inline-flex min-h-8 items-center gap-2 rounded-full border border-ary-line bg-white/75 px-3 text-xs font-bold text-ary-muted"><Users className="h-3.5 w-3.5 text-ary-blue-600" />{data.race.metrics.riders} Riders</span></>}
          actions={<ActionLink href={`/races/${data.race.slug}`}>赛事概览 <ArrowRight className="h-4 w-4" /></ActionLink>}
        />
        <section className="ary-section ary-content">
          <WorksExplorer works={data.works} />
        </section>
      </main>
    </PublicPageShell>
  );
}
