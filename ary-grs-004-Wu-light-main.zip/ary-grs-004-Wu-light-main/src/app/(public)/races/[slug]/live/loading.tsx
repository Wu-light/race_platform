export default function LiveHallLoading() {
  return (
    <div className="min-h-screen bg-ary-canvas">
      <div className="h-16 border-b border-ary-line bg-white/60" />

      <main className="mx-auto max-w-[1200px] px-6 py-12">
        <div className="space-y-4">
          <div className="h-6 w-40 animate-pulse rounded-lg bg-ary-blue-100" />
          <div className="h-10 w-96 animate-pulse rounded-xl bg-ary-blue-100" />
        </div>

        {/* Metric cards skeleton */}
        <div className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {Array.from({ length: 8 }).map((_, i) => (
            <div
              key={i}
              className="h-24 animate-pulse rounded-2xl bg-white/70"
            />
          ))}
        </div>

        {/* Leaderboard skeleton */}
        <div className="mt-10 space-y-4">
          {Array.from({ length: 4 }).map((_, i) => (
            <div
              key={i}
              className="h-20 animate-pulse rounded-2xl bg-white/70"
            />
          ))}
        </div>
      </main>
    </div>
  );
}
