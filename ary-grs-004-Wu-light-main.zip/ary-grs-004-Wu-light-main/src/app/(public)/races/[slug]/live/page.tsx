import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowRight, Clock3, Radio } from "lucide-react";
import { LiveHallContent } from "@/components/live/LiveHallContent";
import { PublicPageShell } from "@/components/layout/PublicPageShell";
import { PublicSubpageHero } from "@/components/layout/PublicSubpageHero";
import { ActionLink } from "@/components/ui/ActionLink";
import { StatusBadge } from "@/components/ui/StatusBadge";
import { getPublicLiveHall } from "@/lib/data-access";
import { formatDateTime } from "@/lib/utils";

export default async function LiveHallPage({ params }: { params: { slug: string } }) {
  const data = await getPublicLiveHall(params.slug);
  if (!data) notFound();
  const { race } = data;

  return (
    <PublicPageShell>
      <main id="main-content">
        {/* Hero — Server Component（SEO 友好、首屏不依赖 JS） */}
        <PublicSubpageHero
          eyebrow="Live Hall · Riding Now"
          title={`${race.title} 正在骑行`}
          description="观看经过字段白名单处理的赛事 Projection。页面不会直接读取原始 CA Session，过程榜也不会替代最终 Award。"
          backHref={`/races/${race.slug}`}
          backLabel="返回 Race Page"
          meta={
            <>
              <StatusBadge status={race.status} />
              <span className="inline-flex min-h-8 items-center gap-2 rounded-full border border-ary-line bg-white/75 px-3 text-xs font-bold text-ary-muted">
                <Radio className="h-3.5 w-3.5 text-ary-blue-600" />
                Public Projection
              </span>
              {data.projectionUpdatedAt && (
                <span className="inline-flex min-h-8 items-center gap-2 rounded-full border border-ary-line bg-white/75 px-3 text-xs font-bold text-ary-muted">
                  <Clock3 className="h-3.5 w-3.5 text-ary-blue-600" />
                  {formatDateTime(data.projectionUpdatedAt)}
                </span>
              )}
            </>
          }
          actions={
            <>
              <Link
                href={`/races/${race.slug}/works`}
                className="inline-flex min-h-11 items-center justify-center gap-2 rounded-xl border border-ary-line bg-white/80 px-4 py-2.5 text-sm font-black text-ary-blue-800"
              >
                查看作品 <ArrowRight className="h-4 w-4" />
              </Link>
            </>
          }
        />

        {/* 动态内容 — 客户端组件，5 秒自动轮询更新 */}
        <LiveHallContent slug={params.slug} initialData={data} />
      </main>
    </PublicPageShell>
  );
}
