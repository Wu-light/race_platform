export default function RaceDetailLoading() {
  return (
    <div className="min-h-screen bg-ary-canvas">
      <div className="h-16 border-b border-ary-line bg-white/60" />

      <main className="mx-auto max-w-[1200px] px-6 py-12">
        {/* Race hero skeleton */}
        <div className="space-y-4">
          <div className="h-6 w-32 animate-pulse rounded-lg bg-ary-blue-100" />
          <div className="h-12 w-[500px] animate-pulse rounded-xl bg-ary-blue-100" />
          <div className="h-5 w-80 animate-pulse rounded-lg bg-ary-blue-50" />
        </div>

        {/* Nav tabs skeleton */}
        <div className="mt-10 flex gap-3">
          {Array.from({ length: 6 }).map((_, i) => (
            <div
              key={i}
              className="h-10 w-24 animate-pulse rounded-xl bg-ary-blue-50"
            />
          ))}
        </div>

        {/* Content skeleton */}
        <div className="mt-10 grid gap-6 sm:grid-cols-2">
          {Array.from({ length: 4 }).map((_, i) => (
            <div
              key={i}
              className="h-40 animate-pulse rounded-3xl bg-white/70"
            />
          ))}
        </div>
      </main>
    </div>
  );
}
