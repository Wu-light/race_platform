import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowRight, FileCheck2, Lightbulb, Quote, Trophy } from "lucide-react";
import { PublicPageShell } from "@/components/layout/PublicPageShell";
import { PublicSubpageHero } from "@/components/layout/PublicSubpageHero";
import { ActionLink } from "@/components/ui/ActionLink";
import { SafeMarkdown } from "@/components/ui/SafeMarkdown";
import { SectionHeading } from "@/components/ui/SectionHeading";
import { WorkCard } from "@/components/work/WorkCard";
import { getHomeGalleryData, getPublicRaceReview } from "@/lib/data-access";
import { formatDate } from "@/lib/utils";

export default async function ReviewPage({ params }: { params: { slug: string } }) {
  const [review, home] = await Promise.all([getPublicRaceReview(params.slug), getHomeGalleryData()]);
  if (!review) notFound();
  const nextRace = home.openRaces.find((race) => race.slug !== review.race.slug);

  return (
    <PublicPageShell>
      <main id="main-content">
        <PublicSubpageHero eyebrow="Published Review · Race Learning" title={`${review.race.title} 评审总结`} description="Review 解释结果背后的判断与可复用经验。内容仅来自已经发布的 review_summary 和公开事实。" backHref={`/races/${review.race.slug}`} backLabel="返回 Race Page" meta={<span className="inline-flex min-h-8 items-center gap-2 rounded-full border border-ary-line bg-white/75 px-3 text-xs font-bold text-ary-muted"><FileCheck2 className="h-3.5 w-3.5 text-ary-blue-600" />发布于 {formatDate(review.publishedAt)}</span>} actions={<>{review.race.publishedAwardCount > 0 && <ActionLink href={`/races/${review.race.slug}/results`}>查看赛果</ActionLink>}<ActionLink href={`/races/${review.race.slug}/works`} variant="secondary">浏览作品</ActionLink></>} />

        <section className="ary-section ary-content"><div className="grid gap-5 lg:grid-cols-[minmax(0,1.25fr)_320px]"><article className="ary-glass rounded-3xl p-6 sm:p-10"><div className="flex items-center gap-3 text-ary-blue-700"><Quote className="h-6 w-6" /><p className="text-xs font-black uppercase tracking-[0.16em]">Review Summary</p></div><SafeMarkdown content={review.content} className="mt-7" /></article><aside className="ary-glass h-fit rounded-3xl p-6"><Lightbulb className="h-7 w-7 text-amber-500" /><h2 className="mt-5 text-xl font-black text-ary-blue-950">事实边界</h2><ul className="mt-4 space-y-3 text-sm leading-6 text-ary-muted"><li>只读取已发布 Review Report</li><li>奖项来自 Award，而非 Projection</li><li>不展示无发布标记的评审表评分</li><li>Evidence 仅展示 public 摘要</li></ul></aside></div></section>

        <section className="ary-section border-y border-ary-line/70 bg-white/35"><div className="ary-content"><SectionHeading eyebrow="02 · Award Rationale" title="获奖说明" description="已发布 Award 的 decisionReason 构成公开判断依据。" /><div className="grid gap-4 lg:grid-cols-2">{review.awards.map((award) => <article key={award.id} className="ary-glass rounded-3xl p-6"><div className="flex items-start gap-4"><span className="grid h-11 w-11 shrink-0 place-items-center rounded-2xl bg-amber-50 text-amber-700"><Trophy className="h-5 w-5" /></span><div><p className="text-xs font-black uppercase tracking-[0.13em] text-amber-700">{award.name} · #{award.rank}</p><h3 className="mt-2 text-lg font-black text-ary-blue-950">{award.riderName}</h3>{award.reason && <p className="mt-2 text-sm leading-6 text-ary-muted">{award.reason}</p>}{award.workSlug && <Link href={`/works/${award.workSlug}`} className="mt-4 inline-flex min-h-11 items-center gap-2 text-sm font-bold text-ary-blue-700">查看 {award.workTitle}<ArrowRight className="h-4 w-4" /></Link>}</div></div></article>)}</div></div></section>

        {review.awards.some((award) => award.reason) && <section className="ary-section ary-content"><SectionHeading eyebrow="03 · Judge Viewpoints" title="评委观点（已发布判断）" description="JudgingRecord 没有独立公开标记，因此这里只引用已经随 Award 发布的判断，不展示评委身份或原始评语。" /><div className="grid gap-4 lg:grid-cols-2">{review.awards.filter((award) => award.reason).slice(0, 2).map((award) => <blockquote key={`view-${award.id}`} className="ary-glass rounded-3xl p-7"><Quote className="h-7 w-7 text-ary-blue-500" /><p className="mt-5 text-lg font-semibold leading-8 text-ary-blue-950">“{award.reason}”</p><footer className="mt-5 text-sm font-bold text-ary-muted">已发布 Award 判断 · {award.name}</footer></blockquote>)}</div></section>}

        {review.featuredWorks.length > 0 && <section className="ary-section ary-content"><SectionHeading eyebrow="03 · Featured Cases" title="典型案例" description="从获奖作品中保留可继续浏览与传播的案例。" /><div className="grid gap-5 md:grid-cols-2 xl:grid-cols-3">{review.featuredWorks.map((work) => <WorkCard key={work.id} work={work} featured />)}</div></section>}

        <section className="ary-section border-y border-ary-line/70 bg-white/35"><div className="ary-content"><SectionHeading eyebrow="04 · Evidence Highlights" title="公开证据摘要" description="没有 public Evidence 时保持空白，不用内部数据补位。" />{review.evidence.length > 0 ? <div className="grid gap-4 md:grid-cols-2">{review.evidence.map((evidence) => <article key={evidence.id} className="ary-glass rounded-3xl p-6"><p className="text-xs font-black uppercase tracking-[0.14em] text-ary-blue-600">{evidence.type.replaceAll("_", " ")}</p><h3 className="mt-2 text-lg font-black text-ary-blue-950">{evidence.title}</h3>{evidence.summary && <p className="mt-3 text-sm leading-6 text-ary-muted">{evidence.summary}</p>}</article>)}</div> : <p className="rounded-3xl border border-dashed border-ary-line p-8 text-center text-ary-muted">本场 Review 暂无公开 Evidence 摘要。</p>}</div></section>

        <section className="ary-section ary-content"><div className="rounded-[30px] bg-gradient-to-br from-ary-blue-950 to-ary-blue-700 p-8 text-white shadow-ary sm:p-10"><p className="text-xs font-black uppercase tracking-[0.18em] text-ary-cyan">Next Race Suggestion</p><h2 className="mt-3 text-3xl font-black">{nextRace ? `下一条开放赛道：${nextRace.title}` : "把复盘带进下一场 Race"}</h2><p className="mt-3 max-w-2xl leading-7 text-white/65">将作品、骑行过程和评审判断转化为下一次更清晰的出发方式。</p><div className="mt-7 flex flex-wrap gap-3">{nextRace && <ActionLink href={`/races/${nextRace.slug}`} className="bg-white text-ary-blue-900 shadow-none">查看下一场</ActionLink>}<ActionLink href="/cooperation" variant="secondary" className="border-white/20 bg-white/10 text-white">了解参赛与办赛</ActionLink></div></div></section>
      </main>
    </PublicPageShell>
  );
}
