import Link from "next/link";
import { notFound } from "next/navigation";
import {
  AlertTriangle,
  ArrowRight,
  BookOpenCheck,
  CircleDollarSign,
  Flag,
  Megaphone,
  Radio,
  Sparkles,
  Target,
  Trophy,
  Users,
} from "lucide-react";
import { PublicPageShell } from "@/components/layout/PublicPageShell";
import { RaceHero } from "@/components/race/RaceHero";
import { RaceLifecycle } from "@/components/race/RaceLifecycle";
import { RaceNavigation } from "@/components/race/RaceNavigation";
import { RaceSchedule } from "@/components/race/RaceSchedule";
import { WorkCard } from "@/components/work/WorkCard";
import { RiderCard } from "@/components/rider/RiderCard";
import { ActionLink } from "@/components/ui/ActionLink";
import { EmptyState } from "@/components/ui/EmptyState";
import { SectionHeading } from "@/components/ui/SectionHeading";
import { formatDate } from "@/lib/utils";
import { getPublicLiveHall, getPublicRaceBySlug } from "@/lib/data-access";
import type { PublicRaceDetail } from "@/types/public";

const fieldLabels: Record<string, string> = {
  title: "作品名称",
  description: "作品介绍",
  demoUrl: "Demo 地址",
  githubUrl: "GitHub 仓库",
  videoUrl: "演示视频",
  techDescription: "技术方案",
};

function statusSpotlight(race: PublicRaceDetail) {
  switch (race.status) {
    case "registration":
    case "published":
      return {
        eyebrow: "Registration · Open Track",
        title: "先理解赛题，再决定如何出发",
        description: "报名阶段优先展示挑战、赛程、交付要求与奖项，帮助 Rider 在入场前形成清晰预期。",
        cards: [
          { icon: Target, label: "真实赛题", value: race.challenge, tone: "blue" },
          { icon: BookOpenCheck, label: "作品交付", value: race.submissionRequirements.fields.length ? `${race.submissionRequirements.fields.length} 项公开材料` : "要求待公布", tone: "cyan" },
          { icon: Trophy, label: "奖项设置", value: race.awardSettings.length ? `${race.awardSettings.length} 条奖项赛道` : "即将公布", tone: "amber" },
        ],
      };
    case "running":
      return {
        eyebrow: "Live · Riding Now",
        title: "赛场正在发生，而不是等待一个结果",
        description: "本区只展示经过白名单解析的 Race Projection；原始 CA Session 不进入公开页面。",
        cards: [
          { icon: Radio, label: "活跃 Rider", value: race.metrics.activeRiders === null ? "暂未同步" : `${race.metrics.activeRiders} 位在线`, tone: "blue" },
          { icon: CircleDollarSign, label: "公开成本摘要", value: race.metrics.totalCost === null ? "暂未同步" : `$${race.metrics.totalCost}`, tone: "cyan" },
          { icon: AlertTriangle, label: "高风险信号", value: race.metrics.highRiskRiders === null ? "暂未同步" : `${race.metrics.highRiskRiders} 位需关注`, tone: "amber" },
        ],
      };
    case "submitting":
      return {
        eyebrow: "Submission · Final Sprint",
        title: "把骑行过程整理成可验证的作品",
        description: "提交阶段聚焦交付材料、公开作品和截止时间；CA 接入状态不作为提交硬门禁。",
        cards: [
          { icon: Flag, label: "公开作品", value: `${race.metrics.publicWorks} 个已上墙`, tone: "blue" },
          { icon: BookOpenCheck, label: "材料字段", value: `${race.submissionRequirements.fields.length} 项`, tone: "cyan" },
          { icon: Target, label: "提交截止", value: race.schedule.submissionDeadline ? formatDate(race.schedule.submissionDeadline) : "待公布", tone: "amber" },
        ],
      };
    case "judging":
      return {
        eyebrow: "Judging · Under Review",
        title: "作品已经交卷，评审正在收敛判断",
        description: "公开端只呈现已公开作品与赛事进度，不提前暴露评分、评语或未发布结果。",
        cards: [
          { icon: BookOpenCheck, label: "公开作品", value: `${race.metrics.publicWorks} 个`, tone: "blue" },
          { icon: Users, label: "Rider", value: `${race.metrics.riders} 位`, tone: "cyan" },
          { icon: Trophy, label: "结果公布", value: race.schedule.judgingEnd ? formatDate(race.schedule.judgingEnd) : "待公布", tone: "amber" },
        ],
      };
    default:
      return {
        eyebrow: "Results · Race Archive",
        title: "冲线之后，作品、奖项与复盘成为长期资产",
        description: "最终结果来自已发布 Award 和 Report，不使用 Live Projection 代替赛果事实。",
        cards: [
          { icon: Trophy, label: "已发布奖项", value: `${race.publishedAwardCount} 条`, tone: "blue" },
          { icon: Sparkles, label: "公开作品", value: `${race.metrics.publicWorks} 个`, tone: "cyan" },
          { icon: BookOpenCheck, label: "评审总结", value: race.hasPublishedReview ? "已发布" : "待发布", tone: "amber" },
        ],
      };
  }
}

const toneStyles = {
  blue: "bg-ary-blue-100 text-ary-blue-700",
  cyan: "bg-cyan-50 text-cyan-700",
  amber: "bg-amber-50 text-amber-700",
} as const;

export default async function RacePage({ params }: { params: { slug: string } }) {
  const race = await getPublicRaceBySlug(params.slug);
  if (!race) notFound();
  const liveData = race.status === "running" ? await getPublicLiveHall(params.slug) : null;

  const spotlight = statusSpotlight(race);

  return (
    <PublicPageShell>
      <main id="main-content">
        <RaceHero race={race} />
        <RaceNavigation race={race} />

        <section id="overview" className="ary-section ary-content">
          <SectionHeading eyebrow="01 · Race Status" title="本场 Race 走到哪里" description="赛事状态驱动页面优先级和入口；赛程日期用于说明，不反向猜测或覆盖赛事状态。" />
          <RaceLifecycle status={race.status} />

          <div className="mt-12 rounded-[30px] border border-ary-line bg-white/65 p-6 shadow-ary backdrop-blur sm:p-8 lg:p-10">
            <div className="max-w-3xl">
              <p className="text-xs font-black uppercase tracking-[0.18em] text-ary-blue-700">{spotlight.eyebrow}</p>
              <h2 className="mt-3 text-3xl font-black tracking-tight text-ary-blue-950 sm:text-4xl">{spotlight.title}</h2>
              <p className="mt-4 leading-7 text-ary-muted">{spotlight.description}</p>
            </div>
            <div className="mt-8 grid gap-4 lg:grid-cols-3">
              {spotlight.cards.map((card) => {
                const Icon = card.icon;
                return (
                  <article key={card.label} className="rounded-3xl border border-ary-line bg-white/80 p-5">
                    <span className={`grid h-11 w-11 place-items-center rounded-2xl ${toneStyles[card.tone as keyof typeof toneStyles]}`}>
                      <Icon className="h-5 w-5" aria-hidden="true" />
                    </span>
                    <p className="mt-5 text-xs font-bold uppercase tracking-[0.12em] text-ary-muted">{card.label}</p>
                    <p className="mt-2 line-clamp-3 font-black leading-6 text-ary-blue-950">{card.value}</p>
                  </article>
                );
              })}
            </div>
          </div>
        </section>

        {(race.status === "registration" || race.status === "published") && (
          <section className="ary-section border-y border-ary-line/70 bg-white/35">
            <div className="ary-content">
              <SectionHeading eyebrow="02 · Why Join & Judging" title="为什么参加，以及如何被评价" description="参赛收益来自 ARY 的公开资产闭环；评审维度采用 PRD 定义的 MVP 固定评分参考，不伪造具体权重。" />
              <div className="grid gap-5 lg:grid-cols-2">
                <article className="ary-glass rounded-3xl p-6 sm:p-8">
                  <p className="text-xs font-black uppercase tracking-[0.16em] text-ary-blue-700">Why Join</p>
                  <h2 className="mt-3 text-2xl font-black text-ary-blue-950">把一次开发变成长期能力资产</h2>
                  <div className="mt-6 space-y-3">
                    {["用真实赛题验证 Agentic Development 方法", "沉淀可传播的公开作品与赛事记录", "通过 Award、Review 与 Evidence 获得可解释反馈"].map((item, index) => <div key={item} className="flex items-start gap-3 rounded-2xl bg-ary-blue-100/65 p-4"><span className="grid h-8 w-8 shrink-0 place-items-center rounded-xl bg-white text-sm font-black text-ary-blue-700">{index + 1}</span><p className="pt-1 text-sm font-bold leading-6 text-ary-blue-950">{item}</p></div>)}
                  </div>
                </article>
                <article className="ary-glass rounded-3xl p-6 sm:p-8">
                  <p className="text-xs font-black uppercase tracking-[0.16em] text-ary-blue-700">MVP Judging Lens</p>
                  <h2 className="mt-3 text-2xl font-black text-ary-blue-950">作品结果 + 骑行能力</h2>
                  <div className="mt-6 grid gap-3 sm:grid-cols-2">
                    <div className="rounded-2xl border border-ary-line bg-white/70 p-4"><p className="font-black text-ary-blue-950">作品结果</p><p className="mt-2 text-sm leading-6 text-ary-muted">完成度、产品理解、技术实现、体验表达、创新性、可展示性。</p></div>
                    <div className="rounded-2xl border border-ary-line bg-white/70 p-4"><p className="font-black text-ary-blue-950">骑行能力</p><p className="mt-2 text-sm leading-6 text-ary-muted">目标拆解、Agent 协同、纠偏、技术判断、成本控制、风险处理、复盘表达。</p></div>
                  </div>
                </article>
              </div>
            </div>
          </section>
        )}

        {liveData && liveData.leaderboard.length > 0 && (
          <section className="ary-section border-y border-ary-line/70 bg-white/35">
            <div className="ary-content">
              <SectionHeading eyebrow="02 · Current Projection" title="当前过程榜预览" description="这是 Live Hall 的过程 Projection，不是最终成绩。" action={<ActionLink href={`/races/${race.slug}/live`} variant="secondary">打开完整 Live Hall</ActionLink>} />
              <div className="grid gap-4 md:grid-cols-3">
                {liveData.leaderboard.slice(0, 3).map((entry) => <article key={entry.riderName} className="ary-glass rounded-3xl p-6"><div className="flex items-center justify-between"><span className="grid h-10 w-10 place-items-center rounded-2xl bg-ary-blue-100 font-black text-ary-blue-700">#{entry.rank}</span><span className="text-sm font-black text-ary-blue-950">{entry.progress}%</span></div><h3 className="mt-5 text-xl font-black text-ary-blue-950">{entry.riderName}</h3><div className="mt-4 h-2 overflow-hidden rounded-full bg-ary-blue-100"><div className="h-full rounded-full bg-gradient-to-r from-ary-blue-800 to-ary-cyan" style={{width:`${entry.progress}%`}} /></div><p className="mt-3 text-xs font-semibold text-ary-muted">公开成本 ${entry.cost} · {entry.risk === "high" ? "高风险" : entry.risk === "medium" ? "需关注" : "低风险"}</p></article>)}
              </div>
            </div>
          </section>
        )}

        {race.status === "judging" && (
          <section className="ary-section border-y border-ary-line/70 bg-white/35">
            <div className="ary-content"><EmptyState title="评委阵容与评语尚未公开" description="当前 Schema 没有评委公开标记，公开端不会暴露 JudgeAssignment 或未发布 JudgingRecord。结果发布后请从 Results / Review 查看已确认判断。" /></div>
          </section>
        )}

        <section id="challenge" className="ary-section border-y border-ary-line/70 bg-white/35">
          <div className="ary-content">
            <SectionHeading eyebrow="02 · Challenge & Rules" title="赛题、规则和赛程在同一上下文" description="所有信息来自当前公开 Race；JSON 字段经过校验，异常时安全回退，不会把原始字段直接送到浏览器。" />
            <div className="grid gap-5 lg:grid-cols-[1.25fr_0.75fr]">
              <div className="space-y-5">
                <article className="ary-glass rounded-3xl p-6 sm:p-8">
                  <div className="flex items-center gap-3 text-ary-blue-700">
                    <Target className="h-5 w-5" aria-hidden="true" />
                    <p className="text-xs font-black uppercase tracking-[0.16em]">Challenge</p>
                  </div>
                  <h2 className="mt-5 text-2xl font-black text-ary-blue-950">{race.challenge}</h2>
                  <p className="mt-5 whitespace-pre-line text-sm leading-7 text-ary-muted">{race.description}</p>
                </article>
                <article className="ary-glass rounded-3xl p-6 sm:p-8">
                  <div className="flex items-center gap-3 text-ary-blue-700">
                    <BookOpenCheck className="h-5 w-5" aria-hidden="true" />
                    <p className="text-xs font-black uppercase tracking-[0.16em]">Race Rules</p>
                  </div>
                  <p className="mt-5 whitespace-pre-line text-sm leading-7 text-ary-muted">{race.rules || "详细规则将在开赛前公布。"}</p>
                </article>
              </div>
              <aside className="ary-glass rounded-3xl p-6 sm:p-8">
                <h2 className="text-xl font-black text-ary-blue-950">赛程时间线</h2>
                <div className="mt-6"><RaceSchedule schedule={race.schedule} /></div>
              </aside>
            </div>
          </div>
        </section>

        <section className="ary-section ary-content">
          <div className="grid gap-5 lg:grid-cols-2">
            <article className="ary-glass rounded-3xl p-6 sm:p-8">
              <p className="text-xs font-black uppercase tracking-[0.16em] text-ary-blue-700">Submission</p>
              <h2 className="mt-3 text-2xl font-black text-ary-blue-950">交付要求</h2>
              {race.submissionRequirements.fields.length > 0 ? (
                <ul className="mt-6 grid gap-3 sm:grid-cols-2">
                  {race.submissionRequirements.fields.map((field) => (
                    <li key={field} className="flex min-h-12 items-center gap-3 rounded-2xl bg-ary-blue-100/70 px-4 py-3 text-sm font-bold text-ary-blue-900">
                      <span className="h-2 w-2 rounded-full bg-ary-blue-500" aria-hidden="true" />
                      {fieldLabels[field] || field}
                    </li>
                  ))}
                </ul>
              ) : <p className="mt-5 text-sm leading-6 text-ary-muted">交付字段仍在确认，发布后会在这里同步。</p>}
              {(race.submissionRequirements.note || race.submissionRequirements.description) && (
                <p className="mt-5 rounded-2xl border border-ary-line bg-white/65 p-4 text-sm leading-6 text-ary-muted">{race.submissionRequirements.note || race.submissionRequirements.description}</p>
              )}
            </article>
            <article className="ary-glass rounded-3xl p-6 sm:p-8">
              <p className="text-xs font-black uppercase tracking-[0.16em] text-ary-blue-700">Awards</p>
              <h2 className="mt-3 text-2xl font-black text-ary-blue-950">奖项赛道</h2>
              {race.awardSettings.length > 0 ? (
                <ol className="mt-6 space-y-3">
                  {race.awardSettings.map((award, index) => (
                    <li key={award} className="flex items-center gap-4 rounded-2xl border border-ary-line bg-white/65 px-4 py-3">
                      <span className="grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-amber-50 text-sm font-black text-amber-700">{String(index + 1).padStart(2, "0")}</span>
                      <span className="font-bold text-ary-blue-950">{award}</span>
                    </li>
                  ))}
                </ol>
              ) : <p className="mt-5 text-sm leading-6 text-ary-muted">奖项设置将在赛事进入正式阶段后公布。</p>}
            </article>
          </div>
        </section>

        <section id="works" className="ary-section border-y border-ary-line/70 bg-white/35">
          <div className="ary-content">
            <SectionHeading
              eyebrow="03 · Public Works"
              title="本场公开作品"
              description="隐藏、草稿和未公开作品在数据访问层即被排除。"
              action={race.works.length > 0 ? <ActionLink href={`/races/${race.slug}/works`} variant="secondary">打开完整作品墙</ActionLink> : undefined}
            />
            {race.works.length > 0 ? (
              <div className="grid gap-5 md:grid-cols-2 xl:grid-cols-3">
                {race.works.slice(0, 3).map((work) => <WorkCard key={work.id} work={work} />)}
              </div>
            ) : (
              <EmptyState title="公开作品尚未上墙" description="作品完成提交并设置为公开后，会自动出现在本场 Race Page。" />
            )}
          </div>
        </section>

        {race.awards.length > 0 && (
          <section className="ary-section ary-content">
            <SectionHeading eyebrow="Published Results" title="获奖名单预览" description="完整榜单按 Award 分组展示；这里只预览已经发布的结果事实。" action={<ActionLink href={`/races/${race.slug}/results`} variant="secondary">查看完整 Results</ActionLink>} />
            <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
              {race.awards.slice(0, 3).map((award) => <article key={award.id} className="ary-glass rounded-3xl p-6"><div className="flex items-center justify-between gap-3"><span className="rounded-full bg-amber-50 px-3 py-1 text-xs font-black text-amber-700">{award.name}</span><span className="text-lg font-black text-ary-blue-700">#{award.rank}</span></div><h3 className="mt-5 text-xl font-black text-ary-blue-950">{award.riderName}</h3>{award.workTitle && <p className="mt-2 text-sm font-semibold text-ary-blue-700">{award.workTitle}</p>}{award.reason && <p className="mt-3 line-clamp-3 text-sm leading-6 text-ary-muted">{award.reason}</p>}</article>)}
            </div>
            {race.hasPublishedReview && <div className="mt-5 rounded-3xl border border-ary-line bg-white/65 p-6"><div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between"><div><p className="text-xs font-black uppercase tracking-[0.15em] text-ary-blue-600">Published Review</p><h3 className="mt-2 text-xl font-black text-ary-blue-950">评审总结已经发布</h3><p className="mt-2 text-sm text-ary-muted">从最终结果继续理解获奖理由、典型案例和公开 Evidence。</p></div><ActionLink href={`/races/${race.slug}/review`}>阅读 Review</ActionLink></div></div>}
          </section>
        )}

        {race.riders.length > 0 && (
          <section id="riders" className="ary-section ary-content">
            <SectionHeading eyebrow="04 · Riders" title="从公开作品看见 Rider" description="Rider 档案由公开作品、奖项与公开 Evidence 推导，不泄露报名记录、账户信息或原始骑行数据。" />
            <div className="grid gap-5 md:grid-cols-2 xl:grid-cols-3">
              {race.riders.slice(0, 3).map((rider) => <RiderCard key={rider.id} rider={rider} />)}
            </div>
          </section>
        )}

        {race.announcements.length > 0 && (
          <section className="ary-section border-t border-ary-line/70 bg-white/35">
            <div className="ary-content">
              <SectionHeading eyebrow="05 · Announcements" title="赛事公告" description="只展示已经到达发布时间的公开公告。" />
              <div className="grid gap-4 lg:grid-cols-2">
                {race.announcements.map((announcement) => (
                  <article key={announcement.id} className="ary-glass rounded-3xl p-6">
                    <div className="flex items-start gap-4">
                      <span className="grid h-11 w-11 shrink-0 place-items-center rounded-2xl bg-ary-blue-100 text-ary-blue-700"><Megaphone className="h-5 w-5" aria-hidden="true" /></span>
                      <div>
                        <p className="text-xs font-semibold text-ary-muted">{formatDate(announcement.publishedAt)}</p>
                        <h3 className="mt-1 text-lg font-black text-ary-blue-950">{announcement.title}</h3>
                        <p className="mt-2 whitespace-pre-line text-sm leading-6 text-ary-muted">{announcement.body}</p>
                      </div>
                    </div>
                  </article>
                ))}
              </div>
            </div>
          </section>
        )}

        <section className="ary-section ary-content">
          <div className="rounded-[30px] bg-gradient-to-br from-ary-blue-950 to-ary-blue-700 p-7 text-white shadow-[0_26px_60px_rgba(6,22,74,0.24)] sm:p-10">
            <div className="flex flex-col gap-7 lg:flex-row lg:items-center lg:justify-between">
              <div>
                <p className="text-xs font-black uppercase tracking-[0.18em] text-ary-cyan">Next Move</p>
                <h2 className="mt-3 text-3xl font-black">继续观看 {race.title}</h2>
                <p className="mt-3 max-w-2xl leading-7 text-white/65">进入对应阶段页面，或回到 Race Gallery 选择另一条赛道。</p>
              </div>
              <div className="flex flex-col gap-3 sm:flex-row">
                {race.status === "running" && <ActionLink href={`/races/${race.slug}/live`} className="bg-white text-ary-blue-900 shadow-none hover:bg-ary-blue-100">进入 Live Hall</ActionLink>}
                {race.publishedAwardCount > 0 && <ActionLink href={`/races/${race.slug}/results`} className="bg-white text-ary-blue-900 shadow-none hover:bg-ary-blue-100">查看赛果</ActionLink>}
                <Link href="/" className="inline-flex min-h-11 items-center justify-center gap-2 rounded-xl border border-white/25 px-5 py-2.5 text-sm font-bold text-white hover:bg-white/10">返回 Gallery <ArrowRight className="h-4 w-4" aria-hidden="true" /></Link>
              </div>
            </div>
          </div>
        </section>
      </main>
    </PublicPageShell>
  );
}
