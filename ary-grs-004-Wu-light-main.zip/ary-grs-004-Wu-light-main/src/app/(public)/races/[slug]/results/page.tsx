import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowRight, Medal, Sparkles, Trophy, Users } from "lucide-react";
import { PublicPageShell } from "@/components/layout/PublicPageShell";
import { PublicSubpageHero } from "@/components/layout/PublicSubpageHero";
import { RiderCard } from "@/components/rider/RiderCard";
import { ActionLink } from "@/components/ui/ActionLink";
import { SectionHeading } from "@/components/ui/SectionHeading";
import { WorkCard } from "@/components/work/WorkCard";
import { getPublicRaceResults } from "@/lib/data-access";

export default async function ResultsPage({ params }: { params: { slug: string } }) {
  const data = await getPublicRaceResults(params.slug);
  if (!data) notFound();

  const groups = new Map<string, typeof data.awards>();
  for (const award of data.awards) groups.set(award.name, [...(groups.get(award.name) || []), award]);

  return (
    <PublicPageShell>
      <main id="main-content">
        <PublicSubpageHero
          eyebrow="Final Results · Published Facts"
          title={`${data.race.title} 赛果`}
          description="最终榜单仅来自已发布 Award。Live Projection、评审草稿与未发布评语不会进入赛果事实。"
          backHref={`/races/${data.race.slug}`}
          backLabel="返回 Race Page"
          meta={<><span className="inline-flex min-h-8 items-center gap-2 rounded-full bg-amber-50 px-3 text-xs font-black text-amber-700"><Trophy className="h-3.5 w-3.5" />{data.awards.length} Published Awards</span><span className="inline-flex min-h-8 items-center gap-2 rounded-full border border-ary-line bg-white/75 px-3 text-xs font-bold text-ary-muted"><Users className="h-3.5 w-3.5 text-ary-blue-600" />{data.race.metrics.riders} Riders</span></>}
          actions={<>{data.hasPublishedReview && <ActionLink href={`/races/${data.race.slug}/review`}>查看评审总结</ActionLink>}<ActionLink href={`/races/${data.race.slug}/works`} variant="secondary">全部作品</ActionLink></>}
        />

        <section className="ary-section ary-content">
          <SectionHeading eyebrow="01 · Award Leaderboards" title="按奖项分组的最终榜单" description="每一组按 Award.rank 排列；无公开 Work 的奖项仍保留获奖者，但不生成作品链接。" />
          <div className="grid gap-5 lg:grid-cols-2">
            {Array.from(groups.entries()).map(([name, awards]) => (
              <section key={name} className="ary-glass overflow-hidden rounded-3xl">
                <div className="flex items-center gap-3 border-b border-ary-line bg-white/55 px-6 py-5"><span className="grid h-10 w-10 place-items-center rounded-2xl bg-amber-50 text-amber-700"><Medal className="h-5 w-5" /></span><h2 className="text-xl font-black text-ary-blue-950">{name}</h2></div>
                <ol className="divide-y divide-ary-line">
                  {awards.sort((a, b) => a.rank - b.rank).map((award) => (
                    <li key={award.id} className="grid gap-4 px-6 py-5 sm:grid-cols-[56px_minmax(0,1fr)_auto] sm:items-center">
                      <span className="grid h-12 w-12 place-items-center rounded-2xl bg-ary-blue-100 text-lg font-black text-ary-blue-800">#{award.rank}</span>
                      <div><p className="font-black text-ary-blue-950">{award.riderName}</p>{award.reason && <p className="mt-1 line-clamp-2 text-sm leading-6 text-ary-muted">{award.reason}</p>}</div>
                      {award.workSlug && award.workTitle ? <Link href={`/works/${award.workSlug}`} className="inline-flex min-h-11 items-center gap-2 text-sm font-bold text-ary-blue-700 hover:text-ary-blue-950">{award.workTitle}<ArrowRight className="h-4 w-4" /></Link> : <span className="text-xs font-semibold text-ary-muted">Rider Award</span>}
                    </li>
                  ))}
                </ol>
              </section>
            ))}
          </div>
        </section>

        {data.winningWorks.length > 0 && <section className="ary-section border-y border-ary-line/70 bg-white/35"><div className="ary-content"><SectionHeading eyebrow="02 · Winning Works" title="获奖作品" description="从已发布 Award 关联到仍保持公开的作品。" /><div className="grid gap-5 md:grid-cols-2 xl:grid-cols-3">{data.winningWorks.map((work) => <WorkCard key={work.id} work={work} featured />)}</div></div></section>}

        {data.riders.length > 0 && <section className="ary-section ary-content"><SectionHeading eyebrow="03 · Riding Skill Highlights" title="从作品与奖项看见 Rider" description="能力标签仅由公开 Evidence 与获奖事实推导。" /><div className="grid gap-5 md:grid-cols-2 xl:grid-cols-3">{data.riders.slice(0, 3).map((rider) => <RiderCard key={rider.id} rider={rider} />)}</div></section>}

        <section className="ary-section ary-content"><div className="rounded-[30px] bg-gradient-to-br from-ary-blue-950 to-ary-blue-700 p-8 text-white shadow-ary sm:p-10"><Sparkles className="h-8 w-8 text-ary-cyan" /><h2 className="mt-5 text-3xl font-black">从结果继续进入复盘</h2><p className="mt-3 max-w-2xl leading-7 text-white/65">赛果说明谁获得了什么；Review 解释这些判断为何成立，并保留典型案例与公开证据。</p><div className="mt-7 flex flex-wrap gap-3">{data.hasPublishedReview && <ActionLink href={`/races/${data.race.slug}/review`} className="bg-white text-ary-blue-900 shadow-none">阅读 Review</ActionLink>}<ActionLink href={`/races/${data.race.slug}`} variant="secondary" className="border-white/20 bg-white/10 text-white">返回赛事</ActionLink></div></div></section>
      </main>
    </PublicPageShell>
  );
}
