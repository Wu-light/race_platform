"use client";

import { useEffect } from "react";
import { AlertTriangle, RotateCcw, Home } from "lucide-react";
import Link from "next/link";

export default function PublicError({
  error,
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  useEffect(() => {
    console.error("[ARY PublicError]", error);
  }, [error]);

  return (
    <div className="flex min-h-screen items-center justify-center bg-ary-canvas px-6">
      <div className="max-w-lg text-center">
        <AlertTriangle className="mx-auto h-14 w-14 text-amber-500" />
        <h1 className="mt-6 text-2xl font-black text-ary-blue-950">
          页面出错了
        </h1>
        <p className="mt-3 text-sm leading-relaxed text-ary-muted">
          请尝试刷新页面，或返回首页。
        </p>
        <div className="mt-6 flex items-center justify-center gap-3">
          <button
            onClick={reset}
            className="inline-flex items-center gap-2 rounded-xl border border-ary-line bg-white px-5 py-2.5 text-sm font-bold text-ary-blue-800 transition hover:border-ary-blue-800"
          >
            <RotateCcw className="h-4 w-4" />
            重试
          </button>
          <Link
            href="/"
            className="inline-flex items-center gap-2 rounded-xl bg-ary-blue-800 px-5 py-2.5 text-sm font-bold text-white transition hover:bg-ary-blue-700"
          >
            <Home className="h-4 w-4" />
            返回首页
          </Link>
        </div>
      </div>
    </div>
  );
}
