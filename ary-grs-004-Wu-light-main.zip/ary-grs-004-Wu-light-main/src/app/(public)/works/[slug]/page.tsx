import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowRight, CalendarDays, Code2, PlayCircle, Trophy, UserRound } from "lucide-react";
import { PublicPageShell } from "@/components/layout/PublicPageShell";
import { PublicSubpageHero } from "@/components/layout/PublicSubpageHero";
import { ActionLink } from "@/components/ui/ActionLink";
import { EmptyState } from "@/components/ui/EmptyState";
import { SafeMarkdown } from "@/components/ui/SafeMarkdown";
import { SectionHeading } from "@/components/ui/SectionHeading";
import { getPublicWorkBySlug } from "@/lib/data-access";
import { formatDate } from "@/lib/utils";

const evidenceLabels: Record<string, string> = {
  session_summary: "Session Summary",
  work: "Work Evidence",
  commit_pr: "Commit / PR",
  screenshot: "Screenshot",
  retrospective: "Retrospective",
  video: "Video",
};

export default async function WorkPage({ params }: { params: { slug: string } }) {
  const work = await getPublicWorkBySlug(params.slug);
  if (!work) notFound();

  return (
    <PublicPageShell>
      <main id="main-content">
        <PublicSubpageHero
          eyebrow="Work Detail · Public Asset"
          title={work.title}
          description={work.description}
          backHref={`/races/${work.race.slug}/works`}
          backLabel={`返回 ${work.race.title} 作品墙`}
          meta={<><span className="inline-flex min-h-8 items-center gap-2 rounded-full border border-ary-line bg-white/75 px-3 text-xs font-bold text-ary-muted"><UserRound className="h-3.5 w-3.5 text-ary-blue-600" />{work.author.name}</span><span className="inline-flex min-h-8 items-center gap-2 rounded-full border border-ary-line bg-white/75 px-3 text-xs font-bold text-ary-muted"><CalendarDays className="h-3.5 w-3.5 text-ary-blue-600" />更新于 {formatDate(work.updatedAt)}</span>{work.awards.map((award) => <span key={award} className="inline-flex min-h-8 items-center gap-2 rounded-full bg-amber-50 px-3 text-xs font-bold text-amber-700"><Trophy className="h-3.5 w-3.5" />{award}</span>)}</>}
          actions={<>{work.demoUrl && <ActionLink href={work.demoUrl} external>打开 Demo</ActionLink>}{work.githubUrl && <ActionLink href={work.githubUrl} variant="secondary" external>查看代码</ActionLink>}</>}
        />

        <section className="ary-section ary-content">
          <div className="grid gap-5 lg:grid-cols-[minmax(0,1.2fr)_minmax(300px,0.8fr)]">
            <article className="ary-glass rounded-3xl p-6 sm:p-8">
              <SectionHeading eyebrow="01 · Product Story" title="作品说明" description="作品公开内容保持原始语义，但不执行其中的 HTML 或脚本。" />
              <div className="grid gap-4 sm:grid-cols-2">
                <div className="rounded-2xl border border-ary-line bg-ary-blue-100/60 p-5"><p className="text-xs font-black uppercase tracking-[0.14em] text-ary-blue-600">Problem Definition</p><h3 className="mt-3 text-lg font-black leading-7 text-ary-blue-950">{work.raceChallenge}</h3></div>
                <div className="rounded-2xl border border-ary-line bg-white/70 p-5"><p className="text-xs font-black uppercase tracking-[0.14em] text-ary-blue-600">Solution</p><SafeMarkdown content={work.description} className="mt-3 text-sm" /></div>
              </div>
              <div className="mt-8 flex flex-wrap gap-3">
                {work.demoUrl && <ActionLink href={work.demoUrl} external>体验 Demo</ActionLink>}
                {work.videoUrl && <ActionLink href={work.videoUrl} variant="secondary" external><PlayCircle className="h-4 w-4" />观看演示</ActionLink>}
                {work.githubUrl && <ActionLink href={work.githubUrl} variant="quiet" external><Code2 className="h-4 w-4" />代码仓库</ActionLink>}
              </div>
            </article>
            <aside className="ary-glass rounded-3xl p-6 sm:p-8">
              <p className="text-xs font-black uppercase tracking-[0.16em] text-ary-blue-700">Race Context</p>
              <h2 className="mt-3 text-2xl font-black text-ary-blue-950">{work.race.title}</h2>
              <p className="mt-3 text-sm leading-6 text-ary-muted">作品始终保留赛事上下文，便于回到同场作品、赛果与复盘。</p>
              <div className="mt-6 space-y-3">
                <ActionLink href={`/races/${work.race.slug}`} className="w-full">查看 Race Page</ActionLink>
                <ActionLink href={`/races/${work.race.slug}/works`} variant="secondary" className="w-full">浏览同场作品</ActionLink>
              </div>
            </aside>
          </div>
        </section>

        <section className="ary-section border-y border-ary-line/70 bg-white/35">
          <div className="ary-content grid gap-5 lg:grid-cols-2">
            <article className="ary-glass rounded-3xl p-6 sm:p-8">
              <SectionHeading eyebrow="02 · Technical Approach" title="技术方案" />
              {work.techDescription ? <SafeMarkdown content={work.techDescription} /> : <EmptyState title="技术说明待补充" description="当前公开作品还没有提供技术方案摘要。" />}
            </article>
            <article className="ary-glass rounded-3xl p-6 sm:p-8">
              <SectionHeading eyebrow="03 · Riding Evidence" title="公开过程证据" description="只展示显式标记为 public 的 Evidence 摘要，不暴露原始 Session 或 sourceRef。" />
              {work.evidence.length > 0 ? <div className="space-y-3">{work.evidence.map((evidence) => <div key={evidence.id} className="rounded-2xl border border-ary-line bg-white/70 p-4"><p className="text-xs font-black uppercase tracking-[0.12em] text-ary-blue-600">{evidenceLabels[evidence.type] || evidence.type}</p><h3 className="mt-2 font-black text-ary-blue-950">{evidence.title}</h3>{evidence.summary && <p className="mt-2 text-sm leading-6 text-ary-muted">{evidence.summary}</p>}</div>)}</div> : <EmptyState title="暂无公开过程证据" description="Evidence 未公开时不会出现在作品详情中。" />}
            </article>
          </div>
        </section>

        <section className="ary-section ary-content">
          <SectionHeading eyebrow="04 · Awards & Author" title="奖项判断与作者档案" description="评审表原始分数和未发布评语不会公开；这里仅使用已发布 Award 的获奖说明。" />
          <div className="grid gap-5 lg:grid-cols-[1fr_0.7fr]">
            <div className="space-y-4">
              {work.awardDetails.length > 0 ? work.awardDetails.map((award) => <article key={award.id} className="ary-glass rounded-3xl p-6"><div className="flex items-start gap-4"><span className="grid h-12 w-12 shrink-0 place-items-center rounded-2xl bg-amber-50 font-black text-amber-700">#{award.rank}</span><div><p className="text-xs font-black uppercase tracking-[0.14em] text-amber-700">{award.name}</p><h3 className="mt-2 text-xl font-black text-ary-blue-950">{award.riderName}</h3>{award.reason && <p className="mt-3 text-sm leading-6 text-ary-muted">{award.reason}</p>}</div></div></article>) : <EmptyState title="尚无已发布奖项" description="奖项发布后会自动显示在这里。" />}
            </div>
            <aside className="rounded-3xl bg-gradient-to-br from-ary-blue-950 to-ary-blue-700 p-7 text-white shadow-ary">
              <UserRound className="h-8 w-8 text-ary-cyan" />
              <p className="mt-6 text-xs font-black uppercase tracking-[0.16em] text-white/55">Rider</p>
              <h2 className="mt-2 text-3xl font-black">{work.author.name}</h2>
              <p className="mt-2 text-white/65">{work.author.affiliation || "独立开发者"}</p>
              {work.author.slug && <Link href={`/riders/${work.author.slug}`} className="mt-7 inline-flex min-h-11 items-center gap-2 rounded-xl bg-white px-5 py-2.5 text-sm font-black text-ary-blue-900">查看 Rider 档案 <ArrowRight className="h-4 w-4" /></Link>}
            </aside>
          </div>
        </section>
      </main>
    </PublicPageShell>
  );
}
