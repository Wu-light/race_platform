import { redirect } from "next/navigation";
import { Monitor, MonitorUp, Tv } from "lucide-react";
import { auth } from "@/lib/auth";
import { getManagedRacesForScreen } from "@/lib/screen-data";
import type { ScreenMode } from "@/types";

const MODES: { key: ScreenMode; label: string; desc: string }[] = [
  { key: "jumbotron", label: "Jumbotron", desc: "大标题 + 关键数字" },
  { key: "billboard", label: "Billboard", desc: "信息看板布局" },
  { key: "live", label: "Live Feed", desc: "实时骑行动态" },
  { key: "leaderboard", label: "Leaderboard", desc: "大字体榜单" },
  { key: "works", label: "Works", desc: "作品轮播展示" },
  { key: "announcement", label: "Announcement", desc: "公告展示" },
];

export default async function ScreenConsolePage({
  searchParams,
}: {
  searchParams: { race?: string; mode?: string };
}) {
  const session = await auth();
  if (!session?.user?.id) {
    redirect("/login");
  }

  const races = await getManagedRacesForScreen(session.user.id);
  const selectedRace = searchParams.race || races[0]?.slug || "";
  const selectedMode = (searchParams.mode || "jumbotron") as ScreenMode;

  return (
    <div className="min-h-screen bg-ary-canvas">
      <div className="mx-auto max-w-[1400px] px-6 py-10">
        {/* Header */}
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div>
            <h1 className="text-3xl font-black text-ary-blue-950">Screen Console</h1>
            <p className="mt-1 text-sm text-ary-muted">
              选择赛事和展示模式，控制现场大屏
            </p>
          </div>

          {/* 全屏按钮 */}
          {selectedRace && (
            <a
              href={`/screen/${selectedRace}?mode=${selectedMode}`}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 rounded-xl bg-ary-blue-800 px-6 py-3 text-sm font-black text-white transition hover:bg-ary-blue-700"
            >
              <MonitorUp className="h-5 w-5" />
              在新窗口打开大屏
            </a>
          )}
        </div>

        {/* 赛事选择器 */}
        <div className="mt-8">
          <label className="text-sm font-bold text-ary-muted">选择赛事</label>
          <div className="mt-2 flex flex-wrap gap-2">
            {races.length > 0 ? (
              races.map((race) => (
                <a
                  key={race.slug}
                  href={`/console/screen?race=${race.slug}&mode=${selectedMode}`}
                  className={`rounded-xl border px-5 py-3 text-sm font-bold transition ${
                    selectedRace === race.slug
                      ? "border-ary-blue-800 bg-ary-blue-800 text-white"
                      : "border-ary-line bg-white text-ary-blue-800 hover:border-ary-blue-800"
                  }`}
                >
                  {race.title}
                  <span className="ml-2 text-xs opacity-60">({race.status})</span>
                </a>
              ))
            ) : (
              <p className="text-sm text-ary-muted">暂无可用赛事。你需要是 Organizer 或 Admin。</p>
            )}
          </div>
        </div>

        {/* 模式选择器 */}
        <div className="mt-8">
          <label className="text-sm font-bold text-ary-muted">展示模式</label>
          <div className="mt-2 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {MODES.map((mode) => {
              const isActive = selectedMode === mode.key;
              const href = selectedRace
                ? `/console/screen?race=${selectedRace}&mode=${mode.key}`
                : "#";
              return (
                <a
                  key={mode.key}
                  href={href}
                  className={`rounded-2xl border p-6 transition ${
                    isActive
                      ? "border-ary-cyan bg-ary-blue-50 ring-2 ring-ary-cyan/20"
                      : "border-ary-line bg-white hover:border-ary-blue-800"
                  } ${!selectedRace ? "pointer-events-none opacity-50" : ""}`}
                >
                  <div className="flex items-center gap-3">
                    {isActive ? (
                      <Tv className="h-5 w-5 text-ary-cyan" />
                    ) : (
                      <Monitor className="h-5 w-5 text-ary-muted" />
                    )}
                    <h3 className="text-lg font-black text-ary-blue-950">
                      {mode.label}
                    </h3>
                  </div>
                  <p className="mt-2 text-sm text-ary-muted">{mode.desc}</p>
                  {isActive && (
                    <span className="mt-3 inline-block rounded-full bg-ary-cyan/10 px-3 py-1 text-xs font-bold text-ary-cyan">
                      当前选中
                    </span>
                  )}
                </a>
              );
            })}
          </div>
        </div>

        {/* 预览区 */}
        {selectedRace && (
          <div className="mt-10 overflow-hidden rounded-3xl border-2 border-ary-line bg-ary-blue-950 shadow-2xl">
            <div className="flex items-center gap-2 border-b border-white/10 px-4 py-2">
              <span className="h-3 w-3 rounded-full bg-red-500" />
              <span className="h-3 w-3 rounded-full bg-amber-400" />
              <span className="h-3 w-3 rounded-full bg-emerald-500" />
              <span className="ml-2 text-xs text-white/40">
                Preview · {MODES.find((m) => m.key === selectedMode)?.label} ·{" "}
                {races.find((r) => r.slug === selectedRace)?.title}
              </span>
            </div>
            <iframe
              src={`/screen/${selectedRace}?mode=${selectedMode}`}
              className="h-[500px] w-full"
              title="大屏预览"
            />
          </div>
        )}
      </div>
    </div>
  );
}
