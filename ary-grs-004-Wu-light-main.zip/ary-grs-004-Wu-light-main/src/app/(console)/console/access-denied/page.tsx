import Link from "next/link";

export default function AccessDeniedPage() {
  return (
    <div className="flex min-h-[60vh] flex-col items-center justify-center px-6 text-center">
      <p className="text-xs font-semibold uppercase tracking-wider text-ary-muted">403</p>
      <h1 className="mt-2 text-2xl font-bold text-slate-900">Access Denied</h1>
      <p className="mt-2 max-w-md text-sm text-muted-foreground">
        You do not have permission to view this page. If you believe this is a mistake, please
        contact an admin to update your role.
      </p>
      <Link
        href="/console"
        className="mt-6 rounded-xl bg-ary-blue-800 px-5 py-2.5 text-xs font-bold text-white transition hover:bg-ary-blue-700"
      >
        Back to Console
      </Link>
    </div>
  );
}
