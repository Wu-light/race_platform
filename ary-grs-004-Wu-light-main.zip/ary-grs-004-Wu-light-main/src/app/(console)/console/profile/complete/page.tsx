import { auth } from "@/lib/auth";
import { redirect } from "next/navigation";
import { prisma } from "@/lib/db";

async function completeProfile(formData: FormData) {
  "use server";

  const session = await auth();
  if (!session?.user?.id) throw new Error("Unauthorized");

  const name = formData.get("name") as string;
  const school = formData.get("school") as string;
  const bio = formData.get("bio") as string;

  await prisma.user.update({
    where: { id: session.user.id },
    data: {
      name: name || undefined,
      school: school || undefined,
      bio: bio || undefined,
      profileCompleted: true,
    },
  });

  redirect("/console");
}

export default async function ProfileCompletePage() {
  const session = await auth();
  if (!session?.user) redirect("/login");

  const profileCompleted = (session.user as any).profileCompleted;
  if (profileCompleted) redirect("/console");

  return (
    <div className="mx-auto max-w-lg px-6 py-12">
      <h1 className="mb-2 text-2xl font-bold text-slate-900">Complete Your Profile</h1>
      <p className="mb-8 text-sm text-muted-foreground">
        Welcome to ARY! Fill in your details to get started.
      </p>

      <form action={completeProfile} className="space-y-5">
        <div>
          <label htmlFor="name" className="mb-1 block text-sm font-medium text-slate-700">Display Name</label>
          <input
            id="name"
            name="name"
            type="text"
            required
            defaultValue={session.user.name ?? ""}
            className="w-full rounded-lg border border-slate-300 px-4 py-2.5 text-sm focus:border-ary-blue-500 focus:outline-none focus:ring-2 focus:ring-ary-blue-200"
          />
        </div>

        <div>
          <label htmlFor="school" className="mb-1 block text-sm font-medium text-slate-700">School / Institution</label>
          <input
            id="school"
            name="school"
            type="text"
            className="w-full rounded-lg border border-slate-300 px-4 py-2.5 text-sm focus:border-ary-blue-500 focus:outline-none focus:ring-2 focus:ring-ary-blue-200"
          />
        </div>

        <div>
          <label htmlFor="bio" className="mb-1 block text-sm font-medium text-slate-700">Bio</label>
          <textarea
            id="bio"
            name="bio"
            rows={3}
            className="w-full rounded-lg border border-slate-300 px-4 py-2.5 text-sm focus:border-ary-blue-500 focus:outline-none focus:ring-2 focus:ring-ary-blue-200"
          />
        </div>

        <button
          type="submit"
          className="rounded-xl bg-ary-blue-800 px-6 py-2.5 text-sm font-bold text-white transition hover:bg-ary-blue-700"
        >
          Save & Continue
        </button>
      </form>
    </div>
  );
}
