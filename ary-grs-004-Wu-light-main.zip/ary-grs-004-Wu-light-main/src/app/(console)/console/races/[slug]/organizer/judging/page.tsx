import { OrganizerNav } from "@/components/layout/OrganizerNav";
import { prisma } from "@/lib/db";
import { auth } from "@/lib/auth";
import { redirect } from "next/navigation";
import { requireOrganizerOfRace } from "@/lib/permissions";
import {
  BarChart3,
  CheckCircle2,
  Clock,
  UserCheck,
  BookOpen,
} from "lucide-react";

export default async function OrganizerJudgingPage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const session = await auth();
  if (!session?.user) redirect("/login");

  const race = await prisma.race.findUnique({ where: { slug } });
  if (!race) redirect("/console/races");
  try {
    await requireOrganizerOfRace(race.id);
  } catch {
    redirect("/console/access-denied");
  }

  // Get all assignments for this race with judging records
  const assignments = await prisma.judgeAssignment.findMany({
    where: { work: { registration: { raceId: race.id } } },
    include: {
      work: {
        select: { id: true, title: true, slug: true },
      },
      judge: {
        select: { id: true, name: true },
      },
      judgingRecord: {
        select: {
          status: true,
          scoreResult: true,
          scoreRiding: true,
          submittedAt: true,
        },
      },
    },
    orderBy: { assignedAt: "desc" },
  });

  // Get all works that need judging
  const worksNeedingJudging = await prisma.work.findMany({
    where: {
      registration: { raceId: race.id },
      status: { in: ["submitted", "locked"] },
    },
    include: {
      registration: {
        include: {
          user: { select: { name: true } },
        },
      },
      judgeAssignments: {
        include: {
          judge: { select: { name: true } },
          judgingRecord: { select: { status: true } },
        },
      },
    },
    orderBy: { createdAt: "desc" },
  });

  // Compute stats
  const totalAssignments = assignments.length;
  const judgedAssignments = assignments.filter(
    (a) => a.judgingRecord?.status === "submitted",
  ).length;
  const draftAssignments = assignments.filter(
    (a) => a.judgingRecord?.status === "draft",
  ).length;
  const pendingAssignments = assignments.filter(
    (a) => !a.judgingRecord,
  ).length;

  // Per-judge stats
  const judgeStatsMap = new Map<
    string,
    {
      judgeName: string;
      total: number;
      submitted: number;
      draft: number;
      pending: number;
      avgScore: number;
      scoreCount: number;
    }
  >();

  assignments.forEach((a) => {
    const judgeId = a.judge.id;
    const name = a.judge.name ?? "未知评委";
    if (!judgeStatsMap.has(judgeId)) {
      judgeStatsMap.set(judgeId, {
        judgeName: name,
        total: 0,
        submitted: 0,
        draft: 0,
        pending: 0,
        avgScore: 0,
        scoreCount: 0,
      });
    }
    const stat = judgeStatsMap.get(judgeId)!;
    stat.total += 1;

    if (!a.judgingRecord) {
      stat.pending += 1;
    } else if (a.judgingRecord.status === "submitted") {
      stat.submitted += 1;
      if (a.judgingRecord.scoreResult != null) {
        stat.avgScore += a.judgingRecord.scoreResult;
        stat.scoreCount += 1;
      }
    } else if (a.judgingRecord.status === "draft") {
      stat.draft += 1;
    }
  });

  judgeStatsMap.forEach((stat) => {
    if (stat.scoreCount > 0) {
      stat.avgScore = Math.round((stat.avgScore / stat.scoreCount) * 10) / 10;
    }
  });

  const judgeStats = Array.from(judgeStatsMap.values());

  // Works that have no submitted judging record
  const unjudgedWorks = worksNeedingJudging.filter((w) => {
    return !w.judgeAssignments.some(
      (ja) => ja.judgingRecord?.status === "submitted",
    );
  });

  const completionPercent =
    totalAssignments > 0
      ? Math.round((judgedAssignments / totalAssignments) * 100)
      : 0;

  return (
    <div className="mx-auto max-w-[1440px] px-6 py-8">
      <OrganizerNav slug={slug} current="judging" />

      <div className="mb-6">
        <h1 className="text-2xl font-bold text-slate-900">评审进度</h1>
        <p className="mt-1 text-sm text-ary-muted">
          跟踪评审完成情况
        </p>
      </div>

      {/* Overall Progress */}
      <div className="mb-8 rounded-xl border border-ary-line bg-white p-6">
        <div className="mb-4 flex items-center justify-between">
          <h2 className="flex items-center gap-2 text-base font-semibold text-slate-900">
            <BarChart3 className="h-5 w-5 text-ary-blue-700" />
            总体进度
          </h2>
          <span className="text-2xl font-bold text-ary-blue-800">
            {completionPercent}%
          </span>
        </div>
        <div className="mb-4 h-3 w-full overflow-hidden rounded-full bg-slate-100">
          <div
            className="h-full rounded-full bg-ary-blue-700 transition-all duration-500"
            style={{ width: `${completionPercent}%` }}
          />
        </div>
        <div className="grid grid-cols-3 gap-4 text-center text-sm">
          <div>
            <p className="text-2xl font-bold text-green-600">
              {judgedAssignments}
            </p>
            <p className="text-xs text-ary-muted">已完成</p>
          </div>
          <div>
            <p className="text-2xl font-bold text-yellow-600">
              {draftAssignments}
            </p>
            <p className="text-xs text-ary-muted">评审中</p>
          </div>
          <div>
            <p className="text-2xl font-bold text-ary-muted">
              {pendingAssignments}
            </p>
            <p className="text-xs text-ary-muted">未开始</p>
          </div>
        </div>
      </div>

      {/* Per-judge Progress */}
      <div className="mb-8 space-y-4">
        <h2 className="flex items-center gap-2 text-base font-semibold text-slate-900">
          <UserCheck className="h-5 w-5 text-ary-blue-700" />
          评委进度
        </h2>

        {judgeStats.length === 0 ? (
          <div className="flex flex-col items-center rounded-xl border border-ary-line bg-white py-12 text-center">
            <UserCheck className="mb-2 h-8 w-8 text-ary-muted" />
            <p className="text-sm text-ary-muted">暂无评委分配</p>
          </div>
        ) : (
          judgeStats.map((stat) => {
            const jCompletion =
              stat.total > 0
                ? Math.round((stat.submitted / stat.total) * 100)
                : 0;
            return (
              <div
                key={stat.judgeName}
                className="rounded-xl border border-ary-line bg-white p-5"
              >
                <div className="mb-2 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="flex h-8 w-8 items-center justify-center rounded-full bg-ary-blue-100 text-xs font-bold text-ary-blue-800">
                      {stat.judgeName[0]?.toUpperCase() ?? "?"}
                    </div>
                    <span className="font-medium text-slate-900">
                      {stat.judgeName}
                    </span>
                  </div>
                  <div className="flex items-center gap-3 text-xs text-ary-muted">
                    <span>
                      已完成 {stat.submitted}/{stat.total}
                    </span>
                    {stat.scoreCount > 0 && (
                      <span className="font-medium text-ary-blue-700">
                        均分 {stat.avgScore}
                      </span>
                    )}
                  </div>
                </div>
                <div className="h-2 w-full overflow-hidden rounded-full bg-slate-100">
                  <div
                    className="h-full rounded-full bg-green-500 transition-all duration-500"
                    style={{ width: `${jCompletion}%` }}
                  />
                </div>
                <div className="mt-1 flex gap-4 text-xs text-ary-muted">
                  <span className="flex items-center gap-1">
                    <CheckCircle2 className="h-3 w-3 text-green-600" />
                    {stat.submitted} 已完成
                  </span>
                  <span className="flex items-center gap-1">
                    <Clock className="h-3 w-3 text-yellow-600" />
                    {stat.draft} 评审中
                  </span>
                  <span className="flex items-center gap-1">
                    <Clock className="h-3 w-3 text-gray-400" />
                    {stat.pending} 未开始
                  </span>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Unjudged Works */}
      <div className="rounded-xl border border-ary-line bg-white p-6">
        <h2 className="mb-4 flex items-center gap-2 text-base font-semibold text-slate-900">
          <BookOpen className="h-5 w-5 text-ary-blue-700" />
          待评审作品 ({unjudgedWorks.length})
        </h2>

        {unjudgedWorks.length === 0 ? (
          <div className="flex flex-col items-center py-8 text-center">
            <CheckCircle2 className="mb-2 h-8 w-8 text-green-600" />
            <p className="text-sm text-green-700">所有作品已完成评审</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead>
                <tr className="border-b border-ary-line bg-slate-50">
                  <th className="px-4 py-3 font-medium text-ary-muted">
                    作品
                  </th>
                  <th className="px-4 py-3 font-medium text-ary-muted">
                    作者
                  </th>
                  <th className="px-4 py-3 font-medium text-ary-muted">
                    状态
                  </th>
                  <th className="px-4 py-3 font-medium text-ary-muted">
                    已分配评委
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-ary-line">
                {unjudgedWorks.map((w) => {
                  const assignedJudges = w.judgeAssignments.map(
                    (ja) => ja.judge?.name ?? "未知",
                  );
                  const hasDraft = w.judgeAssignments.some(
                    (ja) => ja.judgingRecord?.status === "draft",
                  );

                  return (
                    <tr
                      key={w.id}
                      className="transition-colors hover:bg-slate-50"
                    >
                      <td className="px-4 py-3 font-medium text-slate-900">
                        {w.title}
                      </td>
                      <td className="px-4 py-3 text-xs text-ary-muted">
                        {w.registration.user.name ?? "未知"}
                      </td>
                      <td className="px-4 py-3">
                        {hasDraft ? (
                          <span className="inline-flex items-center rounded-full bg-yellow-100 px-2 py-0.5 text-xs font-semibold text-yellow-700">
                            评审中
                          </span>
                        ) : (
                          <span className="inline-flex items-center rounded-full bg-gray-100 px-2 py-0.5 text-xs font-semibold text-gray-600">
                            等待评审
                          </span>
                        )}
                      </td>
                      <td className="px-4 py-3 text-xs text-ary-muted">
                        {assignedJudges.length > 0
                          ? assignedJudges.join(", ")
                          : "未分配"}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
