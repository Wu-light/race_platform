import { auth } from "@/lib/auth";
import { prisma } from "@/lib/db";
import { RiderNav } from "@/components/layout/RiderNav";
import { redirect } from "next/navigation";
import { formatDateTime } from "@/lib/utils";
import { EmptyState } from "@/components/ui/EmptyState";
import { MetricCard } from "@/components/ui/MetricCard";
import { ActionLink } from "@/components/ui/ActionLink";
import {
  Star,
  MessageSquareText,
  Trophy,
  CalendarDays,
  ScrollText,
  Medal,
} from "lucide-react";

function ScoreStars({ score, max = 10 }: { score: number; max?: number }) {
  const fullStars = Math.round(score);
  return (
    <div className="flex items-center gap-1">
      {Array.from({ length: max }, (_, i) => (
        <Star
          key={i}
          className={`h-4 w-4 ${
            i < fullStars
              ? "fill-amber-400 text-amber-400"
              : "fill-slate-200 text-slate-200"
          }`}
        />
      ))}
      <span className="ml-2 text-sm font-semibold text-slate-900">
        {score.toFixed(1)} / {max}
      </span>
    </div>
  );
}

function AwardBadge({ awardName, rank }: { awardName: string; rank: number }) {
  const medalColors: Record<number, string> = {
    1: "border-amber-300 bg-amber-50 text-amber-800",
    2: "border-slate-300 bg-slate-50 text-slate-700",
    3: "border-orange-300 bg-orange-50 text-orange-800",
  };
  return (
    <div
      className={`inline-flex items-center gap-2 rounded-xl border px-4 py-2 ${
        medalColors[rank] ?? "border-purple-200 bg-purple-50 text-purple-700"
      }`}
    >
      <Medal className="h-5 w-5" />
      <div>
        <p className="text-sm font-bold">{awardName}</p>
        <p className="text-xs opacity-80">第 {rank} 名</p>
      </div>
    </div>
  );
}

export default async function RiderReviewPage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const session = await auth();
  if (!session?.user) redirect("/login");
  const userId = session.user.id!;

  const race = await prisma.race.findUnique({ where: { slug } });
  if (!race) {
    return (
      <div className="mx-auto max-w-[1440px] px-6 py-8">
        <RiderNav slug={slug} current="review" />
        <p className="text-lg font-medium text-ary-muted">赛事不存在</p>
      </div>
    );
  }

  const registration = await prisma.registration.findUnique({
    where: {
      userId_raceId: { userId, raceId: race.id },
    },
    include: {
      work: true,
      awards: true,
    },
  });

  if (!registration) {
    return (
      <div className="mx-auto max-w-[1440px] px-6 py-8">
        <RiderNav slug={slug} current="review" />
        <EmptyState
          title="尚未报名"
          description="请先报名参赛，提交作品后方可查看评审结果。"
        />
        <ActionLink href={`/console/races/${slug}/rider`}>
          前往报名
        </ActionLink>
      </div>
    );
  }

  // Get judging records through the work's judge assignments
  const work = registration.work;
  const judgeAssignments = work
    ? await prisma.judgeAssignment.findMany({
        where: { workId: work.id },
        include: {
          judge: {
            select: { id: true, name: true, avatar: true },
          },
          judgingRecord: true,
        },
      })
    : [];

  const hasJudgingRecords = judgeAssignments.some(
    (ja) => ja.judgingRecord !== null,
  );

  // Calculate average scores
  const scores = judgeAssignments
    .filter((ja) => ja.judgingRecord)
    .map((ja) => ja.judgingRecord!);
  const avgScoreResult =
    scores.length > 0
      ? scores.reduce((sum, r) => sum + (r.scoreResult ?? 0), 0) / scores.length
      : null;
  const avgScoreRiding =
    scores.length > 0
      ? scores.reduce((sum, r) => sum + (r.scoreRiding ?? 0), 0) / scores.length
      : null;

  return (
    <div className="mx-auto max-w-[1440px] px-6 py-8">
      <RiderNav slug={slug} current="review" />

      <div className="mb-6">
        <h1 className="text-2xl font-bold text-slate-900">评审结果</h1>
        <p className="mt-1 text-sm text-ary-muted">
          查看评委对你的作品评价与评分
        </p>
      </div>

      {/* No judging yet */}
      {!hasJudgingRecords && (
        <div className="space-y-6">
          <div className="rounded-2xl border border-amber-200 bg-amber-50 p-6">
            <div className="flex items-center gap-2">
              <ScrollText className="h-5 w-5 text-amber-500" />
              <h2 className="text-lg font-bold text-amber-900">评审进行中</h2>
            </div>
            <p className="mt-2 text-sm text-amber-700">
              你的作品已提交，评委正在评审中。请耐心等待评审结果。
            </p>
          </div>
          {work && (
            <div className="rounded-2xl border border-ary-line bg-white p-6">
              <h3 className="mb-2 text-sm font-bold uppercase tracking-wider text-ary-muted">
                你的作品
              </h3>
              <p className="text-lg font-semibold text-slate-900">{work.title}</p>
              <p className="mt-1 text-sm text-ary-muted">
                提交时间: {formatDateTime(work.createdAt)}
              </p>
            </div>
          )}
        </div>
      )}

      {/* Has judging records */}
      {hasJudgingRecords && (
        <div className="space-y-6">
          {/* Score Overview */}
          <div className="grid gap-4 sm:grid-cols-2">
            <MetricCard
              label="作品评分"
              value={avgScoreResult !== null ? `${avgScoreResult.toFixed(1)} / 10` : "--"}
              hint="所有评委的平均分"
            />
            <MetricCard
              label="骑乘评分"
              value={avgScoreRiding !== null ? `${avgScoreRiding.toFixed(1)} / 10` : "--"}
              hint="所有评委的平均分"
            />
          </div>

          {/* Judge Comments */}
          <div className="rounded-2xl border border-ary-line bg-white">
            <div className="border-b border-ary-line px-6 py-4">
              <h2 className="text-lg font-bold text-slate-900">评委评语</h2>
            </div>
            <div className="divide-y divide-ary-line">
              {judgeAssignments.map((ja) => {
                if (!ja.judgingRecord) return null;
                return (
                  <div key={ja.id} className="px-6 py-4">
                    <div className="mb-3 flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <div className="flex h-8 w-8 items-center justify-center rounded-full bg-ary-blue-100 text-xs font-bold text-ary-blue-700">
                          {(ja.judge.name ?? "J")[0]}
                        </div>
                        <span className="text-sm font-semibold text-slate-900">
                          {ja.judge.name ?? "评委"}
                        </span>
                      </div>
                      {ja.judgingRecord.submittedAt && (
                        <span className="text-xs text-ary-muted">
                          {formatDateTime(ja.judgingRecord.submittedAt)}
                        </span>
                      )}
                    </div>
                    <div className="mb-3 grid gap-4 sm:grid-cols-2">
                      <div>
                        <p className="text-xs font-semibold uppercase tracking-wider text-ary-muted">
                          作品评分
                        </p>
                        <ScoreStars
                          score={ja.judgingRecord.scoreResult ?? 0}
                        />
                      </div>
                      <div>
                        <p className="text-xs font-semibold uppercase tracking-wider text-ary-muted">
                          骑乘评分
                        </p>
                        <ScoreStars
                          score={ja.judgingRecord.scoreRiding ?? 0}
                        />
                      </div>
                    </div>
                    {ja.judgingRecord.comments && (
                      <div className="mt-2 rounded-xl bg-slate-50 p-3">
                        <div className="flex items-center gap-1.5 text-xs font-semibold text-ary-muted">
                          <MessageSquareText className="h-3.5 w-3.5" />
                          评语
                        </div>
                        <p className="mt-1 text-sm leading-6 text-slate-700">
                          {ja.judgingRecord.comments}
                        </p>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>

          {/* Work Info */}
          {work && (
            <div className="rounded-2xl border border-ary-line bg-white p-6">
              <h3 className="mb-2 text-sm font-bold uppercase tracking-wider text-ary-muted">
                作品信息
              </h3>
              <p className="text-lg font-semibold text-slate-900">{work.title}</p>
              {work.demoUrl && (
                <a
                  href={work.demoUrl}
                  target="_blank"
                  rel="noreferrer"
                  className="mt-1 inline-flex items-center gap-1 text-sm text-ary-blue-700 hover:underline"
                >
                  Demo 链接
                </a>
              )}
              {work.githubUrl && (
                <a
                  href={work.githubUrl}
                  target="_blank"
                  rel="noreferrer"
                  className="ml-3 mt-1 inline-flex items-center gap-1 text-sm text-ary-blue-700 hover:underline"
                >
                  GitHub 链接
                </a>
              )}
            </div>
          )}
        </div>
      )}

      {/* Awards */}
      {registration.awards.length > 0 && (
        <div className="mt-6">
          <div className="mb-3 flex items-center gap-2">
            <Trophy className="h-5 w-5 text-amber-500" />
            <h2 className="text-lg font-bold text-slate-900">获奖情况</h2>
          </div>
          <div className="flex flex-wrap gap-3">
            {registration.awards.map((award) => (
              <AwardBadge
                key={award.id}
                awardName={award.awardName}
                rank={award.rank}
              />
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
