import { OrganizerNav } from "@/components/layout/OrganizerNav";
import { prisma } from "@/lib/db";
import { auth } from "@/lib/auth";
import { redirect } from "next/navigation";
import { requireOrganizerOfRace } from "@/lib/permissions";
import {
  FileText,
  CheckCircle2,
  Clock,
  AlertCircle,
  Eye,
} from "lucide-react";
import Link from "next/link";
import { GenerateReportButton } from "./GenerateReportButton";

function ReportStatusBadge({ status }: { status: string }) {
  const config: Record<string, { label: string; classes: string }> = {
    draft: { label: "草稿", classes: "bg-gray-100 text-gray-600" },
    generated: { label: "已生成", classes: "bg-blue-100 text-blue-700" },
    reviewed: { label: "已审核", classes: "bg-yellow-100 text-yellow-700" },
    published: { label: "已发布", classes: "bg-green-100 text-green-700" },
  };
  const c = config[status] ?? {
    label: status,
    classes: "bg-gray-100 text-gray-700",
  };
  return (
    <span
      className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-semibold ${c.classes}`}
    >
      {c.label}
    </span>
  );
}

function ReportTypeLabel({ type }: { type: string }) {
  const config: Record<string, string> = {
    rider_report: "选手报告",
    race_report: "赛事报告",
    review_summary: "评审总结",
  };
  return config[type] ?? type;
}

export default async function OrganizerReportsPage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const session = await auth();
  if (!session?.user) redirect("/login");

  const race = await prisma.race.findUnique({ where: { slug } });
  if (!race) redirect("/console/races");
  try {
    await requireOrganizerOfRace(race.id);
  } catch {
    redirect("/console/access-denied");
  }

  const reports = await prisma.report.findMany({
    where: { raceId: race.id },
    include: {
      subjectRegistration: {
        include: {
          user: {
            select: { id: true, name: true },
          },
        },
      },
    },
    orderBy: { createdAt: "desc" },
  });

  const statusCounts: Record<string, number> = {};
  reports.forEach((r) => {
    statusCounts[r.status] = (statusCounts[r.status] ?? 0) + 1;
  });

  return (
    <div className="mx-auto max-w-[1440px] px-6 py-8">
      <OrganizerNav slug={slug} current="reports" />

      <div className="mb-6 flex flex-wrap items-start justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">报告管理</h1>
          <p className="mt-1 text-sm text-ary-muted">
            查看和管理赛事相关报告
          </p>
        </div>
        <GenerateReportButton raceId={race.id} hasReports={reports.length > 0} />
      </div>

      {/* Summary Cards */}
      <div className="mb-6 grid grid-cols-2 gap-4 sm:grid-cols-4">
        <div className="rounded-xl border border-ary-line bg-white p-4">
          <div className="flex items-center gap-3">
            <FileText className="h-5 w-5 text-ary-blue-700" />
            <div>
              <p className="text-xs text-ary-muted">总报告</p>
              <p className="text-xl font-bold text-slate-900">
                {reports.length}
              </p>
            </div>
          </div>
        </div>
        <div className="rounded-xl border border-ary-line bg-white p-4">
          <div className="flex items-center gap-3">
            <Clock className="h-5 w-5 text-yellow-600" />
            <div>
              <p className="text-xs text-ary-muted">草稿</p>
              <p className="text-xl font-bold text-slate-900">
                {statusCounts["draft"] ?? 0}
              </p>
            </div>
          </div>
        </div>
        <div className="rounded-xl border border-ary-line bg-white p-4">
          <div className="flex items-center gap-3">
            <CheckCircle2 className="h-5 w-5 text-green-600" />
            <div>
              <p className="text-xs text-ary-muted">已发布</p>
              <p className="text-xl font-bold text-slate-900">
                {statusCounts["published"] ?? 0}
              </p>
            </div>
          </div>
        </div>
        <div className="rounded-xl border border-ary-line bg-white p-4">
          <div className="flex items-center gap-3">
            <AlertCircle className="h-5 w-5 text-blue-600" />
            <div>
              <p className="text-xs text-ary-muted">已生成</p>
              <p className="text-xl font-bold text-slate-900">
                {statusCounts["generated"] ?? 0}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Reports Table */}
      {reports.length === 0 ? (
        <div className="flex flex-col items-center rounded-xl border border-ary-line bg-white py-16 text-center">
          <FileText className="mb-3 h-12 w-12 text-ary-muted" />
          <p className="text-sm text-ary-muted">暂无报告</p>
          <p className="mt-1 text-xs text-ary-muted">
            点击上方"生成全部报告"按钮生成赛事报告、选手报告和评审总结
          </p>
        </div>
      ) : (
        <div className="overflow-x-auto rounded-xl border border-ary-line bg-white">
          <table className="w-full text-left text-sm">
            <thead>
              <tr className="border-b border-ary-line bg-slate-50">
                <th className="px-4 py-3 font-medium text-ary-muted">类型</th>
                <th className="px-4 py-3 font-medium text-ary-muted">
                  关联选手
                </th>
                <th className="px-4 py-3 font-medium text-ary-muted">状态</th>
                <th className="px-4 py-3 font-medium text-ary-muted">
                  生成时间
                </th>
                <th className="px-4 py-3 font-medium text-ary-muted">
                  发布时间
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-ary-line">
              {reports.map((r) => (
                <tr
                  key={r.id}
                  className="transition-colors hover:bg-slate-50"
                >
                  <td className="px-4 py-3">
                    <ReportTypeLabel type={r.type} />
                  </td>
                  <td className="px-4 py-3 text-xs text-ary-muted">
                    {r.subjectRegistration?.user?.name ?? "-"}
                  </td>
                  <td className="px-4 py-3">
                    <ReportStatusBadge status={r.status} />
                  </td>
                  <td className="px-4 py-3 text-xs text-ary-muted">
                    {r.generatedAt
                      ? new Date(r.generatedAt).toLocaleDateString("zh-CN", {
                          year: "numeric",
                          month: "short",
                          day: "numeric",
                          hour: "2-digit",
                        })
                      : "-"}
                  </td>
                  <td className="px-4 py-3 text-xs text-ary-muted">
                    {r.publishedAt
                      ? new Date(r.publishedAt).toLocaleDateString("zh-CN", {
                          year: "numeric",
                          month: "short",
                          day: "numeric",
                          hour: "2-digit",
                        })
                      : "-"}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
