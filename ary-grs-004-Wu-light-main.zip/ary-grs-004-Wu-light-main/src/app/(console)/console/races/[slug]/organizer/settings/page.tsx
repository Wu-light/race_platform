import { OrganizerNav } from "@/components/layout/OrganizerNav";
import { prisma } from "@/lib/db";
import { auth } from "@/lib/auth";
import { redirect } from "next/navigation";
import { requireOrganizerOfRace } from "@/lib/permissions";
import { SettingsForm } from "./SettingsForm";

export default async function OrganizerSettingsPage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const session = await auth();
  if (!session?.user) redirect("/login");

  const race = await prisma.race.findUnique({ where: { slug } });
  if (!race) redirect("/console/races");
  try {
    await requireOrganizerOfRace(race.id);
  } catch {
    redirect("/console/access-denied");
  }

  // Parse JSON fields
  let schedule: Record<string, string> = {};
  try {
    schedule = JSON.parse(race.schedule);
  } catch {}

  let awardNames: string[] = [];
  try {
    const parsed = JSON.parse(race.awardSettings);
    awardNames = Array.isArray(parsed) ? parsed : [];
  } catch {}

  let submissionFields: string[] = [];
  let submissionFormat = "";
  let submissionDesc = "";
  try {
    const subReq = JSON.parse(race.submissionRequirements);
    submissionFields = Array.isArray(subReq.fields) ? subReq.fields : [];
    submissionFormat = subReq.format ?? "";
    submissionDesc = subReq.description ?? "";
  } catch {}

  const initialData = {
    title: race.title,
    subtitle: race.subtitle ?? "",
    description: race.description,
    challenge: race.challenge,
    rules: race.rules,
    status: race.status,
    visibility: race.visibility,
    schedule,
    awardNames,
    submissionFields,
    submissionFormat,
    submissionDesc,
  };

  return (
    <div className="mx-auto max-w-[1440px] px-6 py-8">
      <OrganizerNav slug={slug} current="settings" />
      <SettingsForm slug={slug} initialData={initialData} />
    </div>
  );
}
