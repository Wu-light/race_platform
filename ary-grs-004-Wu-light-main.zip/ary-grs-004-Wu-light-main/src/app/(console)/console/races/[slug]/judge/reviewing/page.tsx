"use client";

import { useSearchParams, useParams } from "next/navigation";
import Link from "next/link";
import { useEffect, useState, useCallback } from "react";
import { JudgeNav } from "@/components/layout/JudgeNav";
import { SafeMarkdown } from "@/components/ui/SafeMarkdown";
import { ActionLink } from "@/components/ui/ActionLink";
import { ArrowLeft, ExternalLink, Save, Send, Loader2, AlertCircle } from "lucide-react";

// ---- Types ----

interface WorkData {
  id: string;
  title: string;
  description: string;
  demoUrl: string | null;
  githubUrl: string | null;
  videoUrl: string | null;
  techDescription: string | null;
  createdAt: string;
  registration: {
    user: {
      id: string;
      name: string | null;
      avatar: string | null;
      school: string | null;
      company: string | null;
    };
    race: {
      id: string;
      slug: string;
      title: string;
    };
  };
}

interface JudgingRecordData {
  id: string;
  scoreResult: number | null;
  scoreRiding: number | null;
  comments: string | null;
  status: string;
  submittedAt: string | null;
}

interface AssignmentData {
  id: string;
  workId: string;
  judgeId: string;
  work: WorkData;
  judgingRecord: JudgingRecordData | null;
}

// ---- Scoring guidance labels ----

const RESULT_SCORE_LABELS: Record<number, string> = {
  1: "极差 - 未完成基本功能",
  2: "较差 - 基本功能有重大缺陷",
  3: "欠佳 - 基本功能不完整",
  4: "一般 - 基本功能完成，缺乏亮点",
  5: "中等 - 功能完整，有基本质量",
  6: "良好 - 功能完整，有一定设计",
  7: "优秀 - 功能完整，设计精良",
  8: "出色 - 高质量完成，有创新点",
  9: "杰出 - 极具创新，完成度极高",
  10: "完美 - 无可挑剔的标杆作品",
};

const RIDING_SCORE_LABELS: Record<number, string> = {
  1: "极差 - 几乎未使用Agent工具链",
  2: "较差 - Agent使用有明显问题",
  3: "欠佳 - Agent使用不熟练",
  4: "一般 - 能基本使用Agent工具",
  5: "中等 - Agent使用较为流畅",
  6: "良好 - 能有效利用Agent能力",
  7: "优秀 - 熟练运用Agent工具链",
  8: "出色 - 高效运用Agent，流程完善",
  9: "杰出 - 大师级Agent驾驭能力",
  10: "完美 - Agent Rides的标杆表现",
};

// ---- Score Select Component ----

function ScoreSelect({
  label,
  value,
  onChange,
  scoreLabels,
  disabled,
  required,
}: {
  label: string;
  value: number | null;
  onChange: (v: number | null) => void;
  scoreLabels: Record<number, string>;
  disabled: boolean;
  required?: boolean;
}) {
  return (
    <div>
      <label className="mb-1.5 block text-sm font-semibold text-ary-blue-900">
        {label}
        {required && <span className="ml-1 text-red-500">*</span>}
      </label>
      <select
        value={value ?? ""}
        onChange={(e) => onChange(e.target.value ? Number(e.target.value) : null)}
        disabled={disabled}
        className="w-full rounded-lg border border-ary-line bg-white px-3 py-2.5 text-sm text-ary-blue-950 transition-colors focus:border-ary-blue-500 focus:outline-none focus:ring-2 focus:ring-ary-blue-100 disabled:cursor-not-allowed disabled:bg-slate-50 disabled:text-slate-400"
      >
        <option value="">-- 请选择评分 --</option>
        {Array.from({ length: 10 }, (_, i) => i + 1).map((score) => (
          <option key={score} value={score}>
            {score} 分 - {scoreLabels[score]}
          </option>
        ))}
      </select>
    </div>
  );
}

// ---- Main Page Component ----

export default function JudgeReviewingPage() {
  const params = useParams<{ slug: string }>();
  const slug = params.slug;
  const searchParams = useSearchParams();
  const workId = searchParams.get("workId");

  // Form state
  const [scoreResult, setScoreResult] = useState<number | null>(null);
  const [scoreRiding, setScoreRiding] = useState<number | null>(null);
  const [comments, setComments] = useState("");

  // Data state
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [assignment, setAssignment] = useState<AssignmentData | null>(null);
  const [work, setWork] = useState<WorkData | null>(null);
  const [existingRecord, setExistingRecord] = useState<JudgingRecordData | null>(null);
  const [submitSuccess, setSubmitSuccess] = useState(false);

  // Fetch data
  const fetchData = useCallback(async () => {
    if (!workId || !slug) return;

    setLoading(true);
    setError(null);

    try {
      // Fetch assignment for this work and current judge
      const assignmentRes = await fetch(
        `/api/judge-assignments?workId=${encodeURIComponent(workId)}`,
      );
      if (!assignmentRes.ok) {
        const errData = await assignmentRes.json();
        throw new Error(errData.error || "获取评审信息失败");
      }
      const assignments: AssignmentData[] = await assignmentRes.json();

      if (assignments.length === 0) {
        throw new Error("您没有被分配评审此作品");
      }

      const found = assignments[0];
      setAssignment(found);
      setWork(found.work);
      setExistingRecord(found.judgingRecord);

      // Populate form with existing draft data
      if (found.judgingRecord) {
        setScoreResult(found.judgingRecord.scoreResult);
        setScoreRiding(found.judgingRecord.scoreRiding);
        setComments(found.judgingRecord.comments || "");
      }
    } catch (err: any) {
      setError(err.message || "加载数据失败");
    } finally {
      setLoading(false);
    }
  }, [workId, slug]);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  // Handle save/submit
  const handleSubmit = async (action: "draft" | "submit") => {
    if (!assignment) return;
    setSubmitting(true);
    setSubmitSuccess(false);
    setError(null);

    try {
      const res = await fetch("/api/judging-records", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          assignmentId: assignment.id,
          scoreResult: scoreResult ?? null,
          scoreRiding: scoreRiding ?? null,
          comments: comments || null,
          action,
        }),
      });

      if (!res.ok) {
        const errData = await res.json();
        throw new Error(errData.error || "保存评审记录失败");
      }

      const record: JudgingRecordData = await res.json();
      setExistingRecord(record);
      setSubmitSuccess(true);

      if (action === "submit") {
        // Reload to show read-only state
        await fetchData();
      }
    } catch (err: any) {
      setError(err.message || "保存失败");
    } finally {
      setSubmitting(false);
    }
  };

  const isReadOnly = existingRecord?.status === "submitted";
  const isDraft = existingRecord?.status === "draft";

  // ---- Loading State ----
  if (loading) {
    return (
      <div className="mx-auto max-w-[1440px] px-6 py-8">
        <JudgeNav slug={slug} current="reviewing" />
        <div className="flex items-center justify-center py-20">
          <Loader2 className="h-8 w-8 animate-spin text-ary-blue-500" />
          <span className="ml-3 text-sm text-ary-muted">加载作品中...</span>
        </div>
      </div>
    );
  }

  // ---- Error State ----
  if (error && !work) {
    return (
      <div className="mx-auto max-w-[1440px] px-6 py-8">
        <JudgeNav slug={slug} current="reviewing" />
        <div className="rounded-xl border border-red-200 bg-red-50 p-6 text-center">
          <AlertCircle className="mx-auto h-8 w-8 text-red-500" />
          <h3 className="mt-3 text-lg font-semibold text-red-800">加载失败</h3>
          <p className="mt-2 text-sm text-red-600">{error}</p>
          <div className="mt-4 flex justify-center gap-3">
            <ActionLink href={`/console/races/${slug}/judge`} variant="secondary">
              <ArrowLeft className="h-4 w-4" />
              返回作品列表
            </ActionLink>
            <button
              onClick={fetchData}
              className="inline-flex min-h-11 items-center justify-center gap-2 rounded-xl bg-ary-blue-700 px-5 py-2.5 text-sm font-semibold text-white transition-colors hover:bg-ary-blue-800"
            >
              重新加载
            </button>
          </div>
        </div>
      </div>
    );
  }

  // ---- No workId State ----
  if (!workId) {
    return (
      <div className="mx-auto max-w-[1440px] px-6 py-8">
        <JudgeNav slug={slug} current="reviewing" />
        <div className="rounded-xl border border-dashed border-ary-line-strong bg-white/60 px-6 py-12 text-center">
          <AlertCircle className="mx-auto h-7 w-7 text-ary-amber-500" />
          <h3 className="mt-4 font-bold text-ary-blue-950">未指定作品</h3>
          <p className="mx-auto mt-2 max-w-md text-sm leading-6 text-ary-muted">
            请从评审作品列表中选择一个作品进行评审。
          </p>
          <div className="mt-6">
            <ActionLink href={`/console/races/${slug}/judge`} variant="primary">
              <ArrowLeft className="h-4 w-4" />
              返回作品列表
            </ActionLink>
          </div>
        </div>
      </div>
    );
  }

  // ---- Main Content ----
  return (
    <div className="mx-auto max-w-[1440px] px-6 py-8">
      <JudgeNav slug={slug} current="reviewing" />

      {/* Back Link */}
      <Link
        href={`/console/races/${slug}/judge`}
        className="mb-6 inline-flex items-center gap-1.5 text-sm font-medium text-ary-blue-700 transition-colors hover:text-ary-blue-900"
      >
        <ArrowLeft className="h-4 w-4" />
        返回作品列表
      </Link>

      {submitSuccess && (
        <div className="mb-6 rounded-lg border border-emerald-200 bg-emerald-50 px-4 py-3 text-sm font-medium text-emerald-800">
          {existingRecord?.status === "submitted"
            ? "评审结果已成功提交！"
            : "草稿已保存"}
        </div>
      )}

      {error && (
        <div className="mb-6 rounded-lg border border-red-200 bg-red-50 px-4 py-3 text-sm font-medium text-red-700">
          {error}
        </div>
      )}

      {work && (
        <>
          {/* Work Details Panel */}
          <div className="mb-8 rounded-xl border border-ary-line bg-white p-6 shadow-sm">
            <h2 className="mb-1 text-xl font-bold text-ary-blue-950">
              {work.title}
            </h2>
            <p className="mb-4 text-sm text-ary-muted">
              作者：{work.registration.user.name || "未知"}
              {(work.registration.user.school ||
                work.registration.user.company) &&
                ` · ${work.registration.user.school || work.registration.user.company}`}
            </p>

            {/* Links */}
            <div className="mb-6 flex flex-wrap gap-3">
              {work.demoUrl && (
                <a
                  href={work.demoUrl}
                  target="_blank"
                  rel="noreferrer"
                  className="inline-flex items-center gap-1.5 rounded-lg border border-ary-line bg-white px-3 py-1.5 text-xs font-medium text-ary-blue-700 transition-colors hover:bg-ary-blue-50"
                >
                  <ExternalLink className="h-3.5 w-3.5" />
                  体验 Demo
                </a>
              )}
              {work.githubUrl && (
                <a
                  href={work.githubUrl}
                  target="_blank"
                  rel="noreferrer"
                  className="inline-flex items-center gap-1.5 rounded-lg border border-ary-line bg-white px-3 py-1.5 text-xs font-medium text-ary-blue-700 transition-colors hover:bg-ary-blue-50"
                >
                  <ExternalLink className="h-3.5 w-3.5" />
                  GitHub 仓库
                </a>
              )}
              {work.videoUrl && (
                <a
                  href={work.videoUrl}
                  target="_blank"
                  rel="noreferrer"
                  className="inline-flex items-center gap-1.5 rounded-lg border border-ary-line bg-white px-3 py-1.5 text-xs font-medium text-ary-blue-700 transition-colors hover:bg-ary-blue-50"
                >
                  <ExternalLink className="h-3.5 w-3.5" />
                  演示视频
                </a>
              )}
            </div>

            {/* Description */}
            <div className="mb-6">
              <h3 className="mb-2 text-sm font-semibold text-ary-blue-900">
                作品描述
              </h3>
              <div className="rounded-lg bg-slate-50 p-4">
                <SafeMarkdown content={work.description} />
              </div>
            </div>

            {/* Tech Description */}
            {work.techDescription && (
              <div>
                <h3 className="mb-2 text-sm font-semibold text-ary-blue-900">
                  技术说明
                </h3>
                <div className="rounded-lg bg-slate-50 p-4">
                  <SafeMarkdown content={work.techDescription} />
                </div>
              </div>
            )}
          </div>

          {/* Scoring Form */}
          <div className="rounded-xl border border-ary-line bg-white p-6 shadow-sm">
            <h3 className="mb-1 text-lg font-bold text-ary-blue-950">
              评审评分
            </h3>
            <p className="mb-6 text-sm text-ary-muted">
              {isReadOnly
                ? "已提交的评审记录，不可修改"
                : isDraft
                  ? "继续完善您的评审，完成后点击提交"
                  : "请对作品进行评审打分"}
            </p>

            {isReadOnly && existingRecord?.submittedAt && (
              <p className="mb-4 text-xs text-ary-muted">
                提交时间：{new Date(existingRecord.submittedAt).toLocaleString("zh-CN")}
              </p>
            )}

            <div className="space-y-6">
              {/* Score Result */}
              <ScoreSelect
                label="作品结果评分"
                value={scoreResult}
                onChange={setScoreResult}
                scoreLabels={RESULT_SCORE_LABELS}
                disabled={isReadOnly}
                required={!isReadOnly}
              />

              {/* Score Riding */}
              <ScoreSelect
                label="骑行能力评分"
                value={scoreRiding}
                onChange={setScoreRiding}
                scoreLabels={RIDING_SCORE_LABELS}
                disabled={isReadOnly}
                required={!isReadOnly}
              />

              {/* Comments */}
              <div>
                <label className="mb-1.5 block text-sm font-semibold text-ary-blue-900">
                  评审评语
                </label>
                <textarea
                  value={comments}
                  onChange={(e) => setComments(e.target.value)}
                  disabled={isReadOnly}
                  rows={6}
                  placeholder="请输入对作品的评价、建议或意见..."
                  className="w-full rounded-lg border border-ary-line bg-white px-3 py-2.5 text-sm text-ary-blue-950 transition-colors placeholder:text-slate-400 focus:border-ary-blue-500 focus:outline-none focus:ring-2 focus:ring-ary-blue-100 disabled:cursor-not-allowed disabled:bg-slate-50 disabled:text-slate-400"
                />
                <p className="mt-1 text-xs text-ary-muted">
                  评语将展示给参赛者，请客观公正地给出评价建议
                </p>
              </div>

              {/* Action Buttons */}
              {!isReadOnly && (
                <div className="flex flex-wrap gap-3 border-t border-ary-line pt-6">
                  <button
                    onClick={() => handleSubmit("draft")}
                    disabled={submitting}
                    className="inline-flex min-h-11 items-center justify-center gap-2 rounded-xl border border-ary-line bg-white px-5 py-2.5 text-sm font-semibold text-ary-blue-900 shadow-sm transition-colors hover:bg-slate-50 disabled:cursor-not-allowed disabled:opacity-50"
                  >
                    {submitting ? (
                      <Loader2 className="h-4 w-4 animate-spin" />
                    ) : (
                      <Save className="h-4 w-4" />
                    )}
                    {isDraft ? "保存草稿" : "暂存草稿"}
                  </button>
                  <button
                    onClick={() => handleSubmit("submit")}
                    disabled={submitting || scoreResult === null || scoreRiding === null}
                    className="inline-flex min-h-11 items-center justify-center gap-2 rounded-xl bg-gradient-to-br from-ary-blue-800 to-ary-blue-500 px-5 py-2.5 text-sm font-semibold text-white shadow-[0_12px_30px_rgba(7,91,236,0.22)] transition-all hover:-translate-y-0.5 hover:shadow-[0_16px_34px_rgba(7,91,236,0.3)] disabled:cursor-not-allowed disabled:opacity-50 disabled:hover:translate-y-0"
                  >
                    {submitting ? (
                      <Loader2 className="h-4 w-4 animate-spin" />
                    ) : (
                      <Send className="h-4 w-4" />
                    )}
                    提交评审
                  </button>
                </div>
              )}
            </div>
          </div>
        </>
      )}
    </div>
  );
}
