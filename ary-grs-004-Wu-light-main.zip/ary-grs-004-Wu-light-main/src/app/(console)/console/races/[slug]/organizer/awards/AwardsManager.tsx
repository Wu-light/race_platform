"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { setAward, removeAward, publishAwards, unpublishAwards } from "../actions";
import {
  Trophy,
  Plus,
  Trash2,
  Send,
  EyeOff,
  CheckCircle2,
  AlertCircle,
} from "lucide-react";

interface AwardEntry {
  id: string;
  awardName: string;
  rank: number;
  registrationId: string;
  workId: string | null;
  decisionReason: string | null;
  publishedAt: string | null;
  userName: string;
  workTitle: string | null;
}

interface RegistrationItem {
  id: string;
  userName: string;
  workTitle: string | null;
  workId: string | null;
}

export function AwardsManager({
  slug,
  awardCategories,
  initialAwards,
  registrations,
}: {
  slug: string;
  awardCategories: string[];
  initialAwards: AwardEntry[];
  registrations: RegistrationItem[];
}) {
  const router = useRouter();

  const [awards, setAwards] = useState<AwardEntry[]>(initialAwards);
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState<{
    type: "success" | "error";
    text: string;
  } | null>(null);

  // Form state
  const [selectedCategory, setSelectedCategory] = useState("");
  const [selectedRegId, setSelectedRegId] = useState("");
  const [rank, setRank] = useState(1);
  const [decisionReason, setDecisionReason] = useState("");

  const refreshData = async () => {
    router.refresh();
  };

  const handleAddAward = async () => {
    if (!selectedCategory || !selectedRegId) {
      setMessage({ type: "error", text: "请选择奖项类别和选手" });
      return;
    }
    setSaving(true);
    setMessage(null);
    try {
      const reg = registrations.find((r) => r.id === selectedRegId);
      await setAward(slug, {
        awardName: selectedCategory,
        registrationId: selectedRegId,
        rank,
        workId: reg?.workId ?? undefined,
        decisionReason: decisionReason || undefined,
      });
      setMessage({ type: "success", text: "奖项已设置" });
      setSelectedRegId("");
      setRank(1);
      setDecisionReason("");
      await refreshData();
    } catch (err: any) {
      setMessage({ type: "error", text: err.message ?? "设置失败" });
    } finally {
      setSaving(false);
    }
  };

  const handleRemoveAward = async (awardId: string) => {
    try {
      await removeAward(awardId, slug);
      setAwards(awards.filter((a) => a.id !== awardId));
      setMessage({ type: "success", text: "奖项已移除" });
    } catch (err: any) {
      setMessage({ type: "error", text: err.message ?? "移除失败" });
    }
  };

  const handlePublish = async () => {
    try {
      await publishAwards(slug);
      setAwards(
        awards.map((a) => ({
          ...a,
          publishedAt: a.publishedAt ?? new Date().toISOString(),
        })),
      );
      setMessage({ type: "success", text: "奖项已发布" });
    } catch (err: any) {
      setMessage({ type: "error", text: err.message ?? "发布失败" });
    }
  };

  const handleUnpublish = async () => {
    try {
      await unpublishAwards(slug);
      setAwards(awards.map((a) => ({ ...a, publishedAt: null })));
      setMessage({ type: "success", text: "奖项已取消发布" });
    } catch (err: any) {
      setMessage({ type: "error", text: err.message ?? "取消发布失败" });
    }
  };

  const allPublished = awards.length > 0 && awards.every((a) => a.publishedAt);
  const anyPublished = awards.some((a) => a.publishedAt);

  return (
    <div>
      <div className="mb-6 flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">奖项管理</h1>
          <p className="mt-1 text-sm text-ary-muted">
            设置和发布赛事奖项
          </p>
        </div>
        <div className="flex gap-2">
          {allPublished ? (
            <button
              onClick={handleUnpublish}
              className="inline-flex items-center gap-1.5 rounded-lg border border-yellow-200 bg-white px-4 py-2 text-sm font-semibold text-yellow-700 transition-colors hover:bg-yellow-50"
            >
              <EyeOff className="h-4 w-4" />
              取消发布
            </button>
          ) : (
            <button
              onClick={handlePublish}
              disabled={awards.length === 0}
              className="inline-flex items-center gap-1.5 rounded-lg bg-green-600 px-4 py-2 text-sm font-semibold text-white transition-colors hover:bg-green-700 disabled:opacity-50"
            >
              <Send className="h-4 w-4" />
              发布所有奖项
            </button>
          )}
        </div>
      </div>

      {message && (
        <div
          className={`mb-6 flex items-center gap-2 rounded-lg border p-3 text-sm ${
            message.type === "success"
              ? "border-green-200 bg-green-50 text-green-700"
              : "border-red-200 bg-red-50 text-red-700"
          }`}
        >
          {message.type === "success" ? (
            <CheckCircle2 className="h-4 w-4" />
          ) : (
            <AlertCircle className="h-4 w-4" />
          )}
          {message.text}
        </div>
      )}

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        {/* Add Award Form */}
        <div className="rounded-xl border border-ary-line bg-white p-6">
          <h2 className="mb-4 flex items-center gap-2 text-base font-semibold text-slate-900">
            <Plus className="h-5 w-5 text-ary-blue-700" />
            添加奖项
          </h2>

          <div className="space-y-4">
            <div>
              <label className="mb-1 block text-sm font-medium text-slate-700">
                奖项类别
              </label>
              <select
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
                className="w-full rounded-lg border border-ary-line px-3 py-2 text-sm focus:border-ary-blue-500 focus:outline-none focus:ring-1 focus:ring-ary-blue-500"
              >
                <option value="">-- 请选择 --</option>
                {awardCategories.map((cat) => (
                  <option key={cat} value={cat}>
                    {cat}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="mb-1 block text-sm font-medium text-slate-700">
                获奖选手
              </label>
              <select
                value={selectedRegId}
                onChange={(e) => setSelectedRegId(e.target.value)}
                className="w-full rounded-lg border border-ary-line px-3 py-2 text-sm focus:border-ary-blue-500 focus:outline-none focus:ring-1 focus:ring-ary-blue-500"
              >
                <option value="">-- 请选择 --</option>
                {registrations.map((r) => (
                  <option key={r.id} value={r.id}>
                    {r.userName} {r.workTitle ? `(${r.workTitle})` : ""}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="mb-1 block text-sm font-medium text-slate-700">
                名次
              </label>
              <input
                type="number"
                min={1}
                max={100}
                value={rank}
                onChange={(e) => setRank(parseInt(e.target.value) || 1)}
                className="w-full rounded-lg border border-ary-line px-3 py-2 text-sm focus:border-ary-blue-500 focus:outline-none focus:ring-1 focus:ring-ary-blue-500"
              />
            </div>

            <div>
              <label className="mb-1 block text-sm font-medium text-slate-700">
                获奖理由
              </label>
              <textarea
                value={decisionReason}
                onChange={(e) => setDecisionReason(e.target.value)}
                rows={3}
                className="w-full rounded-lg border border-ary-line px-3 py-2 text-sm focus:border-ary-blue-500 focus:outline-none focus:ring-1 focus:ring-ary-blue-500"
                placeholder="可选"
              />
            </div>

            <button
              onClick={handleAddAward}
              disabled={saving || !selectedCategory || !selectedRegId}
              className="inline-flex w-full items-center justify-center gap-1.5 rounded-lg bg-ary-blue-700 px-4 py-2 text-sm font-semibold text-white transition-colors hover:bg-ary-blue-800 disabled:opacity-50"
            >
              {saving ? "保存中..." : "添加奖项"}
            </button>
          </div>
        </div>

        {/* Right: Current Awards */}
        <div className="lg:col-span-2">
          <div className="rounded-xl border border-ary-line bg-white">
            <div className="border-b border-ary-line px-6 py-4">
              <h2 className="flex items-center gap-2 text-base font-semibold text-slate-900">
                <Trophy className="h-5 w-5 text-ary-blue-700" />
                当前奖项 ({awards.length})
                {anyPublished && (
                  <span className="inline-flex items-center rounded-full bg-green-100 px-2 py-0.5 text-xs font-semibold text-green-700">
                    已发布
                  </span>
                )}
              </h2>
            </div>

            {awards.length === 0 ? (
              <div className="flex flex-col items-center py-12 text-center">
                <Trophy className="mb-2 h-8 w-8 text-ary-muted" />
                <p className="text-sm text-ary-muted">暂无奖项设置</p>
              </div>
            ) : (
              <div className="divide-y divide-ary-line">
                {awardCategories.map((cat) => {
                  const catAwards = awards
                    .filter((a) => a.awardName === cat)
                    .sort((a, b) => a.rank - b.rank);

                  if (catAwards.length === 0) return null;

                  return (
                    <div key={cat} className="p-6">
                      <h3 className="mb-3 text-sm font-semibold text-slate-900">
                        {cat}
                      </h3>
                      <table className="w-full text-left text-sm">
                        <thead>
                          <tr className="border-b border-ary-line">
                            <th className="pb-2 font-medium text-ary-muted">
                              名次
                            </th>
                            <th className="pb-2 font-medium text-ary-muted">
                              选手
                            </th>
                            <th className="pb-2 font-medium text-ary-muted">
                              作品
                            </th>
                            <th className="pb-2 font-medium text-ary-muted">
                              理由
                            </th>
                            <th className="pb-2 font-medium text-ary-muted">
                              状态
                            </th>
                            <th className="pb-2 font-medium text-ary-muted">
                              操作
                            </th>
                          </tr>
                        </thead>
                        <tbody>
                          {catAwards.map((a) => (
                            <tr
                              key={a.id}
                              className="border-b border-ary-line/50"
                            >
                              <td className="py-2 font-bold text-ary-blue-700">
                                #{a.rank}
                              </td>
                              <td className="py-2 text-slate-700">
                                {a.userName}
                              </td>
                              <td className="py-2 text-xs text-ary-muted">
                                {a.workTitle ?? "-"}
                              </td>
                              <td className="py-2 text-xs text-ary-muted">
                                {a.decisionReason ?? "-"}
                              </td>
                              <td className="py-2">
                                {a.publishedAt ? (
                                  <span className="inline-flex items-center rounded-full bg-green-100 px-2 py-0.5 text-xs font-semibold text-green-700">
                                    已发布
                                  </span>
                                ) : (
                                  <span className="inline-flex items-center rounded-full bg-yellow-100 px-2 py-0.5 text-xs font-semibold text-yellow-700">
                                    未发布
                                  </span>
                                )}
                              </td>
                              <td className="py-2">
                                <button
                                  onClick={() => handleRemoveAward(a.id)}
                                  className="inline-flex items-center gap-1 rounded-lg bg-red-50 px-2.5 py-1.5 text-xs font-medium text-red-700 transition-colors hover:bg-red-100"
                                >
                                  <Trash2 className="h-3.5 w-3.5" />
                                  移除
                                </button>
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
