import { OrganizerNav } from "@/components/layout/OrganizerNav";
import { prisma } from "@/lib/db";
import { auth } from "@/lib/auth";
import { redirect } from "next/navigation";
import { requireOrganizerOfRace } from "@/lib/permissions";
import { Users, AlertTriangle, CheckCircle, Wifi } from "lucide-react";

function StatusBadge({ status }: { status: string }) {
  const config: Record<string, { label: string; classes: string }> = {
    not_configured: { label: "未配置", classes: "bg-gray-100 text-gray-600" },
    connected: { label: "已连接", classes: "bg-blue-100 text-blue-700" },
    active: { label: "活跃", classes: "bg-green-100 text-green-700" },
    failed: { label: "异常", classes: "bg-red-100 text-red-700" },
  };
  const c = config[status] ?? {
    label: status,
    classes: "bg-gray-100 text-gray-700",
  };
  return (
    <span
      className={`inline-flex items-center rounded-full px-2 py-0.5 text-xs font-semibold ${c.classes}`}
    >
      {c.label}
    </span>
  );
}

function WorkStatusBadge({ status }: { status: string | null }) {
  if (!status) return <span className="text-xs text-ary-muted">-</span>;
  const config: Record<string, { label: string; classes: string }> = {
    draft: { label: "草稿", classes: "bg-gray-100 text-gray-600" },
    submitted: { label: "已提交", classes: "bg-green-100 text-green-700" },
    locked: { label: "已锁定", classes: "bg-purple-100 text-purple-700" },
    hidden: { label: "已隐藏", classes: "bg-yellow-100 text-yellow-700" },
  };
  const c = config[status] ?? {
    label: status,
    classes: "bg-gray-100 text-gray-700",
  };
  return (
    <span
      className={`inline-flex items-center rounded-full px-2 py-0.5 text-xs font-semibold ${c.classes}`}
    >
      {c.label}
    </span>
  );
}

export default async function OrganizerRidersPage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const session = await auth();
  if (!session?.user) redirect("/login");

  const race = await prisma.race.findUnique({ where: { slug } });
  if (!race) redirect("/console/races");
  try {
    await requireOrganizerOfRace(race.id);
  } catch {
    redirect("/console/access-denied");
  }

  // Get approved registrations with user info, race project, and work
  const riders = await prisma.registration.findMany({
    where: { raceId: race.id, status: "approved" },
    include: {
      user: {
        select: {
          id: true,
          name: true,
          email: true,
          avatar: true,
          githubId: true,
          school: true,
          company: true,
        },
      },
      raceProject: {
        select: {
          id: true,
          aggregateIngestionStatus: true,
          connectionHealth: true,
          lastSyncedAt: true,
        },
      },
      work: {
        select: {
          id: true,
          title: true,
          status: true,
          slug: true,
        },
      },
    },
    orderBy: { submittedAt: "asc" },
  });

  // Count riders per CA status
  const caStatusCounts: Record<string, number> = {};
  riders.forEach((r) => {
    const st = r.raceProject?.aggregateIngestionStatus ?? "not_configured";
    caStatusCounts[st] = (caStatusCounts[st] ?? 0) + 1;
  });

  return (
    <div className="mx-auto max-w-[1440px] px-6 py-8">
      <OrganizerNav slug={slug} current="riders" />

      <div className="mb-6">
        <h1 className="text-2xl font-bold text-slate-900">参赛选手名单</h1>
        <p className="mt-1 text-sm text-ary-muted">
          已批准的参赛选手 ({riders.length} 人)
        </p>
      </div>

      {/* Summary Cards */}
      <div className="mb-6 grid grid-cols-2 gap-4 sm:grid-cols-4">
        <div className="rounded-xl border border-ary-line bg-white p-4">
          <div className="flex items-center gap-3">
            <Users className="h-5 w-5 text-ary-blue-700" />
            <div>
              <p className="text-xs text-ary-muted">总选手数</p>
              <p className="text-xl font-bold text-slate-900">
                {riders.length}
              </p>
            </div>
          </div>
        </div>
        <div className="rounded-xl border border-ary-line bg-white p-4">
          <div className="flex items-center gap-3">
            <Wifi className="h-5 w-5 text-green-600" />
            <div>
              <p className="text-xs text-ary-muted">CA 已连接</p>
              <p className="text-xl font-bold text-slate-900">
                {(caStatusCounts["connected"] ?? 0) +
                  (caStatusCounts["active"] ?? 0)}
              </p>
            </div>
          </div>
        </div>
        <div className="rounded-xl border border-ary-line bg-white p-4">
          <div className="flex items-center gap-3">
            <AlertTriangle className="h-5 w-5 text-red-600" />
            <div>
              <p className="text-xs text-ary-muted">CA 异常</p>
              <p className="text-xl font-bold text-slate-900">
                {caStatusCounts["failed"] ?? 0}
              </p>
            </div>
          </div>
        </div>
        <div className="rounded-xl border border-ary-line bg-white p-4">
          <div className="flex items-center gap-3">
            <CheckCircle className="h-5 w-5 text-ary-blue-700" />
            <div>
              <p className="text-xs text-ary-muted">有作品</p>
              <p className="text-xl font-bold text-slate-900">
                {riders.filter((r) => r.work).length}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Riders Table */}
      {riders.length === 0 ? (
        <div className="flex flex-col items-center rounded-xl border border-ary-line bg-white py-16 text-center">
          <Users className="mb-3 h-12 w-12 text-ary-muted" />
          <p className="text-sm text-ary-muted">暂无已批准的参赛选手</p>
        </div>
      ) : (
        <div className="overflow-x-auto rounded-xl border border-ary-line bg-white">
          <table className="w-full text-left text-sm">
            <thead>
              <tr className="border-b border-ary-line bg-slate-50">
                <th className="px-4 py-3 font-medium text-ary-muted">选手</th>
                <th className="px-4 py-3 font-medium text-ary-muted">
                  学校/公司
                </th>
                <th className="px-4 py-3 font-medium text-ary-muted">
                  CA 状态
                </th>
                <th className="px-4 py-3 font-medium text-ary-muted">
                  作品状态
                </th>
                <th className="px-4 py-3 font-medium text-ary-muted">
                  最后同步
                </th>
                <th className="px-4 py-3 font-medium text-ary-muted">
                  风险指标
                </th>
              </tr>
            </thead>
            <tbody className="divide-y divide-ary-line">
              {riders.map((reg) => {
                const healthStr = reg.raceProject?.connectionHealth ?? "{}";
                let health: Record<string, any> = {};
                try {
                  health = JSON.parse(healthStr);
                } catch {
                  // ignore
                }
                const riskLevel =
                  health.riskLevel ?? (reg.raceProject ? "low" : "unknown");

                return (
                  <tr
                    key={reg.id}
                    className="transition-colors hover:bg-slate-50"
                  >
                    <td className="px-4 py-3">
                      <div className="flex items-center gap-2">
                        <div className="flex h-8 w-8 items-center justify-center rounded-full bg-ary-blue-100 text-xs font-bold text-ary-blue-800">
                          {reg.user.name?.[0]?.toUpperCase() ?? "?"}
                        </div>
                        <div>
                          <p className="font-medium text-slate-900">
                            {reg.user.name ?? "未知用户"}
                          </p>
                          {reg.user.email && (
                            <p className="text-xs text-ary-muted">
                              {reg.user.email}
                            </p>
                          )}
                        </div>
                      </div>
                    </td>
                    <td className="px-4 py-3 text-xs text-ary-muted">
                      {reg.user.school ?? reg.user.company ?? "-"}
                    </td>
                    <td className="px-4 py-3">
                      <StatusBadge
                        status={
                          reg.raceProject?.aggregateIngestionStatus ??
                          "not_configured"
                        }
                      />
                    </td>
                    <td className="px-4 py-3">
                      <WorkStatusBadge status={reg.work?.status ?? null} />
                    </td>
                    <td className="px-4 py-3 text-xs text-ary-muted">
                      {reg.raceProject?.lastSyncedAt
                        ? new Date(
                            reg.raceProject.lastSyncedAt,
                          ).toLocaleDateString("zh-CN", {
                            month: "short",
                            day: "numeric",
                            hour: "2-digit",
                            minute: "2-digit",
                          })
                        : "-"}
                    </td>
                    <td className="px-4 py-3">
                      <RiskIndicator level={riskLevel} />
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

function RiskIndicator({ level }: { level: string }) {
  const config: Record<string, { label: string; classes: string; dot: string }> = {
    low: {
      label: "低风险",
      classes: "bg-green-50 text-green-700",
      dot: "bg-green-500",
    },
    medium: {
      label: "中风险",
      classes: "bg-yellow-50 text-yellow-700",
      dot: "bg-yellow-500",
    },
    high: {
      label: "高风险",
      classes: "bg-red-50 text-red-700",
      dot: "bg-red-500",
    },
    unknown: {
      label: "未知",
      classes: "bg-gray-50 text-gray-600",
      dot: "bg-gray-400",
    },
  };
  const c = config[level] ?? config.unknown;
  return (
    <span
      className={`inline-flex items-center gap-1.5 rounded-full px-2.5 py-0.5 text-xs font-semibold ${c.classes}`}
    >
      <span className={`h-1.5 w-1.5 rounded-full ${c.dot}`} />
      {c.label}
    </span>
  );
}
