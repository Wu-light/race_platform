"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import {
  approveRegistration,
  rejectRegistration,
  batchApproveRegistrations,
} from "../actions";
import { CheckCircle, XCircle, CheckCheck } from "lucide-react";

interface RegistrationItem {
  id: string;
  status: string;
  userName: string;
  userEmail: string;
  userAvatar: string;
  githubId: number;
  school: string | null;
  company: string | null;
  submittedAt: string;
  workTitle: string | null;
  workStatus: string | null;
}

function StatusBadge({ status }: { status: string }) {
  const config: Record<string, { label: string; classes: string }> = {
    submitted: { label: "待审核", classes: "bg-yellow-100 text-yellow-700" },
    approved: { label: "已批准", classes: "bg-green-100 text-green-700" },
    rejected: { label: "已拒绝", classes: "bg-red-100 text-red-700" },
    withdrawn: { label: "已撤回", classes: "bg-gray-100 text-gray-600" },
  };
  const c = config[status] ?? { label: status, classes: "bg-gray-100 text-gray-700" };
  return (
    <span
      className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-semibold ${c.classes}`}
    >
      {c.label}
    </span>
  );
}

export function RegistrationActions({
  registrations,
  slug,
}: {
  registrations: RegistrationItem[];
  slug: string;
}) {
  const router = useRouter();
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  const [processingId, setProcessingId] = useState<string | null>(null);
  const [batchProcessing, setBatchProcessing] = useState(false);

  const handleApprove = async (id: string) => {
    setProcessingId(id);
    try {
      await approveRegistration(id, slug);
      router.refresh();
    } catch (err) {
      console.error(err);
    } finally {
      setProcessingId(null);
    }
  };

  const handleReject = async (id: string) => {
    setProcessingId(id);
    try {
      await rejectRegistration(id, slug);
      router.refresh();
    } catch (err) {
      console.error(err);
    } finally {
      setProcessingId(null);
    }
  };

  const handleBatchApprove = async () => {
    if (selectedIds.size === 0) return;
    setBatchProcessing(true);
    try {
      await batchApproveRegistrations(Array.from(selectedIds), slug);
      setSelectedIds(new Set());
      router.refresh();
    } catch (err) {
      console.error(err);
    } finally {
      setBatchProcessing(false);
    }
  };

  const toggleSelect = (id: string) => {
    const next = new Set(selectedIds);
    if (next.has(id)) {
      next.delete(id);
    } else {
      next.add(id);
    }
    setSelectedIds(next);
  };

  const toggleSelectAll = () => {
    const submitted = registrations.filter((r) => r.status === "submitted");
    if (selectedIds.size === submitted.length) {
      setSelectedIds(new Set());
    } else {
      setSelectedIds(new Set(submitted.map((r) => r.id)));
    }
  };

  const submittedRegs = registrations.filter((r) => r.status === "submitted");

  if (registrations.length === 0) {
    return (
      <div className="flex flex-col items-center rounded-xl border border-ary-line bg-white py-16 text-center">
        <UsersIcon className="mb-3 h-12 w-12 text-ary-muted" />
        <p className="text-sm text-ary-muted">暂无报名记录</p>
      </div>
    );
  }

  return (
    <div>
      {/* Batch actions bar */}
      {selectedIds.size > 0 && (
        <div className="mb-3 flex items-center gap-3 rounded-lg bg-ary-blue-100 p-3">
          <span className="text-sm font-medium text-ary-blue-900">
            已选择 {selectedIds.size} 项
          </span>
          <button
            onClick={handleBatchApprove}
            disabled={batchProcessing}
            className="inline-flex items-center gap-1.5 rounded-lg bg-green-600 px-3 py-1.5 text-xs font-semibold text-white transition-colors hover:bg-green-700 disabled:opacity-50"
          >
            <CheckCheck className="h-3.5 w-3.5" />
            {batchProcessing ? "处理中..." : "批量批准"}
          </button>
          <button
            onClick={() => setSelectedIds(new Set())}
            className="text-xs font-medium text-ary-muted hover:text-slate-800"
          >
            取消选择
          </button>
        </div>
      )}

      <div className="overflow-x-auto rounded-xl border border-ary-line bg-white">
        <table className="w-full text-left text-sm">
          <thead>
            <tr className="border-b border-ary-line bg-slate-50">
              {submittedRegs.length > 0 && (
                <th className="w-10 px-4 py-3">
                  <input
                    type="checkbox"
                    checked={
                      submittedRegs.length > 0 &&
                      selectedIds.size === submittedRegs.length
                    }
                    onChange={toggleSelectAll}
                    className="h-4 w-4 rounded border-ary-line text-ary-blue-700 focus:ring-ary-blue-500"
                  />
                </th>
              )}
              <th className="px-4 py-3 font-medium text-ary-muted">用户</th>
              <th className="px-4 py-3 font-medium text-ary-muted">
                GitHub ID
              </th>
              <th className="px-4 py-3 font-medium text-ary-muted">
                学校/公司
              </th>
              <th className="px-4 py-3 font-medium text-ary-muted">状态</th>
              <th className="px-4 py-3 font-medium text-ary-muted">
                提交时间
              </th>
              <th className="px-4 py-3 font-medium text-ary-muted">作品</th>
              <th className="px-4 py-3 font-medium text-ary-muted">操作</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-ary-line">
            {registrations.map((reg) => {
              const canAct = reg.status === "submitted";
              return (
                <tr
                  key={reg.id}
                  className={`transition-colors hover:bg-slate-50 ${
                    selectedIds.has(reg.id) ? "bg-ary-blue-50" : ""
                  }`}
                >
                  {submittedRegs.length > 0 && (
                    <td className="px-4 py-3">
                      {canAct && (
                        <input
                          type="checkbox"
                          checked={selectedIds.has(reg.id)}
                          onChange={() => toggleSelect(reg.id)}
                          className="h-4 w-4 rounded border-ary-line text-ary-blue-700 focus:ring-ary-blue-500"
                        />
                      )}
                    </td>
                  )}
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-2">
                      <div className="flex h-8 w-8 items-center justify-center rounded-full bg-ary-blue-100 text-xs font-bold text-ary-blue-800">
                        {reg.userName[0]?.toUpperCase() ?? "?"}
                      </div>
                      <div>
                        <p className="font-medium text-slate-900">
                          {reg.userName}
                        </p>
                        {reg.userEmail && (
                          <p className="text-xs text-ary-muted">
                            {reg.userEmail}
                          </p>
                        )}
                      </div>
                    </div>
                  </td>
                  <td className="px-4 py-3 font-mono text-xs text-slate-700">
                    {reg.githubId}
                  </td>
                  <td className="px-4 py-3 text-xs text-ary-muted">
                    {reg.school ?? reg.company ?? "-"}
                  </td>
                  <td className="px-4 py-3">
                    <StatusBadge status={reg.status} />
                  </td>
                  <td className="px-4 py-3 text-xs text-ary-muted">
                    {new Date(reg.submittedAt).toLocaleDateString("zh-CN", {
                      month: "short",
                      day: "numeric",
                      hour: "2-digit",
                      minute: "2-digit",
                    })}
                  </td>
                  <td className="px-4 py-3 text-xs text-ary-muted">
                    {reg.workTitle ?? "-"}
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex gap-1.5">
                      {canAct && (
                        <>
                          <button
                            onClick={() => handleApprove(reg.id)}
                            disabled={processingId === reg.id}
                            className="inline-flex items-center gap-1 rounded-lg bg-green-50 px-2.5 py-1.5 text-xs font-medium text-green-700 transition-colors hover:bg-green-100 disabled:opacity-50"
                          >
                            <CheckCircle className="h-3.5 w-3.5" />
                            {processingId === reg.id ? "..." : "批准"}
                          </button>
                          <button
                            onClick={() => handleReject(reg.id)}
                            disabled={processingId === reg.id}
                            className="inline-flex items-center gap-1 rounded-lg bg-red-50 px-2.5 py-1.5 text-xs font-medium text-red-700 transition-colors hover:bg-red-100 disabled:opacity-50"
                          >
                            <XCircle className="h-3.5 w-3.5" />
                            {processingId === reg.id ? "..." : "拒绝"}
                          </button>
                        </>
                      )}
                      {!canAct && (
                        <span className="text-xs text-ary-muted">-</span>
                      )}
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function UsersIcon({ className }: { className?: string }) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
    >
      <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2" />
      <circle cx="9" cy="7" r="4" />
      <path d="M22 21v-2a4 4 0 0 0-3-3.87" />
      <path d="M16 3.13a4 4 0 0 1 0 7.75" />
    </svg>
  );
}
