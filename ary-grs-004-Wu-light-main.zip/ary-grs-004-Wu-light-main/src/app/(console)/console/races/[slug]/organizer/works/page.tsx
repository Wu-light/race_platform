import { OrganizerNav } from "@/components/layout/OrganizerNav";
import { prisma } from "@/lib/db";
import { auth } from "@/lib/auth";
import { redirect } from "next/navigation";
import { requireOrganizerOfRace } from "@/lib/permissions";
import { WorksActions } from "./WorksActions";
import { FileText, Lock, Eye, EyeOff } from "lucide-react";

function WorkStatusBadge({ status }: { status: string }) {
  const config: Record<string, { label: string; classes: string }> = {
    draft: { label: "草稿", classes: "bg-gray-100 text-gray-600" },
    submitted: { label: "已提交", classes: "bg-green-100 text-green-700" },
    locked: { label: "已锁定", classes: "bg-purple-100 text-purple-700" },
    hidden: { label: "已隐藏", classes: "bg-yellow-100 text-yellow-700" },
  };
  const c = config[status] ?? {
    label: status,
    classes: "bg-gray-100 text-gray-700",
  };
  return (
    <span
      className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-semibold ${c.classes}`}
    >
      {c.label}
    </span>
  );
}

function VisibilityBadge({ visibility }: { visibility: string }) {
  const config: Record<string, { label: string; classes: string }> = {
    public: { label: "公开", classes: "bg-green-100 text-green-700" },
    hidden: { label: "隐藏", classes: "bg-gray-100 text-gray-600" },
    internal: { label: "内部", classes: "bg-yellow-100 text-yellow-700" },
  };
  const c = config[visibility] ?? {
    label: visibility,
    classes: "bg-gray-100 text-gray-600",
  };
  return (
    <span
      className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-semibold ${c.classes}`}
    >
      {c.label}
    </span>
  );
}

export default async function OrganizerWorksPage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const session = await auth();
  if (!session?.user) redirect("/login");

  const race = await prisma.race.findUnique({ where: { slug } });
  if (!race) redirect("/console/races");
  try {
    await requireOrganizerOfRace(race.id);
  } catch {
    redirect("/console/access-denied");
  }

  // Get all works for this race
  const works = await prisma.work.findMany({
    where: { registration: { raceId: race.id } },
    include: {
      registration: {
        include: {
          user: {
            select: {
              id: true,
              name: true,
              avatar: true,
              githubId: true,
            },
          },
        },
      },
    },
    orderBy: { createdAt: "desc" },
  });

  const statusCounts: Record<string, number> = {};
  works.forEach((w) => {
    statusCounts[w.status] = (statusCounts[w.status] ?? 0) + 1;
  });

  return (
    <div className="mx-auto max-w-[1440px] px-6 py-8">
      <OrganizerNav slug={slug} current="works" />

      <div className="mb-6">
        <h1 className="text-2xl font-bold text-slate-900">作品管理</h1>
        <p className="mt-1 text-sm text-ary-muted">
          管理所有参赛作品 ({works.length} 个)
        </p>
      </div>

      {/* Summary Cards */}
      <div className="mb-6 grid grid-cols-2 gap-4 sm:grid-cols-4">
        <div className="rounded-xl border border-ary-line bg-white p-4">
          <div className="flex items-center gap-3">
            <FileText className="h-5 w-5 text-ary-blue-700" />
            <div>
              <p className="text-xs text-ary-muted">总作品数</p>
              <p className="text-xl font-bold text-slate-900">
                {works.length}
              </p>
            </div>
          </div>
        </div>
        <div className="rounded-xl border border-ary-line bg-white p-4">
          <div className="flex items-center gap-3">
            <FileText className="h-5 w-5 text-green-600" />
            <div>
              <p className="text-xs text-ary-muted">已提交</p>
              <p className="text-xl font-bold text-slate-900">
                {statusCounts["submitted"] ?? 0}
              </p>
            </div>
          </div>
        </div>
        <div className="rounded-xl border border-ary-line bg-white p-4">
          <div className="flex items-center gap-3">
            <Lock className="h-5 w-5 text-purple-600" />
            <div>
              <p className="text-xs text-ary-muted">已锁定</p>
              <p className="text-xl font-bold text-slate-900">
                {statusCounts["locked"] ?? 0}
              </p>
            </div>
          </div>
        </div>
        <div className="rounded-xl border border-ary-line bg-white p-4">
          <div className="flex items-center gap-3">
            <EyeOff className="h-5 w-5 text-yellow-600" />
            <div>
              <p className="text-xs text-ary-muted">草稿/隐藏</p>
              <p className="text-xl font-bold text-slate-900">
                {(statusCounts["draft"] ?? 0) + (statusCounts["hidden"] ?? 0)}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Works Table */}
      <WorksActions
        works={works.map((w) => ({
          id: w.id,
          title: w.title,
          slug: w.slug,
          status: w.status,
          visibility: w.visibility,
          authorName: w.registration.user.name ?? "未知用户",
          authorGithubId: w.registration.user.githubId,
          createdAt: w.createdAt.toISOString(),
        }))}
        slug={slug}
      />
    </div>
  );
}
