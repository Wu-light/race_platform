"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { lockWork, unlockWork, hideWork, unhideWork } from "../actions";
import Link from "next/link";
import {
  Lock,
  Unlock,
  EyeOff,
  Eye,
  ExternalLink,
  FileText,
} from "lucide-react";

interface WorkItem {
  id: string;
  title: string;
  slug: string;
  status: string;
  visibility: string;
  authorName: string;
  authorGithubId: number;
  createdAt: string;
}

function WorkStatusBadge({ status }: { status: string }) {
  const config: Record<string, { label: string; classes: string }> = {
    draft: { label: "草稿", classes: "bg-gray-100 text-gray-600" },
    submitted: { label: "已提交", classes: "bg-green-100 text-green-700" },
    locked: { label: "已锁定", classes: "bg-purple-100 text-purple-700" },
    hidden: { label: "已隐藏", classes: "bg-yellow-100 text-yellow-700" },
  };
  const c = config[status] ?? {
    label: status,
    classes: "bg-gray-100 text-gray-700",
  };
  return (
    <span
      className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-semibold ${c.classes}`}
    >
      {c.label}
    </span>
  );
}

function VisibilityBadge({ visibility }: { visibility: string }) {
  const config: Record<string, { label: string; classes: string }> = {
    public: { label: "公开", classes: "bg-green-100 text-green-700" },
    hidden: { label: "隐藏", classes: "bg-gray-100 text-gray-600" },
    internal: { label: "内部", classes: "bg-yellow-100 text-yellow-700" },
  };
  const c = config[visibility] ?? {
    label: visibility,
    classes: "bg-gray-100 text-gray-600",
  };
  return (
    <span
      className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-semibold ${c.classes}`}
    >
      {c.label}
    </span>
  );
}

export function WorksActions({
  works,
  slug,
}: {
  works: WorkItem[];
  slug: string;
}) {
  const router = useRouter();
  const [processingId, setProcessingId] = useState<string | null>(null);

  const handleAction = async (
    action: (workId: string, slug: string) => Promise<void>,
    workId: string,
  ) => {
    setProcessingId(workId);
    try {
      await action(workId, slug);
      router.refresh();
    } catch (err) {
      console.error(err);
    } finally {
      setProcessingId(null);
    }
  };

  if (works.length === 0) {
    return (
      <div className="flex flex-col items-center rounded-xl border border-ary-line bg-white py-16 text-center">
        <FileText className="mb-3 h-12 w-12 text-ary-muted" />
        <p className="text-sm text-ary-muted">暂无作品</p>
      </div>
    );
  }

  return (
    <div className="overflow-x-auto rounded-xl border border-ary-line bg-white">
      <table className="w-full text-left text-sm">
        <thead>
          <tr className="border-b border-ary-line bg-slate-50">
            <th className="px-4 py-3 font-medium text-ary-muted">作品</th>
            <th className="px-4 py-3 font-medium text-ary-muted">作者</th>
            <th className="px-4 py-3 font-medium text-ary-muted">状态</th>
            <th className="px-4 py-3 font-medium text-ary-muted">可见性</th>
            <th className="px-4 py-3 font-medium text-ary-muted">提交时间</th>
            <th className="px-4 py-3 font-medium text-ary-muted">操作</th>
          </tr>
        </thead>
        <tbody className="divide-y divide-ary-line">
          {works.map((work) => (
            <tr
              key={work.id}
              className="transition-colors hover:bg-slate-50"
            >
              <td className="px-4 py-3">
                <Link
                  href={`/works/${work.slug}`}
                  className="font-medium text-ary-blue-700 hover:text-ary-blue-800 hover:underline"
                >
                  {work.title}
                </Link>
              </td>
              <td className="px-4 py-3 text-xs text-ary-muted">
                {work.authorName}
              </td>
              <td className="px-4 py-3">
                <WorkStatusBadge status={work.status} />
              </td>
              <td className="px-4 py-3">
                <VisibilityBadge visibility={work.visibility} />
              </td>
              <td className="px-4 py-3 text-xs text-ary-muted">
                {new Date(work.createdAt).toLocaleDateString("zh-CN", {
                  month: "short",
                  day: "numeric",
                  hour: "2-digit",
                })}
              </td>
              <td className="px-4 py-3">
                <div className="flex flex-wrap gap-1.5">
                  {work.status === "submitted" && (
                    <button
                      onClick={() => handleAction(lockWork, work.id)}
                      disabled={processingId === work.id}
                      className="inline-flex items-center gap-1 rounded-lg bg-purple-50 px-2.5 py-1.5 text-xs font-medium text-purple-700 transition-colors hover:bg-purple-100 disabled:opacity-50"
                    >
                      <Lock className="h-3.5 w-3.5" />
                      锁定
                    </button>
                  )}
                  {work.status === "locked" && (
                    <button
                      onClick={() => handleAction(unlockWork, work.id)}
                      disabled={processingId === work.id}
                      className="inline-flex items-center gap-1 rounded-lg bg-blue-50 px-2.5 py-1.5 text-xs font-medium text-blue-700 transition-colors hover:bg-blue-100 disabled:opacity-50"
                    >
                      <Unlock className="h-3.5 w-3.5" />
                      解锁
                    </button>
                  )}
                  {work.visibility !== "hidden" && (
                    <button
                      onClick={() => handleAction(hideWork, work.id)}
                      disabled={processingId === work.id}
                      className="inline-flex items-center gap-1 rounded-lg bg-yellow-50 px-2.5 py-1.5 text-xs font-medium text-yellow-700 transition-colors hover:bg-yellow-100 disabled:opacity-50"
                    >
                      <EyeOff className="h-3.5 w-3.5" />
                      隐藏
                    </button>
                  )}
                  {work.visibility === "hidden" && (
                    <button
                      onClick={() => handleAction(unhideWork, work.id)}
                      disabled={processingId === work.id}
                      className="inline-flex items-center gap-1 rounded-lg bg-green-50 px-2.5 py-1.5 text-xs font-medium text-green-700 transition-colors hover:bg-green-100 disabled:opacity-50"
                    >
                      <Eye className="h-3.5 w-3.5" />
                      显示
                    </button>
                  )}
                </div>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
