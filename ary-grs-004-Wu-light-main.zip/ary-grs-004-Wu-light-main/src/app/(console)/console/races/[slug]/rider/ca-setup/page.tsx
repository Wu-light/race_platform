"use client";

import { useEffect, useState, useCallback } from "react";
import { useParams, useRouter } from "next/navigation";
import { RiderNav } from "@/components/layout/RiderNav";
import { ActionLink } from "@/components/ui/ActionLink";
import { EmptyState } from "@/components/ui/EmptyState";
import {
  Plus,
  Wifi,
  WifiOff,
  Activity,
  AlertTriangle,
  Handshake,
  XCircle,
  Loader2,
  CheckCircle2,
  TriangleAlert,
} from "lucide-react";

// ---------- Types ----------

interface CAConnection {
  id: string;
  caType: string;
  connectorId: string | null;
  externalProjectRef: string | null;
  ingestionStatus: string;
  registeredAt: string;
  handshakeAt: string | null;
  disabledAt: string | null;
}

interface RaceProject {
  id: string;
  aggregateIngestionStatus: string;
  connectionHealth: string;
  lastSyncedAt: string | null;
  caConnections: CAConnection[];
}

interface RegistrationData {
  id: string;
  status: string;
  raceProject: RaceProject | null;
}

interface RaceData {
  id: string;
  slug: string;
  title: string;
}

// ---------- Status Badge ----------

function ConnStatusBadge({ status }: { status: string }) {
  const styles: Record<string, string> = {
    not_configured: "border-slate-200 bg-slate-100 text-slate-600",
    connected: "border-blue-200 bg-blue-50 text-ary-blue-700",
    active: "border-emerald-200 bg-emerald-50 text-emerald-700",
    failed: "border-red-200 bg-red-50 text-red-700",
  };
  const labels: Record<string, string> = {
    not_configured: "未配置",
    connected: "已连接",
    active: "活动中",
    failed: "失败",
  };
  const icons: Record<string, React.ReactNode> = {
    not_configured: <WifiOff className="h-3.5 w-3.5" />,
    connected: <Wifi className="h-3.5 w-3.5" />,
    active: <Activity className="h-3.5 w-3.5" />,
    failed: <AlertTriangle className="h-3.5 w-3.5" />,
  };
  return (
    <span
      className={`inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-xs font-semibold ${
        styles[status] ?? styles.not_configured
      }`}
    >
      {icons[status] ?? null}
      {labels[status] ?? status}
    </span>
  );
}

// ---------- Main Component ----------

export default function CaSetupPage() {
  const params = useParams();
  const router = useRouter();
  const slug = params.slug as string;

  const [race, setRace] = useState<RaceData | null>(null);
  const [registration, setRegistration] = useState<RegistrationData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Form state
  const [caType, setCaType] = useState("claude_code");
  const [connectorId, setConnectorId] = useState("");
  const [externalProjectRef, setExternalProjectRef] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);

  // Action state
  const [actionLoading, setActionLoading] = useState<string | null>(null);

  const fetchData = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const [raceRes, regRes] = await Promise.all([
        fetch(`/api/races/${slug}`),
        fetch(`/api/registrations?raceSlug=${slug}`),
      ]);

      if (!raceRes.ok) {
        throw new Error("无法获取赛事信息");
      }
      const raceData = await raceRes.json();
      setRace(raceData);

      if (regRes.ok) {
        const regData = await regRes.json();
        setRegistration(regData.registration);
      }
    } catch (e: any) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  }, [slug]);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  // Add CA connection
  async function handleAddConnection(e: React.FormEvent) {
    e.preventDefault();
    if (!registration?.raceProject) return;

    setSubmitting(true);
    setFormError(null);
    try {
      const res = await fetch(
        `/api/race-projects/${registration.raceProject.id}/ca-connections`,
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            caType,
            connectorId: connectorId || null,
            externalProjectRef: externalProjectRef || null,
          }),
        },
      );
      if (!res.ok) {
        const data = await res.json();
        throw new Error(data.error ?? "添加连接失败");
      }
      setCaType("claude_code");
      setConnectorId("");
      setExternalProjectRef("");
      await fetchData();
    } catch (e: any) {
      setFormError(e.message);
    } finally {
      setSubmitting(false);
    }
  }

  // Handle action on CA connection
  async function handleConnectionAction(
    connectionId: string,
    action: string,
  ) {
    setActionLoading(`${connectionId}-${action}`);
    try {
      const res = await fetch(`/api/ca-connections/${connectionId}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action }),
      });
      if (!res.ok) {
        const data = await res.json();
        throw new Error(data.error ?? "操作失败");
      }
      await fetchData();
    } catch (e: any) {
      setFormError(e.message);
    } finally {
      setActionLoading(null);
    }
  }

  if (loading) {
    return (
      <div className="mx-auto flex max-w-[1440px] items-center justify-center px-6 py-24">
        <Loader2 className="h-8 w-8 animate-spin text-ary-blue-500" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="mx-auto max-w-[1440px] px-6 py-8">
        <RiderNav slug={slug} current="ca-setup" />
        <div className="rounded-2xl border border-red-200 bg-red-50 p-6 text-center">
          <TriangleAlert className="mx-auto h-8 w-8 text-red-500" />
          <p className="mt-2 text-sm text-red-700">{error}</p>
        </div>
      </div>
    );
  }

  if (!race) {
    return (
      <div className="mx-auto max-w-[1440px] px-6 py-8">
        <RiderNav slug={slug} current="ca-setup" />
        <p className="text-lg font-medium text-ary-muted">赛事不存在</p>
      </div>
    );
  }

  if (!registration) {
    return (
      <div className="mx-auto max-w-[1440px] px-6 py-8">
        <RiderNav slug={slug} current="ca-setup" />
        <EmptyState
          title="尚未报名"
          description="请先报名参赛以进行 CA 配置。"
        />
        <ActionLink href={`/console/races/${slug}/rider`} className="mt-4">
          前往报名
        </ActionLink>
      </div>
    );
  }

  if (!registration.raceProject) {
    return (
      <div className="mx-auto max-w-[1440px] px-6 py-8">
        <RiderNav slug={slug} current="ca-setup" />
        <div className="rounded-2xl border border-amber-200 bg-amber-50 p-6">
          <div className="flex items-center gap-2">
            <AlertTriangle className="h-5 w-5 text-amber-500" />
            <h2 className="text-lg font-bold text-amber-900">
              请先完成报名审核
            </h2>
          </div>
          <p className="mt-2 text-sm text-amber-700">
            你的报名正在审核中，审核通过后即可进行 CA 配置。
          </p>
          <ActionLink
            href={`/console/races/${slug}/rider`}
            variant="secondary"
            className="mt-3"
          >
            查看报名状态
          </ActionLink>
        </div>
      </div>
    );
  }

  const raceProject = registration.raceProject;
  const connections = raceProject.caConnections;

  return (
    <div className="mx-auto max-w-[1440px] px-6 py-8">
      <RiderNav slug={slug} current="ca-setup" />

      <div className="mb-6">
        <h1 className="text-2xl font-bold text-slate-900">CA 配置</h1>
        <p className="mt-1 text-sm text-ary-muted">
          配置和管理你的 Coding Agent 连接
        </p>
      </div>

      <div className="grid gap-6 lg:grid-cols-5">
        {/* Left: Connection List */}
        <div className="lg:col-span-3 space-y-4">
          <h2 className="text-lg font-bold text-slate-900">
            当前连接 ({connections.length})
          </h2>

          {connections.length === 0 ? (
            <EmptyState
              title="暂无连接"
              description="使用右侧表单添加你的第一个 CA 连接。"
            />
          ) : (
            connections.map((conn) => (
              <div
                key={conn.id}
                className="rounded-2xl border border-ary-line bg-white p-5"
              >
                <div className="flex items-start justify-between">
                  <div>
                    <div className="mb-2 flex items-center gap-2">
                      <span className="text-base font-bold text-slate-900">
                        {conn.caType === "claude_code"
                          ? "Claude Code"
                          : conn.caType === "codex"
                            ? "Codex"
                            : "其他"}
                      </span>
                      <ConnStatusBadge status={conn.ingestionStatus} />
                    </div>
                    <div className="space-y-1 text-sm">
                      {conn.connectorId && (
                        <p>
                          <span className="text-ary-muted">Connector ID:</span>{" "}
                          <span className="font-mono text-slate-900">
                            {conn.connectorId}
                          </span>
                        </p>
                      )}
                      {conn.externalProjectRef && (
                        <p>
                          <span className="text-ary-muted">外部项目:</span>{" "}
                          <span className="text-slate-900">
                            {conn.externalProjectRef}
                          </span>
                        </p>
                      )}
                      {conn.handshakeAt && (
                        <p className="text-xs text-ary-muted">
                          握手完成:{" "}
                          {new Date(conn.handshakeAt).toLocaleString("zh-CN")}
                        </p>
                      )}
                      {conn.disabledAt && (
                        <p className="text-xs text-red-500">
                          已禁用:{" "}
                          {new Date(conn.disabledAt).toLocaleString("zh-CN")}
                        </p>
                      )}
                    </div>
                  </div>
                </div>

                {/* Action buttons */}
                <div className="mt-4 flex flex-wrap gap-2">
                  {conn.ingestionStatus === "not_configured" && (
                    <button
                      type="button"
                      onClick={() =>
                        handleConnectionAction(conn.id, "handshake")
                      }
                      disabled={actionLoading === `${conn.id}-handshake`}
                      className="inline-flex items-center gap-1.5 rounded-lg border border-blue-200 bg-blue-50 px-3 py-1.5 text-xs font-semibold text-ary-blue-700 transition-colors hover:bg-blue-100 disabled:opacity-50"
                    >
                      {actionLoading === `${conn.id}-handshake` ? (
                        <Loader2 className="h-3.5 w-3.5 animate-spin" />
                      ) : (
                        <Handshake className="h-3.5 w-3.5" />
                      )}
                      Handshake
                    </button>
                  )}
                  {(conn.ingestionStatus === "connected" ||
                    conn.ingestionStatus === "active") && (
                    <button
                      type="button"
                      onClick={() =>
                        handleConnectionAction(conn.id, "disable")
                      }
                      disabled={actionLoading === `${conn.id}-disable`}
                      className="inline-flex items-center gap-1.5 rounded-lg border border-red-200 bg-red-50 px-3 py-1.5 text-xs font-semibold text-red-700 transition-colors hover:bg-red-100 disabled:opacity-50"
                    >
                      {actionLoading === `${conn.id}-disable` ? (
                        <Loader2 className="h-3.5 w-3.5 animate-spin" />
                      ) : (
                        <XCircle className="h-3.5 w-3.5" />
                      )}
                      禁用
                    </button>
                  )}
                  {conn.ingestionStatus === "failed" && (
                    <button
                      type="button"
                      onClick={() =>
                        handleConnectionAction(conn.id, "register")
                      }
                      disabled={actionLoading === `${conn.id}-register`}
                      className="inline-flex items-center gap-1.5 rounded-lg border border-slate-200 bg-slate-50 px-3 py-1.5 text-xs font-semibold text-slate-700 transition-colors hover:bg-slate-100 disabled:opacity-50"
                    >
                      {actionLoading === `${conn.id}-register` ? (
                        <Loader2 className="h-3.5 w-3.5 animate-spin" />
                      ) : (
                        <CheckCircle2 className="h-3.5 w-3.5" />
                      )}
                      重新注册
                    </button>
                  )}
                </div>
              </div>
            ))
          )}

          {/* Ingestion status indicator */}
          {connections.length > 0 && (
            <div className="rounded-2xl border border-ary-line bg-white p-4">
              <h3 className="mb-2 text-sm font-semibold text-slate-900">
                数据摄取状态
              </h3>
              <div className="flex items-center gap-2">
                <ConnStatusBadge
                  status={raceProject.aggregateIngestionStatus}
                />
                <span className="text-xs text-ary-muted">
                  总体数据摄取状态
                </span>
              </div>
              {raceProject.lastSyncedAt && (
                <p className="mt-1 text-xs text-ary-muted">
                  上次同步:{" "}
                  {new Date(raceProject.lastSyncedAt).toLocaleString("zh-CN")}
                </p>
              )}
            </div>
          )}
        </div>

        {/* Right: Add Connection Form */}
        <div className="lg:col-span-2">
          <div className="rounded-2xl border border-ary-line bg-white p-6">
            <h2 className="mb-4 text-lg font-bold text-slate-900">
              添加 CA 连接
            </h2>
            <form onSubmit={handleAddConnection} className="space-y-4">
              {/* CA Type */}
              <div>
                <label className="mb-1.5 block text-xs font-semibold uppercase tracking-wider text-ary-muted">
                  CA 类型
                </label>
                <select
                  value={caType}
                  onChange={(e) => setCaType(e.target.value)}
                  className="w-full rounded-xl border border-ary-line bg-white px-3 py-2.5 text-sm text-slate-900 focus:border-ary-blue-500 focus:outline-none focus:ring-2 focus:ring-ary-blue-100"
                >
                  <option value="claude_code">Claude Code</option>
                  <option value="codex">Codex</option>
                  <option value="other">其他</option>
                </select>
              </div>

              {/* Connector ID */}
              <div>
                <label className="mb-1.5 block text-xs font-semibold uppercase tracking-wider text-ary-muted">
                  Connector ID
                </label>
                <input
                  type="text"
                  value={connectorId}
                  onChange={(e) => setConnectorId(e.target.value)}
                  placeholder="输入你的 Connector ID"
                  className="w-full rounded-xl border border-ary-line bg-white px-3 py-2.5 text-sm text-slate-900 placeholder:text-slate-400 focus:border-ary-blue-500 focus:outline-none focus:ring-2 focus:ring-ary-blue-100"
                />
              </div>

              {/* External Project Reference */}
              <div>
                <label className="mb-1.5 block text-xs font-semibold uppercase tracking-wider text-ary-muted">
                  外部项目参考
                </label>
                <input
                  type="text"
                  value={externalProjectRef}
                  onChange={(e) => setExternalProjectRef(e.target.value)}
                  placeholder="GitHub repo URL 或项目名称"
                  className="w-full rounded-xl border border-ary-line bg-white px-3 py-2.5 text-sm text-slate-900 placeholder:text-slate-400 focus:border-ary-blue-500 focus:outline-none focus:ring-2 focus:ring-ary-blue-100"
                />
              </div>

              {formError && (
                <p className="text-xs text-red-600">{formError}</p>
              )}

              <button
                type="submit"
                disabled={submitting}
                className="inline-flex w-full items-center justify-center gap-2 rounded-xl bg-gradient-to-br from-ary-blue-800 to-ary-blue-500 px-5 py-2.5 text-sm font-semibold text-white shadow-[0_12px_30px_rgba(7,91,236,0.22)] transition duration-200 hover:-translate-y-0.5 hover:shadow-[0_16px_34px_rgba(7,91,236,0.3)] disabled:cursor-not-allowed disabled:opacity-50"
              >
                {submitting ? (
                  <Loader2 className="h-4 w-4 animate-spin" />
                ) : (
                  <Plus className="h-4 w-4" />
                )}
                {submitting ? "注册中..." : "注册连接"}
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
}
