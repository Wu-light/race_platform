import { OrganizerNav } from "@/components/layout/OrganizerNav";
import { prisma } from "@/lib/db";
import { auth } from "@/lib/auth";
import { redirect } from "next/navigation";
import { requireOrganizerOfRace } from "@/lib/permissions";
import { RegistrationActions } from "./RegistrationActions";
import { Users, CheckCircle, XCircle, Clock, Filter } from "lucide-react";

const STATUS_OPTIONS = [
  { value: "all", label: "全部" },
  { value: "submitted", label: "待审核" },
  { value: "approved", label: "已批准" },
  { value: "rejected", label: "已拒绝" },
  { value: "withdrawn", label: "已撤回" },
];

function StatusBadge({ status }: { status: string }) {
  const config: Record<string, { label: string; classes: string }> = {
    submitted: { label: "待审核", classes: "bg-yellow-100 text-yellow-700" },
    approved: { label: "已批准", classes: "bg-green-100 text-green-700" },
    rejected: { label: "已拒绝", classes: "bg-red-100 text-red-700" },
    withdrawn: { label: "已撤回", classes: "bg-gray-100 text-gray-600" },
  };
  const c = config[status] ?? { label: status, classes: "bg-gray-100 text-gray-700" };
  return (
    <span
      className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-semibold ${c.classes}`}
    >
      {c.label}
    </span>
  );
}

export default async function OrganizerRegistrationsPage({
  params,
  searchParams,
}: {
  params: Promise<{ slug: string }>;
  searchParams: Promise<{ status?: string }>;
}) {
  const { slug } = await params;
  const search = await searchParams;
  const filterStatus = search.status ?? "all";

  const session = await auth();
  if (!session?.user) redirect("/login");

  const race = await prisma.race.findUnique({ where: { slug } });
  if (!race) redirect("/console/races");
  try {
    await requireOrganizerOfRace(race.id);
  } catch {
    redirect("/console/access-denied");
  }

  const whereStatus =
    filterStatus !== "all" ? filterStatus : undefined;

  const registrations = await prisma.registration.findMany({
    where: {
      raceId: race.id,
      ...(whereStatus ? { status: whereStatus } : {}),
    },
    include: {
      user: {
        select: {
          id: true,
          name: true,
          email: true,
          avatar: true,
          githubId: true,
          school: true,
          company: true,
        },
      },
      work: {
        select: { id: true, title: true, status: true },
      },
    },
    orderBy: { submittedAt: "desc" },
  });

  const statusCounts = await prisma.registration.groupBy({
    by: ["status"],
    where: { raceId: race.id },
    _count: true,
  });
  const countMap: Record<string, number> = {};
  statusCounts.forEach((r) => {
    countMap[r.status] = r._count;
  });
  const totalCount = registrations.length;
  const approvedCount = countMap["approved"] ?? 0;
  const submittedCount = countMap["submitted"] ?? 0;
  const rejectedCount = countMap["rejected"] ?? 0;

  return (
    <div className="mx-auto max-w-[1440px] px-6 py-8">
      <OrganizerNav slug={slug} current="registrations" />

      <div className="mb-6">
        <h1 className="text-2xl font-bold text-slate-900">报名管理</h1>
        <p className="mt-1 text-sm text-ary-muted">
          管理参赛者的报名申请
        </p>
      </div>

      {/* Summary Cards */}
      <div className="mb-6 grid grid-cols-2 gap-4 sm:grid-cols-4">
        <div className="rounded-xl border border-ary-line bg-white p-4">
          <div className="flex items-center gap-3">
            <Users className="h-5 w-5 text-ary-blue-700" />
            <div>
              <p className="text-xs text-ary-muted">总报名</p>
              <p className="text-xl font-bold text-slate-900">
                {totalCount}
              </p>
            </div>
          </div>
        </div>
        <div className="rounded-xl border border-ary-line bg-white p-4">
          <div className="flex items-center gap-3">
            <Clock className="h-5 w-5 text-yellow-600" />
            <div>
              <p className="text-xs text-ary-muted">待审核</p>
              <p className="text-xl font-bold text-slate-900">
                {submittedCount}
              </p>
            </div>
          </div>
        </div>
        <div className="rounded-xl border border-ary-line bg-white p-4">
          <div className="flex items-center gap-3">
            <CheckCircle className="h-5 w-5 text-green-600" />
            <div>
              <p className="text-xs text-ary-muted">已批准</p>
              <p className="text-xl font-bold text-slate-900">
                {approvedCount}
              </p>
            </div>
          </div>
        </div>
        <div className="rounded-xl border border-ary-line bg-white p-4">
          <div className="flex items-center gap-3">
            <XCircle className="h-5 w-5 text-red-600" />
            <div>
              <p className="text-xs text-ary-muted">已拒绝</p>
              <p className="text-xl font-bold text-slate-900">
                {rejectedCount}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Filter */}
      <div className="mb-4 flex items-center gap-2">
        <Filter className="h-4 w-4 text-ary-muted" />
        {STATUS_OPTIONS.map((opt) => {
          const href =
            opt.value === "all"
              ? `/console/races/${slug}/organizer/registrations`
              : `/console/races/${slug}/organizer/registrations?status=${opt.value}`;
          const isActive =
            (opt.value === "all" && filterStatus === "all") ||
            opt.value === filterStatus;
          return (
            <a
              key={opt.value}
              href={href}
              className={`rounded-lg px-3 py-1.5 text-xs font-medium transition-colors ${
                isActive
                  ? "bg-ary-blue-100 text-ary-blue-900"
                  : "text-slate-500 hover:bg-slate-100 hover:text-slate-800"
              }`}
            >
              {opt.label}
            </a>
          );
        })}
      </div>

      {/* Table */}
      <RegistrationActions
        registrations={registrations.map((r) => ({
          id: r.id,
          status: r.status,
          userName: r.user.name ?? "未知用户",
          userEmail: r.user.email ?? "",
          userAvatar: r.user.avatar ?? "",
          githubId: r.user.githubId,
          school: r.user.school ?? null,
          company: r.user.company ?? null,
          submittedAt: r.submittedAt.toISOString(),
          workTitle: r.work?.title ?? null,
          workStatus: r.work?.status ?? null,
        }))}
        slug={slug}
      />
    </div>
  );
}
