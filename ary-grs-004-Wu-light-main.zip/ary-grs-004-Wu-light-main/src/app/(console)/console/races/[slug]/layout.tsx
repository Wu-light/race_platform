import { ConsoleShell } from "@/components/layout/ConsoleShell";
import { auth } from "@/lib/auth";
import { redirect } from "next/navigation";
import { prisma } from "@/lib/db";
import { getUserRoles } from "@/lib/permissions";

export default async function RaceLayout({
  children,
  params,
}: {
  children: React.ReactNode;
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const session = await auth();
  if (!session?.user) redirect("/login");

  if (!(session.user as any).profileCompleted) {
    redirect("/console/profile/complete");
  }

  const race = await prisma.race.findUnique({
    where: { slug },
    select: { id: true, slug: true, title: true },
  });

  if (!race) {
    return <ConsoleShell>{children}</ConsoleShell>;
  }

  const roles = getUserRoles((session.user as any).roles ?? "[]");
  const userId = session.user.id;

  if (roles.includes("admin")) {
    return <ConsoleShell currentRace={race}>{children}</ConsoleShell>;
  }

  let allowed = false;
  if (roles.includes("organizer") && race.id) {
    const r = await prisma.race.findFirst({
      where: { id: race.id, organizerId: userId },
      select: { id: true },
    });
    if (r) allowed = true;
  }
  if (!allowed && roles.includes("rider")) {
    const reg = await prisma.registration.findFirst({
      where: { raceId: race.id, userId, status: "approved" },
      select: { id: true },
    });
    if (reg) allowed = true;
  }
  if (!allowed && roles.includes("judge")) {
    const assignment = await prisma.judgeAssignment.findFirst({
      where: { judgeId: userId, work: { registration: { raceId: race.id } } },
      select: { id: true },
    });
    if (assignment) allowed = true;
  }

  if (!allowed) {
    redirect("/console/access-denied");
  }

  return <ConsoleShell currentRace={race}>{children}</ConsoleShell>;
}
