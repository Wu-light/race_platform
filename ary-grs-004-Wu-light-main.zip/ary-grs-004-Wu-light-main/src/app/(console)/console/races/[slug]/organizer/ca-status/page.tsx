import { OrganizerNav } from "@/components/layout/OrganizerNav";
import { prisma } from "@/lib/db";
import { auth } from "@/lib/auth";
import { redirect } from "next/navigation";
import { requireOrganizerOfRace } from "@/lib/permissions";
import {
  Wifi,
  WifiOff,
  Activity,
  AlertTriangle,
  Clock,
  WifiIcon,
} from "lucide-react";

function StatusBadge({ status }: { status: string }) {
  const config: Record<string, { label: string; classes: string }> = {
    not_configured: { label: "未配置", classes: "bg-gray-100 text-gray-600" },
    connected: { label: "已连接", classes: "bg-blue-100 text-blue-700" },
    active: { label: "活跃", classes: "bg-green-100 text-green-700" },
    failed: { label: "异常", classes: "bg-red-100 text-red-700" },
  };
  const c = config[status] ?? {
    label: status,
    classes: "bg-gray-100 text-gray-700",
  };
  return (
    <span
      className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-semibold ${c.classes}`}
    >
      {c.label}
    </span>
  );
}

function ConnectionHealthIcon({ status }: { status: string }) {
  switch (status) {
    case "active":
      return <Wifi className="h-4 w-4 text-green-600" />;
    case "connected":
      return <WifiIcon className="h-4 w-4 text-blue-600" />;
    case "failed":
      return <AlertTriangle className="h-4 w-4 text-red-600" />;
    default:
      return <WifiOff className="h-4 w-4 text-gray-400" />;
  }
}

export default async function OrganizerCaStatusPage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const session = await auth();
  if (!session?.user) redirect("/login");

  const race = await prisma.race.findUnique({ where: { slug } });
  if (!race) redirect("/console/races");
  try {
    await requireOrganizerOfRace(race.id);
  } catch {
    redirect("/console/access-denied");
  }

  // Get all approved registrations with race projects and CA connections
  const riders = await prisma.registration.findMany({
    where: { raceId: race.id, status: "approved" },
    include: {
      user: {
        select: {
          id: true,
          name: true,
          email: true,
          avatar: true,
          githubId: true,
        },
      },
      raceProject: {
        include: {
          caConnections: {
            orderBy: { registeredAt: "desc" },
          },
        },
      },
    },
    orderBy: { submittedAt: "asc" },
  });

  // Compute summary counts
  const summary: Record<string, number> = {
    not_configured: 0,
    connected: 0,
    active: 0,
    failed: 0,
  };
  riders.forEach((r) => {
    const st = r.raceProject?.aggregateIngestionStatus ?? "not_configured";
    summary[st] = (summary[st] ?? 0) + 1;
  });

  return (
    <div className="mx-auto max-w-[1440px] px-6 py-8">
      <OrganizerNav slug={slug} current="ca-status" />

      <div className="mb-6">
        <h1 className="text-2xl font-bold text-slate-900">CA 连接状态</h1>
        <p className="mt-1 text-sm text-ary-muted">
          每位选手的 Coding Agent 连接状态概览
        </p>
      </div>

      {/* Summary Cards */}
      <div className="mb-6 grid grid-cols-2 gap-4 sm:grid-cols-4">
        <div className="rounded-xl border border-ary-line bg-white p-4">
          <div className="flex items-center gap-3">
            <WifiOff className="h-5 w-5 text-gray-400" />
            <div>
              <p className="text-xs text-gray-500">未配置</p>
              <p className="text-xl font-bold text-slate-900">
                {summary.not_configured}
              </p>
            </div>
          </div>
        </div>
        <div className="rounded-xl border border-ary-line bg-white p-4">
          <div className="flex items-center gap-3">
            <WifiIcon className="h-5 w-5 text-blue-600" />
            <div>
              <p className="text-xs text-gray-500">已连接</p>
              <p className="text-xl font-bold text-slate-900">
                {summary.connected}
              </p>
            </div>
          </div>
        </div>
        <div className="rounded-xl border border-ary-line bg-white p-4">
          <div className="flex items-center gap-3">
            <Activity className="h-5 w-5 text-green-600" />
            <div>
              <p className="text-xs text-gray-500">活跃</p>
              <p className="text-xl font-bold text-slate-900">
                {summary.active}
              </p>
            </div>
          </div>
        </div>
        <div className="rounded-xl border border-ary-line bg-white p-4">
          <div className="flex items-center gap-3">
            <AlertTriangle className="h-5 w-5 text-red-600" />
            <div>
              <p className="text-xs text-gray-500">异常</p>
              <p className="text-xl font-bold text-slate-900">
                {summary.failed}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Riders table with CA details */}
      {riders.length === 0 ? (
        <div className="flex flex-col items-center rounded-xl border border-ary-line bg-white py-16 text-center">
          <WifiOff className="mb-3 h-12 w-12 text-ary-muted" />
          <p className="text-sm text-ary-muted">暂无已批准的参赛选手</p>
        </div>
      ) : (
        <div className="space-y-4">
          {riders.map((reg) => {
            const project = reg.raceProject;
            const caStatus =
              project?.aggregateIngestionStatus ?? "not_configured";
            const connections = project?.caConnections ?? [];
            const totalSessions = connections.length;

            return (
              <div
                key={reg.id}
                className="rounded-xl border border-ary-line bg-white p-5"
              >
                <div className="mb-3 flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="flex h-10 w-10 items-center justify-center rounded-full bg-ary-blue-100 text-sm font-bold text-ary-blue-800">
                      {reg.user.name?.[0]?.toUpperCase() ?? "?"}
                    </div>
                    <div>
                      <p className="font-medium text-slate-900">
                        {reg.user.name ?? "未知用户"}
                      </p>
                      <p className="text-xs text-ary-muted">
                        GitHub: {reg.user.githubId}
                        {reg.user.email && ` | ${reg.user.email}`}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <ConnectionHealthIcon status={caStatus} />
                    <StatusBadge status={caStatus} />
                  </div>
                </div>

                {/* CA Connections list */}
                {connections.length > 0 ? (
                  <div className="mt-3 overflow-x-auto">
                    <table className="w-full text-left text-xs">
                      <thead>
                        <tr className="border-b border-ary-line">
                          <th className="pb-2 font-medium text-ary-muted">
                            连接类型
                          </th>
                          <th className="pb-2 font-medium text-ary-muted">
                            状态
                          </th>
                          <th className="pb-2 font-medium text-ary-muted">
                            Connector ID
                          </th>
                          <th className="pb-2 font-medium text-ary-muted">
                            注册时间
                          </th>
                          <th className="pb-2 font-medium text-ary-muted">
                            最后同步
                          </th>
                        </tr>
                      </thead>
                      <tbody>
                        {connections.map((conn) => (
                          <tr
                            key={conn.id}
                            className="border-b border-ary-line/50"
                          >
                            <td className="py-2 font-medium text-slate-700">
                              {conn.caType === "claude_code"
                                ? "Claude Code"
                                : conn.caType === "codex"
                                  ? "Codex"
                                  : "其他"}
                            </td>
                            <td className="py-2">
                              <StatusBadge status={conn.ingestionStatus} />
                            </td>
                            <td className="py-2 font-mono text-ary-muted">
                              {conn.connectorId ?? "-"}
                            </td>
                            <td className="py-2 text-ary-muted">
                              {conn.registeredAt
                                ? new Date(
                                    conn.registeredAt,
                                  ).toLocaleDateString("zh-CN", {
                                    month: "short",
                                    day: "numeric",
                                    hour: "2-digit",
                                    minute: "2-digit",
                                  })
                                : "-"}
                            </td>
                            <td className="py-2 text-ary-muted">
                              {conn.lastSyncedAt
                                ? new Date(
                                    conn.lastSyncedAt,
                                  ).toLocaleDateString("zh-CN", {
                                    month: "short",
                                    day: "numeric",
                                    hour: "2-digit",
                                    minute: "2-digit",
                                  })
                                : "-"}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                ) : (
                  <p className="mt-2 text-xs text-ary-muted">
                    暂无 CA 连接
                  </p>
                )}

                {/* Quick stats for active connection */}
                {caStatus === "active" && (
                  <div className="mt-3 flex gap-4 text-xs text-ary-muted">
                    <span className="flex items-center gap-1">
                      <Activity className="h-3 w-3" />
                      {connections.length} 连接
                    </span>
                    <span className="flex items-center gap-1">
                      <Clock className="h-3 w-3" />
                      {totalSessions} 会话
                    </span>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
