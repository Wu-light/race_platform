"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { FileText, Loader2 } from "lucide-react";

interface Props {
  raceId: string;
  hasReports: boolean;
}

export function GenerateReportButton({ raceId, hasReports }: Props) {
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState("");

  const generate = async (type: string) => {
    setLoading(true);
    setMessage("");
    try {
      const res = await fetch("/api/reports", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ raceId, type }),
      });
      if (res.ok) {
        setMessage(`报告 (${type === "all" ? "全部" : type}) 已生成`);
        router.refresh();
      } else {
        const err = await res.json();
        setMessage(err.error || "生成失败");
      }
    } catch {
      setMessage("网络错误");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex flex-wrap items-center gap-3">
      <button
        disabled={loading}
        onClick={() => generate("all")}
        className="inline-flex items-center gap-2 rounded-xl bg-ary-blue-800 px-5 py-2.5 text-sm font-bold text-white transition hover:bg-ary-blue-700 disabled:opacity-50"
      >
        {loading ? (
          <Loader2 className="h-4 w-4 animate-spin" />
        ) : (
          <FileText className="h-4 w-4" />
        )}
        生成全部报告
      </button>

      {hasReports && (
        <>
          <button
            disabled={loading}
            onClick={() => generate("race_report")}
            className="rounded-xl border border-ary-line bg-white px-4 py-2.5 text-sm font-bold text-ary-blue-800 transition hover:border-ary-blue-800 disabled:opacity-50"
          >
            仅赛事报告
          </button>
          <button
            disabled={loading}
            onClick={() => generate("review_summary")}
            className="rounded-xl border border-ary-line bg-white px-4 py-2.5 text-sm font-bold text-ary-blue-800 transition hover:border-ary-blue-800 disabled:opacity-50"
          >
            仅评审总结
          </button>
        </>
      )}

      {message && (
        <span className="text-sm font-medium text-ary-blue-700">{message}</span>
      )}
    </div>
  );
}
