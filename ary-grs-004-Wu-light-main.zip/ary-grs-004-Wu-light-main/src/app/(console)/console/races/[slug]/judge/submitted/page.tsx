import { prisma } from "@/lib/db";
import { requireAuth, requireJudgeForRace } from "@/lib/permissions";
import { JudgeNav } from "@/components/layout/JudgeNav";
import { EmptyState } from "@/components/ui/EmptyState";
import { MetricCard } from "@/components/ui/MetricCard";
import { ActionLink } from "@/components/ui/ActionLink";
import { formatDateTime } from "@/lib/utils";
import { FileText, ExternalLink, Star, Bike } from "lucide-react";

export default async function JudgeSubmittedPage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const userId = await requireAuth();

  const race = await prisma.race.findUnique({
    where: { slug },
    select: { id: true, title: true },
  });

  if (!race) {
    return (
      <div className="mx-auto max-w-[1440px] px-6 py-8">
        <EmptyState title="赛事不存在" description="未找到该赛事，请检查链接是否正确。" />
      </div>
    );
  }

  // Verify judge access
  await requireJudgeForRace(race.id);

  // Get all submitted judging records for this judge in this race
  const submittedRecords = await prisma.judgingRecord.findMany({
    where: {
      status: "submitted",
      assignment: {
        judgeId: userId,
        work: {
          registration: {
            raceId: race.id,
          },
        },
      },
    },
    include: {
      assignment: {
        include: {
          work: {
            include: {
              registration: {
                include: {
                  user: {
                    select: { id: true, name: true, school: true, company: true },
                  },
                },
              },
            },
          },
        },
      },
    },
    orderBy: { submittedAt: "desc" },
  });

  const total = submittedRecords.length;

  // Calculate average scores
  const avgScoreResult =
    total > 0
      ? submittedRecords.reduce(
          (sum, r) => sum + (r.scoreResult ?? 0),
          0,
        ) / total
      : 0;
  const avgScoreRiding =
    total > 0
      ? submittedRecords.reduce(
          (sum, r) => sum + (r.scoreRiding ?? 0),
          0,
        ) / total
      : 0;

  return (
    <div className="mx-auto max-w-[1440px] px-6 py-8">
      <JudgeNav slug={slug} current="submitted" />

      {/* Page Header */}
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-ary-blue-950">已提交评审</h1>
        <p className="mt-1 text-sm text-ary-muted">
          查看您已提交的评审记录
        </p>
      </div>

      {/* Summary Cards */}
      {total > 0 && (
        <div className="mb-8 grid grid-cols-1 gap-4 sm:grid-cols-3">
          <MetricCard
            label="已提交评审"
            value={total}
            hint="已提交评审结果的作品总数"
          />
          <MetricCard
            label="平均作品结果评分"
            value={avgScoreResult.toFixed(1)}
            hint="满分 10 分"
          />
          <MetricCard
            label="平均骑行能力评分"
            value={avgScoreRiding.toFixed(1)}
            hint="满分 10 分"
          />
        </div>
      )}

      {/* Submitted Records List */}
      {submittedRecords.length === 0 ? (
        <div>
          <EmptyState
            title="暂无已提交评审"
            description="您还没有提交任何评审结果，请先完成作品评审。"
          />
          <div className="mt-6 text-center">
            <ActionLink
              href={`/console/races/${slug}/judge`}
              variant="primary"
            >
              查看待评审作品
            </ActionLink>
          </div>
        </div>
      ) : (
        <div className="space-y-4">
          {submittedRecords.map((record) => {
            const work = record.assignment.work;
            const author = work.registration.user;

            return (
              <div
                key={record.id}
                className="rounded-xl border border-ary-line bg-white p-5 shadow-sm transition-shadow hover:shadow-md"
              >
                <div className="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
                  {/* Left: Work Info */}
                  <div className="min-w-0 flex-1">
                    <div className="flex items-start gap-3">
                      <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-emerald-100">
                        <FileText className="h-5 w-5 text-emerald-700" />
                      </div>
                      <div className="min-w-0">
                        <h3 className="truncate text-base font-semibold text-ary-blue-950">
                          {work.title}
                        </h3>
                        <p className="mt-0.5 text-sm text-ary-muted">
                          作者：{author.name || "未知"}
                          {(author.school || author.company) &&
                            ` · ${author.school || author.company}`}
                        </p>
                      </div>
                    </div>

                    {/* Scores */}
                    <div className="mt-3 flex flex-wrap gap-4">
                      <div className="inline-flex items-center gap-1.5 rounded-lg bg-ary-blue-50 px-3 py-1.5">
                        <Star className="h-3.5 w-3.5 text-ary-blue-700" />
                        <span className="text-xs font-semibold text-ary-blue-900">
                          作品结果：{record.scoreResult ?? "-"} 分
                        </span>
                      </div>
                      <div className="inline-flex items-center gap-1.5 rounded-lg bg-violet-50 px-3 py-1.5">
                        <Bike className="h-3.5 w-3.5 text-violet-700" />
                        <span className="text-xs font-semibold text-violet-900">
                          骑行能力：{record.scoreRiding ?? "-"} 分
                        </span>
                      </div>
                    </div>

                    {/* Comments Preview */}
                    {record.comments && (
                      <p className="mt-3 text-sm leading-6 text-ary-muted">
                        {record.comments.length > 100
                          ? `${record.comments.slice(0, 100)}...`
                          : record.comments}
                      </p>
                    )}

                    {/* Submitted Date */}
                    <p className="mt-2 text-xs text-ary-muted">
                      提交时间：{record.submittedAt ? formatDateTime(record.submittedAt) : "-"}
                    </p>
                  </div>

                  {/* Right: Action */}
                  <div className="flex shrink-0 items-center">
                    <ActionLink
                      href={`/console/races/${slug}/judge/reviewing?workId=${work.id}`}
                      variant="secondary"
                    >
                      查看完整评审
                      <ExternalLink className="h-4 w-4" />
                    </ActionLink>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
