"use server";

import { prisma } from "@/lib/db";
import { requireOrganizerOfRace } from "@/lib/permissions";
import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";

/** Get race by slug with organizer auth check. Returns race + race id for reuse. */
async function getAuthorizedRace(slug: string) {
  const race = await prisma.race.findUnique({ where: { slug } });
  if (!race) throw new Error("赛事不存在");
  await requireOrganizerOfRace(race.id);
  return race;
}

// ─── Settings ──────────────────────────────────────────────

export async function updateRaceSettings(
  slug: string,
  data: {
    title: string;
    subtitle?: string;
    description: string;
    challenge: string;
    rules: string;
    status: string;
    visibility: string;
    schedule: string; // JSON string
    awardSettings: string; // JSON string
    submissionRequirements: string; // JSON string
  },
) {
  await getAuthorizedRace(slug);
  await prisma.race.update({
    where: { slug },
    data: {
      title: data.title,
      subtitle: data.subtitle || null,
      description: data.description,
      challenge: data.challenge,
      rules: data.rules,
      status: data.status,
      visibility: data.visibility,
      schedule: data.schedule,
      awardSettings: data.awardSettings,
      submissionRequirements: data.submissionRequirements,
    },
  });
  revalidatePath(`/console/races/${slug}/organizer/settings`);
}

export async function publishRace(slug: string) {
  const race = await getAuthorizedRace(slug);
  if (race.status !== "draft" && race.status !== "published") {
    throw new Error("只有草稿或已发布状态的赛事可以发布");
  }
  await prisma.race.update({
    where: { slug },
    data: { status: "published" },
  });
  revalidatePath(`/console/races/${slug}/organizer`);
  redirect(`/console/races/${slug}/organizer`);
}

export async function archiveRace(slug: string) {
  const race = await getAuthorizedRace(slug);
  if (race.status === "archived") {
    throw new Error("赛事已归档");
  }
  await prisma.race.update({
    where: { slug },
    data: { status: "archived" },
  });
  revalidatePath(`/console/races/${slug}/organizer`);
  redirect(`/console/races/${slug}/organizer`);
}

// ─── Registrations ─────────────────────────────────────────

export async function approveRegistration(registrationId: string, slug: string) {
  const race = await prisma.race.findUnique({ where: { slug } });
  if (!race) throw new Error("赛事不存在");
  await requireOrganizerOfRace(race.id);

  await prisma.registration.update({
    where: { id: registrationId },
    data: { status: "approved", approvedAt: new Date() },
  });
  revalidatePath(`/console/races/${slug}/organizer/registrations`);
}

export async function rejectRegistration(registrationId: string, slug: string) {
  const race = await prisma.race.findUnique({ where: { slug } });
  if (!race) throw new Error("赛事不存在");
  await requireOrganizerOfRace(race.id);

  await prisma.registration.update({
    where: { id: registrationId },
    data: { status: "rejected" },
  });
  revalidatePath(`/console/races/${slug}/organizer/registrations`);
}

export async function batchApproveRegistrations(registrationIds: string[], slug: string) {
  const race = await prisma.race.findUnique({ where: { slug } });
  if (!race) throw new Error("赛事不存在");
  await requireOrganizerOfRace(race.id);

  await prisma.registration.updateMany({
    where: { id: { in: registrationIds }, raceId: race.id, status: "submitted" },
    data: { status: "approved", approvedAt: new Date() },
  });
  revalidatePath(`/console/races/${slug}/organizer/registrations`);
}

// ─── Works ─────────────────────────────────────────────────

export async function lockWork(workId: string, slug: string) {
  const race = await prisma.race.findUnique({ where: { slug } });
  if (!race) throw new Error("赛事不存在");
  await requireOrganizerOfRace(race.id);

  await prisma.work.update({
    where: { id: workId },
    data: { status: "locked" },
  });
  revalidatePath(`/console/races/${slug}/organizer/works`);
}

export async function unlockWork(workId: string, slug: string) {
  const race = await prisma.race.findUnique({ where: { slug } });
  if (!race) throw new Error("赛事不存在");
  await requireOrganizerOfRace(race.id);

  await prisma.work.update({
    where: { id: workId },
    data: { status: "submitted" },
  });
  revalidatePath(`/console/races/${slug}/organizer/works`);
}

export async function hideWork(workId: string, slug: string) {
  const race = await prisma.race.findUnique({ where: { slug } });
  if (!race) throw new Error("赛事不存在");
  await requireOrganizerOfRace(race.id);

  await prisma.work.update({
    where: { id: workId },
    data: { visibility: "hidden" },
  });
  revalidatePath(`/console/races/${slug}/organizer/works`);
}

export async function unhideWork(workId: string, slug: string) {
  const race = await prisma.race.findUnique({ where: { slug } });
  if (!race) throw new Error("赛事不存在");
  await requireOrganizerOfRace(race.id);

  await prisma.work.update({
    where: { id: workId },
    data: { visibility: "public" },
  });
  revalidatePath(`/console/races/${slug}/organizer/works`);
}

// ─── Judges ────────────────────────────────────────────────

export async function assignJudge(workId: string, judgeId: string, slug: string) {
  const race = await prisma.race.findUnique({ where: { slug } });
  if (!race) throw new Error("赛事不存在");
  const userId = await requireOrganizerOfRace(race.id);

  // Check if already assigned
  const existing = await prisma.judgeAssignment.findFirst({
    where: { workId, judgeId },
  });
  if (existing) throw new Error("该作品已分配给此评委");

  await prisma.judgeAssignment.create({
    data: {
      workId,
      judgeId,
      assignedByUserId: userId,
    },
  });
  revalidatePath(`/console/races/${slug}/organizer/judges`);
}

export async function removeJudgeAssignment(assignmentId: string, slug: string) {
  const race = await prisma.race.findUnique({ where: { slug } });
  if (!race) throw new Error("赛事不存在");
  await requireOrganizerOfRace(race.id);

  // Also delete associated judging record
  const record = await prisma.judgingRecord.findUnique({
    where: { assignmentId },
  });
  if (record) {
    await prisma.judgingRecord.delete({ where: { id: record.id } });
  }
  await prisma.judgeAssignment.delete({ where: { id: assignmentId } });
  revalidatePath(`/console/races/${slug}/organizer/judges`);
}

// ─── Awards ────────────────────────────────────────────────

export async function setAward(
  slug: string,
  data: {
    awardName: string;
    registrationId: string;
    rank: number;
    workId?: string;
    decisionReason?: string;
  },
) {
  const race = await prisma.race.findUnique({ where: { slug } });
  if (!race) throw new Error("赛事不存在");
  await requireOrganizerOfRace(race.id);

  // Upsert: if same race + awardName + registrationId exists, update
  const existing = await prisma.award.findFirst({
    where: {
      raceId: race.id,
      awardName: data.awardName,
      registrationId: data.registrationId,
    },
  });

  if (existing) {
    await prisma.award.update({
      where: { id: existing.id },
      data: {
        rank: data.rank,
        workId: data.workId || null,
        decisionReason: data.decisionReason || null,
      },
    });
  } else {
    await prisma.award.create({
      data: {
        raceId: race.id,
        registrationId: data.registrationId,
        awardName: data.awardName,
        rank: data.rank,
        workId: data.workId || null,
        decisionReason: data.decisionReason || null,
      },
    });
  }
  revalidatePath(`/console/races/${slug}/organizer/awards`);
}

export async function removeAward(awardId: string, slug: string) {
  const race = await prisma.race.findUnique({ where: { slug } });
  if (!race) throw new Error("赛事不存在");
  await requireOrganizerOfRace(race.id);

  await prisma.award.delete({ where: { id: awardId } });
  revalidatePath(`/console/races/${slug}/organizer/awards`);
}

export async function publishAwards(slug: string) {
  const race = await prisma.race.findUnique({ where: { slug } });
  if (!race) throw new Error("赛事不存在");
  await requireOrganizerOfRace(race.id);

  // Set publishedAt for all unpublished awards in this race
  const now = new Date();
  await prisma.award.updateMany({
    where: { raceId: race.id, publishedAt: null },
    data: { publishedAt: now },
  });
  revalidatePath(`/console/races/${slug}/organizer/awards`);
}

export async function unpublishAwards(slug: string) {
  const race = await prisma.race.findUnique({ where: { slug } });
  if (!race) throw new Error("赛事不存在");
  await requireOrganizerOfRace(race.id);

  await prisma.award.updateMany({
    where: { raceId: race.id },
    data: { publishedAt: null },
  });
  revalidatePath(`/console/races/${slug}/organizer/awards`);
}
