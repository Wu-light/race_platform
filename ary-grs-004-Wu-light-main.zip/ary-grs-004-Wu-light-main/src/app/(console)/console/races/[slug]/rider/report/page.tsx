import { auth } from "@/lib/auth";
import { prisma } from "@/lib/db";
import { RiderNav } from "@/components/layout/RiderNav";
import { redirect } from "next/navigation";
import { formatDateTime } from "@/lib/utils";
import { EmptyState } from "@/components/ui/EmptyState";
import {
  FileText,
  Clock,
  CheckCircle2,
  Loader2,
} from "lucide-react";

function ReportStatusBadge({ status }: { status: string }) {
  const styles: Record<string, string> = {
    draft: "border-slate-200 bg-slate-100 text-slate-600",
    generated: "border-blue-200 bg-blue-50 text-ary-blue-700",
    reviewed: "border-violet-200 bg-violet-50 text-violet-700",
    published: "border-emerald-200 bg-emerald-50 text-emerald-700",
  };
  const labels: Record<string, string> = {
    draft: "草稿",
    generated: "已生成",
    reviewed: "已审阅",
    published: "已发布",
  };
  return (
    <span
      className={`inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-xs font-semibold ${
        styles[status] ?? styles.draft
      }`}
    >
      {labels[status] ?? status}
    </span>
  );
}

export default async function RiderReportPage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const session = await auth();
  if (!session?.user) redirect("/login");
  const userId = session.user.id!;

  const race = await prisma.race.findUnique({ where: { slug } });
  if (!race) {
    return (
      <div className="mx-auto max-w-[1440px] px-6 py-8">
        <RiderNav slug={slug} current="report" />
        <p className="text-lg font-medium text-ary-muted">赛事不存在</p>
      </div>
    );
  }

  const registration = await prisma.registration.findUnique({
    where: {
      userId_raceId: { userId, raceId: race.id },
    },
  });

  if (!registration) {
    return (
      <div className="mx-auto max-w-[1440px] px-6 py-8">
        <RiderNav slug={slug} current="report" />
        <EmptyState
          title="尚未报名"
          description="请先报名参赛，赛事结束后可查看骑手报告。"
        />
      </div>
    );
  }

  // Find rider report for this registration
  const report = await prisma.report.findFirst({
    where: {
      raceId: race.id,
      subjectRegistrationId: registration.id,
      type: "rider_report",
    },
    orderBy: { createdAt: "desc" },
  });

  const isPublished = report?.status === "published";

  return (
    <div className="mx-auto max-w-[1440px] px-6 py-8">
      <RiderNav slug={slug} current="report" />

      <div className="mb-6">
        <h1 className="text-2xl font-bold text-slate-900">骑手报告</h1>
        <p className="mt-1 text-sm text-ary-muted">
          查看你的赛事骑乘综合报告
        </p>
      </div>

      {!report ? (
        /* Report not yet generated */
        <div className="rounded-2xl border border-ary-line bg-white p-8 text-center">
          <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-2xl bg-ary-surface">
            <Loader2 className="h-8 w-8 animate-spin text-ary-blue-500" />
          </div>
          <h2 className="text-xl font-bold text-slate-900">报告生成中</h2>
          <p className="mx-auto mt-2 max-w-md text-sm leading-6 text-ary-muted">
            你的骑手报告正在生成中。报告将在评审结束后自动生成，请稍后再来查看。
          </p>
          <div className="mt-4 flex items-center justify-center gap-2 text-xs text-ary-muted">
            <Clock className="h-3.5 w-3.5" />
            <span>通常在评审结束后数分钟内生成</span>
          </div>
        </div>
      ) : report.status !== "published" ? (
        /* Report exists but not published */
        <div className="rounded-2xl border border-ary-line bg-white p-8 text-center">
          <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-2xl bg-ary-surface">
            <FileText className="h-8 w-8 text-ary-blue-500" />
          </div>
          <h2 className="text-xl font-bold text-slate-900">报告尚未发布</h2>
          <ReportStatusBadge status={report.status} />
          <p className="mx-auto mt-4 max-w-md text-sm leading-6 text-ary-muted">
            报告已生成，正在审阅中。发布后即可查看完整内容。
          </p>
          {report.generatedAt && (
            <p className="mt-3 text-xs text-ary-muted">
              生成时间: {formatDateTime(report.generatedAt)}
            </p>
          )}
        </div>
      ) : (
        /* Published report */
        <div className="space-y-6">
          <div className="flex items-center justify-between rounded-2xl border border-emerald-200 bg-emerald-50 px-6 py-4">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="h-5 w-5 text-emerald-600" />
              <span className="font-semibold text-emerald-900">
                报告已发布
              </span>
            </div>
            <div className="text-xs text-emerald-700">
              {report.publishedAt && (
                <span>发布时间: {formatDateTime(report.publishedAt)}</span>
              )}
            </div>
          </div>

          <div className="rounded-2xl border border-ary-line bg-white p-6">
            <h2 className="mb-2 text-lg font-bold text-slate-900">
              骑手报告
            </h2>
            <p className="mb-4 text-sm text-ary-muted">
              你的个人赛事表现综合报告（由 AI 生成）
            </p>
            <div className="prose prose-sm max-w-none prose-headings:text-ary-blue-900 prose-p:text-slate-700">
              <div className="whitespace-pre-wrap text-sm leading-7 text-slate-700">
                {report.content}
              </div>
            </div>
          </div>

          <div className="rounded-2xl border border-ary-line bg-white p-6">
            <h3 className="mb-3 text-sm font-bold uppercase tracking-wider text-ary-muted">
              报告信息
            </h3>
            <div className="grid gap-2 text-sm sm:grid-cols-2">
              <div>
                <span className="text-ary-muted">生成时间:</span>
                <span className="ml-2 font-medium text-slate-900">
                  {report.generatedAt
                    ? formatDateTime(report.generatedAt)
                    : "--"}
                </span>
              </div>
              <div>
                <span className="text-ary-muted">发布时间:</span>
                <span className="ml-2 font-medium text-slate-900">
                  {report.publishedAt
                    ? formatDateTime(report.publishedAt)
                    : "--"}
                </span>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
