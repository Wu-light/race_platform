"use client";

import { useEffect, useState, useCallback } from "react";
import { useParams, useRouter } from "next/navigation";
import { RiderNav } from "@/components/layout/RiderNav";
import { ActionLink } from "@/components/ui/ActionLink";
import { EmptyState } from "@/components/ui/EmptyState";
import {
  Loader2,
  TriangleAlert,
  Save,
  Send,
  ExternalLink,
  Github,
  Video,
  Code,
  Eye,
  CheckCircle2,
  Clock,
  Lock,
} from "lucide-react";

// ---------- Types ----------

interface WorkData {
  id: string;
  slug: string;
  title: string;
  description: string;
  demoUrl: string | null;
  githubUrl: string | null;
  videoUrl: string | null;
  techDescription: string | null;
  status: string;
  createdAt: string;
  updatedAt: string;
}

interface RegistrationData {
  id: string;
  status: string;
  work: WorkData | null;
}

// ---------- Status Badge ----------

function WorkStatusBadge({ status }: { status: string }) {
  const styles: Record<string, string> = {
    draft: "border-slate-200 bg-slate-100 text-slate-600",
    submitted: "border-blue-200 bg-blue-50 text-ary-blue-700",
    locked: "border-violet-200 bg-violet-50 text-violet-700",
    hidden: "border-slate-200 bg-slate-100 text-slate-600",
  };
  const labels: Record<string, string> = {
    draft: "草稿",
    submitted: "已提交",
    locked: "已锁定",
    hidden: "已隐藏",
  };
  const icons: Record<string, React.ReactNode> = {
    draft: <Clock className="h-3.5 w-3.5" />,
    submitted: <CheckCircle2 className="h-3.5 w-3.5" />,
    locked: <Lock className="h-3.5 w-3.5" />,
  };
  return (
    <span
      className={`inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-xs font-semibold ${
        styles[status] ?? styles.draft
      }`}
    >
      {icons[status] ?? null}
      {labels[status] ?? status}
    </span>
  );
}

// ---------- Main Component ----------

export default function SubmissionPage() {
  const params = useParams();
  const router = useRouter();
  const slug = params.slug as string;

  const [registration, setRegistration] = useState<RegistrationData | null>(
    null,
  );
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Form state
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [demoUrl, setDemoUrl] = useState("");
  const [githubUrl, setGithubUrl] = useState("");
  const [videoUrl, setVideoUrl] = useState("");
  const [techDescription, setTechDescription] = useState("");
  const [workId, setWorkId] = useState<string | null>(null);

  const [submitting, setSubmitting] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);
  const [formSuccess, setFormSuccess] = useState<string | null>(null);

  const [viewMode, setViewMode] = useState<"create" | "edit" | "readonly">(
    "create",
  );

  const fetchData = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch(`/api/registrations?raceSlug=${slug}`);
      if (!res.ok) {
        throw new Error("无法获取报名信息");
      }
      const data = await res.json();
      const reg = data.registration as RegistrationData | null;
      setRegistration(reg);

      if (reg?.work) {
        const w = reg.work;
        setWorkId(w.id);
        setTitle(w.title);
        setDescription(w.description);
        setDemoUrl(w.demoUrl ?? "");
        setGithubUrl(w.githubUrl ?? "");
        setVideoUrl(w.videoUrl ?? "");
        setTechDescription(w.techDescription ?? "");

        if (w.status === "draft") {
          setViewMode("edit");
        } else {
          setViewMode("readonly");
        }
      } else {
        setViewMode("create");
      }
    } catch (e: any) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  }, [slug]);

  useEffect(() => {
    fetchData();
  }, [fetchData]);

  // Validate form
  function validate(): string | null {
    if (!title.trim()) return "标题为必填项";
    if (!description.trim()) return "描述为必填项";
    return null;
  }

  // Create work (draft)
  async function handleSaveDraft(e: React.FormEvent) {
    e.preventDefault();
    const validationError = validate();
    if (validationError) {
      setFormError(validationError);
      return;
    }
    if (!registration) return;

    setSubmitting(true);
    setFormError(null);
    setFormSuccess(null);
    try {
      const res = await fetch("/api/works", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          registrationId: registration.id,
          title: title.trim(),
          description: description.trim(),
          demoUrl: demoUrl.trim() || null,
          githubUrl: githubUrl.trim() || null,
          videoUrl: videoUrl.trim() || null,
          techDescription: techDescription.trim() || null,
        }),
      });
      if (!res.ok) {
        const data = await res.json();
        throw new Error(data.error ?? "保存失败");
      }
      const work = await res.json();
      setWorkId(work.id);
      setFormSuccess("草稿已保存");
      await fetchData();
    } catch (e: any) {
      setFormError(e.message);
    } finally {
      setSubmitting(false);
    }
  }

  // Submit work
  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    const validationError = validate();
    if (validationError) {
      setFormError(validationError);
      return;
    }

    if (!registration) return;

    setSubmitting(true);
    setFormError(null);
    setFormSuccess(null);
    try {
      // Create if no workId yet
      let currentWorkId = workId;
      if (!currentWorkId) {
        const createRes = await fetch("/api/works", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            registrationId: registration.id,
            title: title.trim(),
            description: description.trim(),
            demoUrl: demoUrl.trim() || null,
            githubUrl: githubUrl.trim() || null,
            videoUrl: videoUrl.trim() || null,
            techDescription: techDescription.trim() || null,
          }),
        });
        if (!createRes.ok) {
          const data = await createRes.json();
          throw new Error(data.error ?? "创建作品失败");
        }
        const work = await createRes.json();
        currentWorkId = work.id;
        setWorkId(currentWorkId);
      } else {
        // Update content first
        const updateRes = await fetch(`/api/works/${currentWorkId}`, {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            title: title.trim(),
            description: description.trim(),
            demoUrl: demoUrl.trim() || null,
            githubUrl: githubUrl.trim() || null,
            videoUrl: videoUrl.trim() || null,
            techDescription: techDescription.trim() || null,
          }),
        });
        if (!updateRes.ok) {
          const data = await updateRes.json();
          throw new Error(data.error ?? "更新作品失败");
        }
      }

      // Submit
      const submitRes = await fetch(`/api/works/${currentWorkId}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "submit" }),
      });
      if (!submitRes.ok) {
        const data = await submitRes.json();
        throw new Error(data.error ?? "提交失败");
      }

      setFormSuccess("作品已成功提交！");
      await fetchData();
    } catch (e: any) {
      setFormError(e.message);
    } finally {
      setSubmitting(false);
    }
  }

  // Update draft (for existing work in draft status)
  async function handleUpdateDraft(e: React.FormEvent) {
    e.preventDefault();
    const validationError = validate();
    if (validationError) {
      setFormError(validationError);
      return;
    }
    if (!workId) return;

    setSubmitting(true);
    setFormError(null);
    setFormSuccess(null);
    try {
      const res = await fetch(`/api/works/${workId}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          title: title.trim(),
          description: description.trim(),
          demoUrl: demoUrl.trim() || null,
          githubUrl: githubUrl.trim() || null,
          videoUrl: videoUrl.trim() || null,
          techDescription: techDescription.trim() || null,
        }),
      });
      if (!res.ok) {
        const data = await res.json();
        throw new Error(data.error ?? "更新失败");
      }
      setFormSuccess("草稿已更新");
    } catch (e: any) {
      setFormError(e.message);
    } finally {
      setSubmitting(false);
    }
  }

  // ----- Render -----

  if (loading) {
    return (
      <div className="mx-auto flex max-w-[1440px] items-center justify-center px-6 py-24">
        <Loader2 className="h-8 w-8 animate-spin text-ary-blue-500" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="mx-auto max-w-[1440px] px-6 py-8">
        <RiderNav slug={slug} current="submission" />
        <div className="rounded-2xl border border-red-200 bg-red-50 p-6 text-center">
          <TriangleAlert className="mx-auto h-8 w-8 text-red-500" />
          <p className="mt-2 text-sm text-red-700">{error}</p>
        </div>
      </div>
    );
  }

  if (!registration) {
    return (
      <div className="mx-auto max-w-[1440px] px-6 py-8">
        <RiderNav slug={slug} current="submission" />
        <EmptyState
          title="尚未报名"
          description="请先报名参赛以提交作品。"
        />
        <ActionLink href={`/console/races/${slug}/rider`} className="mt-4">
          前往报名
        </ActionLink>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-[1440px] px-6 py-8">
      <RiderNav slug={slug} current="submission" />

      <div className="mb-6">
        <h1 className="text-2xl font-bold text-slate-900">作品提交</h1>
        <p className="mt-1 text-sm text-ary-muted">
          提交你的赛事参赛作品
        </p>
      </div>

      {/* Success/Error messages */}
      {formSuccess && (
        <div className="mb-6 rounded-2xl border border-emerald-200 bg-emerald-50 px-6 py-4">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="h-5 w-5 text-emerald-600" />
            <span className="font-semibold text-emerald-900">{formSuccess}</span>
          </div>
        </div>
      )}

      {formError && (
        <div className="mb-6 rounded-2xl border border-red-200 bg-red-50 px-6 py-4">
          <div className="flex items-center gap-2">
            <TriangleAlert className="h-5 w-5 text-red-500" />
            <span className="font-semibold text-red-900">{formError}</span>
          </div>
        </div>
      )}

      <div className="rounded-2xl border border-ary-line bg-white p-6">
        {/* Read-only view */}
        {viewMode === "readonly" && registration.work && (
          <div>
            <div className="mb-6 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <h2 className="text-lg font-bold text-slate-900">
                  {registration.work.title}
                </h2>
                <WorkStatusBadge status={registration.work.status} />
              </div>
            </div>

            <div className="mb-6">
              <h3 className="mb-2 text-sm font-bold uppercase tracking-wider text-ary-muted">
                描述
              </h3>
              <div className="whitespace-pre-wrap rounded-xl bg-slate-50 p-4 text-sm leading-7 text-slate-700">
                {registration.work.description}
              </div>
            </div>

            {/* Links */}
            <div className="mb-6 flex flex-wrap gap-3">
              {registration.work.demoUrl && (
                <a
                  href={registration.work.demoUrl}
                  target="_blank"
                  rel="noreferrer"
                  className="inline-flex items-center gap-1.5 rounded-lg border border-ary-line bg-white px-3 py-1.5 text-xs font-semibold text-ary-blue-700 transition-colors hover:bg-ary-surface"
                >
                  <ExternalLink className="h-3.5 w-3.5" />
                  Demo
                </a>
              )}
              {registration.work.githubUrl && (
                <a
                  href={registration.work.githubUrl}
                  target="_blank"
                  rel="noreferrer"
                  className="inline-flex items-center gap-1.5 rounded-lg border border-ary-line bg-white px-3 py-1.5 text-xs font-semibold text-ary-blue-700 transition-colors hover:bg-ary-surface"
                >
                  <Github className="h-3.5 w-3.5" />
                  GitHub
                </a>
              )}
              {registration.work.videoUrl && (
                <a
                  href={registration.work.videoUrl}
                  target="_blank"
                  rel="noreferrer"
                  className="inline-flex items-center gap-1.5 rounded-lg border border-ary-line bg-white px-3 py-1.5 text-xs font-semibold text-ary-blue-700 transition-colors hover:bg-ary-surface"
                >
                  <Video className="h-3.5 w-3.5" />
                  视频
                </a>
              )}
            </div>

            {/* Tech Description */}
            {registration.work.techDescription && (
              <div>
                <h3 className="mb-2 text-sm font-bold uppercase tracking-wider text-ary-muted">
                  技术说明
                </h3>
                <div className="whitespace-pre-wrap rounded-xl bg-slate-50 p-4 text-sm leading-7 text-slate-700">
                  {registration.work.techDescription}
                </div>
              </div>
            )}

            {/* Read-only actions */}
            {registration.work.status === "submitted" && (
              <div className="mt-6 rounded-xl border border-blue-200 bg-blue-50 p-4">
                <div className="flex items-center gap-2">
                  <CheckCircle2 className="h-5 w-5 text-ary-blue-700" />
                  <span className="text-sm font-semibold text-ary-blue-900">
                    作品已提交，等待评审
                  </span>
                </div>
              </div>
            )}
            {registration.work.status === "locked" && (
              <div className="mt-6 rounded-xl border border-violet-200 bg-violet-50 p-4">
                <div className="flex items-center gap-2">
                  <Lock className="h-5 w-5 text-violet-700" />
                  <span className="text-sm font-semibold text-violet-900">
                    作品已被锁定，无法修改
                  </span>
                </div>
              </div>
            )}
          </div>
        )}

        {/* Create / Edit Form */}
        {(viewMode === "create" || viewMode === "edit") && (
          <form
            onSubmit={
              viewMode === "create"
                ? handleSaveDraft
                : handleUpdateDraft
            }
            className="space-y-5"
          >
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-bold text-slate-900">
                {viewMode === "create" ? "创建作品" : "编辑作品"}
              </h2>
              {registration.work && (
                <WorkStatusBadge status={registration.work.status} />
              )}
            </div>

            {/* Title */}
            <div>
              <label className="mb-1.5 block text-xs font-semibold uppercase tracking-wider text-ary-muted">
                标题 <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="输入作品标题"
                required
                className="w-full rounded-xl border border-ary-line bg-white px-3 py-2.5 text-sm text-slate-900 placeholder:text-slate-400 focus:border-ary-blue-500 focus:outline-none focus:ring-2 focus:ring-ary-blue-100"
              />
            </div>

            {/* Description */}
            <div>
              <label className="mb-1.5 block text-xs font-semibold uppercase tracking-wider text-ary-muted">
                描述 <span className="text-red-500">*</span>
              </label>
              <textarea
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="描述你的作品（支持 Markdown 格式）"
                required
                rows={6}
                className="w-full rounded-xl border border-ary-line bg-white px-3 py-2.5 text-sm text-slate-900 placeholder:text-slate-400 focus:border-ary-blue-500 focus:outline-none focus:ring-2 focus:ring-ary-blue-100"
              />
              <p className="mt-1 text-xs text-ary-muted">
                支持 Markdown 格式
              </p>
            </div>

            {/* Demo URL */}
            <div>
              <label className="mb-1.5 block text-xs font-semibold uppercase tracking-wider text-ary-muted">
                Demo 链接
              </label>
              <div className="relative">
                <ExternalLink className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-ary-muted" />
                <input
                  type="url"
                  value={demoUrl}
                  onChange={(e) => setDemoUrl(e.target.value)}
                  placeholder="https://demo.example.com"
                  className="w-full rounded-xl border border-ary-line bg-white py-2.5 pl-10 pr-3 text-sm text-slate-900 placeholder:text-slate-400 focus:border-ary-blue-500 focus:outline-none focus:ring-2 focus:ring-ary-blue-100"
                />
              </div>
            </div>

            {/* GitHub URL */}
            <div>
              <label className="mb-1.5 block text-xs font-semibold uppercase tracking-wider text-ary-muted">
                GitHub 链接
              </label>
              <div className="relative">
                <Github className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-ary-muted" />
                <input
                  type="url"
                  value={githubUrl}
                  onChange={(e) => setGithubUrl(e.target.value)}
                  placeholder="https://github.com/username/repo"
                  className="w-full rounded-xl border border-ary-line bg-white py-2.5 pl-10 pr-3 text-sm text-slate-900 placeholder:text-slate-400 focus:border-ary-blue-500 focus:outline-none focus:ring-2 focus:ring-ary-blue-100"
                />
              </div>
            </div>

            {/* Video URL */}
            <div>
              <label className="mb-1.5 block text-xs font-semibold uppercase tracking-wider text-ary-muted">
                视频链接
              </label>
              <div className="relative">
                <Video className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-ary-muted" />
                <input
                  type="url"
                  value={videoUrl}
                  onChange={(e) => setVideoUrl(e.target.value)}
                  placeholder="https://youtube.com/watch?v=..."
                  className="w-full rounded-xl border border-ary-line bg-white py-2.5 pl-10 pr-3 text-sm text-slate-900 placeholder:text-slate-400 focus:border-ary-blue-500 focus:outline-none focus:ring-2 focus:ring-ary-blue-100"
                />
              </div>
            </div>

            {/* Tech Description */}
            <div>
              <label className="mb-1.5 block text-xs font-semibold uppercase tracking-wider text-ary-muted">
                技术说明
              </label>
              <div className="relative">
                <Code className="pointer-events-none absolute left-3 top-3 h-4 w-4 text-ary-muted" />
                <textarea
                  value={techDescription}
                  onChange={(e) => setTechDescription(e.target.value)}
                  placeholder="描述技术实现、架构等（支持 Markdown）"
                  rows={4}
                  className="w-full rounded-xl border border-ary-line bg-white py-2.5 pl-10 pr-3 text-sm text-slate-900 placeholder:text-slate-400 focus:border-ary-blue-500 focus:outline-none focus:ring-2 focus:ring-ary-blue-100"
                />
              </div>
              <p className="mt-1 text-xs text-ary-muted">
                支持 Markdown 格式
              </p>
            </div>

            {/* Action Buttons */}
            <div className="flex flex-wrap gap-3 border-t border-ary-line pt-5">
              {viewMode === "create" && (
                <>
                  <button
                    type="submit"
                    disabled={submitting}
                    className="inline-flex items-center gap-2 rounded-xl border border-ary-line bg-white px-5 py-2.5 text-sm font-semibold text-ary-blue-900 shadow-sm transition duration-200 hover:border-ary-line-strong hover:bg-white disabled:cursor-not-allowed disabled:opacity-50"
                  >
                    {submitting ? (
                      <Loader2 className="h-4 w-4 animate-spin" />
                    ) : (
                      <Save className="h-4 w-4" />
                    )}
                    保存草稿
                  </button>
                  <button
                    type="button"
                    onClick={handleSubmit}
                    disabled={submitting}
                    className="inline-flex items-center gap-2 rounded-xl bg-gradient-to-br from-ary-blue-800 to-ary-blue-500 px-5 py-2.5 text-sm font-semibold text-white shadow-[0_12px_30px_rgba(7,91,236,0.22)] transition duration-200 hover:-translate-y-0.5 hover:shadow-[0_16px_34px_rgba(7,91,236,0.3)] disabled:cursor-not-allowed disabled:opacity-50"
                  >
                    {submitting ? (
                      <Loader2 className="h-4 w-4 animate-spin" />
                    ) : (
                      <Send className="h-4 w-4" />
                    )}
                    提交作品
                  </button>
                </>
              )}
              {viewMode === "edit" && (
                <>
                  <button
                    type="submit"
                    disabled={submitting}
                    className="inline-flex items-center gap-2 rounded-xl border border-ary-line bg-white px-5 py-2.5 text-sm font-semibold text-ary-blue-900 shadow-sm transition duration-200 hover:border-ary-line-strong hover:bg-white disabled:cursor-not-allowed disabled:opacity-50"
                  >
                    {submitting ? (
                      <Loader2 className="h-4 w-4 animate-spin" />
                    ) : (
                      <Save className="h-4 w-4" />
                    )}
                    更新草稿
                  </button>
                  <button
                    type="button"
                    onClick={handleSubmit}
                    disabled={submitting}
                    className="inline-flex items-center gap-2 rounded-xl bg-gradient-to-br from-ary-blue-800 to-ary-blue-500 px-5 py-2.5 text-sm font-semibold text-white shadow-[0_12px_30px_rgba(7,91,236,0.22)] transition duration-200 hover:-translate-y-0.5 hover:shadow-[0_16px_34px_rgba(7,91,236,0.3)] disabled:cursor-not-allowed disabled:opacity-50"
                  >
                    {submitting ? (
                      <Loader2 className="h-4 w-4 animate-spin" />
                    ) : (
                      <Send className="h-4 w-4" />
                    )}
                    提交作品
                  </button>
                </>
              )}
            </div>
          </form>
        )}
      </div>
    </div>
  );
}
