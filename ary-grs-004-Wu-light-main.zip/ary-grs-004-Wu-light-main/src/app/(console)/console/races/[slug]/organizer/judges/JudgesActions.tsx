"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { assignJudge, removeJudgeAssignment } from "../actions";
import Link from "next/link";
import {
  UserPlus,
  Trash2,
  CheckCircle2,
  Clock,
  BookOpen,
  Users,
} from "lucide-react";

interface WorkItem {
  id: string;
  title: string;
  slug: string;
  authorName: string;
}

interface JudgeItem {
  id: string;
  name: string;
  email: string;
}

interface AssignmentItem {
  id: string;
  workTitle: string;
  workSlug: string;
  judgeName: string;
  judgeId: string;
  assignedByName: string;
  assignedAt: string;
  judgingStatus: string | null;
  scoreResult: number | null;
  scoreRiding: number | null;
}

export function JudgesActions({
  works,
  judges,
  assignments,
  slug,
}: {
  works: WorkItem[];
  judges: JudgeItem[];
  assignments: AssignmentItem[];
  slug: string;
}) {
  const router = useRouter();
  const [selectedWorkId, setSelectedWorkId] = useState("");
  const [selectedJudgeId, setSelectedJudgeId] = useState("");
  const [assigning, setAssigning] = useState(false);
  const [removingId, setRemovingId] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  const handleAssign = async () => {
    if (!selectedWorkId || !selectedJudgeId) {
      setError("请选择作品和评委");
      return;
    }
    setAssigning(true);
    setError(null);
    try {
      await assignJudge(selectedWorkId, selectedJudgeId, slug);
      setSelectedWorkId("");
      setSelectedJudgeId("");
      router.refresh();
    } catch (err: any) {
      setError(err.message ?? "分配失败");
    } finally {
      setAssigning(false);
    }
  };

  const handleRemove = async (assignmentId: string) => {
    setRemovingId(assignmentId);
    try {
      await removeJudgeAssignment(assignmentId, slug);
      router.refresh();
    } catch (err) {
      console.error(err);
    } finally {
      setRemovingId(null);
    }
  };

  // Build set of already-assigned work ids
  const assignedWorkIds = new Set(assignments.map((a) => a.workSlug));

  // Works not yet assigned to any judge
  const unassignedWorks = works.filter(
    (w) => !assignedWorkIds.has(w.slug),
  );

  return (
    <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
      {/* Left: Assign Panel */}
      <div className="rounded-xl border border-ary-line bg-white p-6">
        <h2 className="mb-4 flex items-center gap-2 text-base font-semibold text-slate-900">
          <UserPlus className="h-5 w-5 text-ary-blue-700" />
          分配评委
        </h2>

        {error && (
          <div className="mb-3 rounded-lg border border-red-200 bg-red-50 p-3 text-xs text-red-700">
            {error}
          </div>
        )}

        <div className="space-y-4">
          {/* Work Select */}
          <div>
            <label className="mb-1 block text-sm font-medium text-slate-700">
              选择作品
            </label>
            <select
              value={selectedWorkId}
              onChange={(e) => setSelectedWorkId(e.target.value)}
              className="w-full rounded-lg border border-ary-line px-3 py-2 text-sm focus:border-ary-blue-500 focus:outline-none focus:ring-1 focus:ring-ary-blue-500"
            >
              <option value="">-- 请选择 --</option>
              {unassignedWorks.map((w) => (
                <option key={w.id} value={w.id}>
                  {w.title} ({w.authorName})
                </option>
              ))}
              {unassignedWorks.length === 0 && (
                <option value="" disabled>
                  所有作品已分配
                </option>
              )}
            </select>
          </div>

          {/* Judge Select */}
          <div>
            <label className="mb-1 block text-sm font-medium text-slate-700">
              选择评委
            </label>
            <select
              value={selectedJudgeId}
              onChange={(e) => setSelectedJudgeId(e.target.value)}
              className="w-full rounded-lg border border-ary-line px-3 py-2 text-sm focus:border-ary-blue-500 focus:outline-none focus:ring-1 focus:ring-ary-blue-500"
            >
              <option value="">-- 请选择 --</option>
              {judges.map((j) => (
                <option key={j.id} value={j.id}>
                  {j.name} ({j.email})
                </option>
              ))}
              {judges.length === 0 && (
                <option value="" disabled>
                  暂无评委用户
                </option>
              )}
            </select>
          </div>

          <button
            onClick={handleAssign}
            disabled={assigning || !selectedWorkId || !selectedJudgeId}
            className="inline-flex w-full items-center justify-center gap-1.5 rounded-lg bg-ary-blue-700 px-4 py-2 text-sm font-semibold text-white transition-colors hover:bg-ary-blue-800 disabled:opacity-50"
          >
            {assigning ? "分配中..." : "确认分配"}
          </button>
        </div>

        {/* Works list */}
        <div className="mt-6">
          <h3 className="mb-2 flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-ary-muted">
            <BookOpen className="h-3.5 w-3.5" />
            全部作品 ({works.length})
          </h3>
          <div className="max-h-48 space-y-1 overflow-y-auto">
            {works.map((w) => {
              const isAssigned = assignedWorkIds.has(w.slug);
              return (
                <div
                  key={w.id}
                  className={`flex items-center justify-between rounded-lg px-3 py-2 text-sm ${
                    isAssigned
                      ? "bg-green-50 text-green-800"
                      : "bg-slate-50 text-slate-700"
                  }`}
                >
                  <span className="truncate">{w.title}</span>
                  {isAssigned ? (
                    <CheckCircle2 className="h-4 w-4 shrink-0 text-green-600" />
                  ) : (
                    <Clock className="h-4 w-4 shrink-0 text-ary-muted" />
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Right: Assignments Table */}
      <div>
        <div className="rounded-xl border border-ary-line bg-white">
          <div className="border-b border-ary-line px-6 py-4">
            <h2 className="flex items-center gap-2 text-base font-semibold text-slate-900">
              <Users className="h-5 w-5 text-ary-blue-700" />
              当前分配 ({assignments.length})
            </h2>
          </div>

          {assignments.length === 0 ? (
            <div className="flex flex-col items-center py-12 text-center">
              <Users className="mb-2 h-8 w-8 text-ary-muted" />
              <p className="text-sm text-ary-muted">暂无分配</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full text-left text-sm">
                <thead>
                  <tr className="border-b border-ary-line bg-slate-50">
                    <th className="px-4 py-3 font-medium text-ary-muted">
                      作品
                    </th>
                    <th className="px-4 py-3 font-medium text-ary-muted">
                      评委
                    </th>
                    <th className="px-4 py-3 font-medium text-ary-muted">
                      评审状态
                    </th>
                    <th className="px-4 py-3 font-medium text-ary-muted">
                      操作
                    </th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-ary-line">
                  {assignments.map((a) => (
                    <tr
                      key={a.id}
                      className="transition-colors hover:bg-slate-50"
                    >
                      <td className="px-4 py-3">
                        <Link
                          href={`/works/${a.workSlug}`}
                          className="font-medium text-ary-blue-700 hover:underline"
                        >
                          {a.workTitle}
                        </Link>
                      </td>
                      <td className="px-4 py-3 text-sm text-slate-700">
                        {a.judgeName}
                      </td>
                      <td className="px-4 py-3">
                        {a.judgingStatus === "submitted" ? (
                          <span className="inline-flex items-center rounded-full bg-green-100 px-2 py-0.5 text-xs font-semibold text-green-700">
                            已完成
                            {a.scoreResult != null && ` (${a.scoreResult}/10)`}
                          </span>
                        ) : a.judgingStatus === "draft" ? (
                          <span className="inline-flex items-center rounded-full bg-yellow-100 px-2 py-0.5 text-xs font-semibold text-yellow-700">
                            评审中
                          </span>
                        ) : (
                          <span className="text-xs text-ary-muted">
                            未开始
                          </span>
                        )}
                      </td>
                      <td className="px-4 py-3">
                        <button
                          onClick={() => handleRemove(a.id)}
                          disabled={removingId === a.id}
                          className="inline-flex items-center gap-1 rounded-lg bg-red-50 px-2.5 py-1.5 text-xs font-medium text-red-700 transition-colors hover:bg-red-100 disabled:opacity-50"
                        >
                          <Trash2 className="h-3.5 w-3.5" />
                          {removingId === a.id ? "..." : "移除"}
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
