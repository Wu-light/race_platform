"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";

export function RegisterButton({ raceId }: { raceId: string }) {
  const router = useRouter();
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function handleRegister() {
    setLoading(true);
    setError(null);
    try {
      const res = await fetch("/api/registrations", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ raceId }),
      });
      if (!res.ok) {
        const data = await res.json();
        throw new Error(data.error ?? "报名失败");
      }
      router.refresh();
    } catch (e: any) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div>
      <button
        type="button"
        onClick={handleRegister}
        disabled={loading}
        className="inline-flex min-h-11 items-center justify-center gap-2 rounded-xl bg-gradient-to-br from-ary-blue-800 to-ary-blue-500 px-6 py-2.5 text-sm font-semibold text-white shadow-[0_12px_30px_rgba(7,91,236,0.22)] transition duration-200 hover:-translate-y-0.5 hover:shadow-[0_16px_34px_rgba(7,91,236,0.3)] disabled:cursor-not-allowed disabled:opacity-50"
      >
        {loading ? "提交中..." : "报名参赛"}
      </button>
      {error && <p className="mt-2 text-xs text-red-600">{error}</p>}
    </div>
  );
}
