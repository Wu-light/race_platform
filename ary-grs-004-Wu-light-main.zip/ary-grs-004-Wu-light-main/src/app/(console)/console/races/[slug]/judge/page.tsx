import { prisma } from "@/lib/db";
import { requireAuth, requireJudgeForRace } from "@/lib/permissions";
import { JudgeNav } from "@/components/layout/JudgeNav";
import { EmptyState } from "@/components/ui/EmptyState";
import { MetricCard } from "@/components/ui/MetricCard";
import { ActionLink } from "@/components/ui/ActionLink";
import { formatDate } from "@/lib/utils";
import { FileText, ExternalLink } from "lucide-react";

function getStatusInfo(
  judgingRecord: { id: string; status: string } | null,
): {
  label: string;
  color: string;
  bgColor: string;
  dotColor: string;
} {
  if (!judgingRecord) {
    return {
      label: "未开始",
      color: "text-slate-500",
      bgColor: "bg-slate-100",
      dotColor: "bg-slate-400",
    };
  }
  if (judgingRecord.status === "draft") {
    return {
      label: "草稿",
      color: "text-amber-700",
      bgColor: "bg-amber-50",
      dotColor: "bg-amber-500",
    };
  }
  return {
    label: "已提交",
    color: "text-emerald-700",
    bgColor: "bg-emerald-50",
    dotColor: "bg-emerald-500",
  };
}

export default async function JudgeAssignedPage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const userId = await requireAuth();

  const race = await prisma.race.findUnique({
    where: { slug },
    select: { id: true, title: true },
  });

  if (!race) {
    return (
      <div className="mx-auto max-w-[1440px] px-6 py-8">
        <EmptyState title="赛事不存在" description="未找到该赛事，请检查链接是否正确。" />
      </div>
    );
  }

  // Verify judge access
  await requireJudgeForRace(race.id);

  const assignments = await prisma.judgeAssignment.findMany({
    where: {
      judgeId: userId,
      work: {
        registration: {
          raceId: race.id,
        },
      },
    },
    include: {
      work: {
        include: {
          registration: {
            include: {
              user: {
                select: { id: true, name: true, school: true, company: true },
              },
            },
          },
        },
      },
      judgingRecord: {
        select: { id: true, status: true, submittedAt: true },
      },
    },
    orderBy: { assignedAt: "desc" },
  });

  const total = assignments.length;
  const completed = assignments.filter(
    (a) => a.judgingRecord?.status === "submitted",
  ).length;
  const pending = total - completed;
  const inDraft = assignments.filter(
    (a) => a.judgingRecord?.status === "draft",
  ).length;

  return (
    <div className="mx-auto max-w-[1440px] px-6 py-8">
      <JudgeNav slug={slug} current="assigned" />

      {/* Page Header */}
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-ary-blue-950">评审作品列表</h1>
        <p className="mt-1 text-sm text-ary-muted">
          查看和管理分配给您的评审作品
        </p>
      </div>

      {/* Summary Cards */}
      <div className="mb-8 grid grid-cols-1 gap-4 sm:grid-cols-3">
        <MetricCard label="总分配" value={total} hint="分配给您评审的作品总数" />
        <MetricCard
          label="已完成"
          value={completed}
          hint="已提交评审结果的作品"
          className="border-emerald-200/50"
        />
        <MetricCard
          label="待评审"
          value={pending}
          hint={inDraft > 0 ? `${inDraft} 份草稿待提交` : "尚未开始评审的作品"}
          className={pending > 0 ? "border-amber-200/50" : undefined}
        />
      </div>

      {/* Assignments List */}
      {assignments.length === 0 ? (
        <EmptyState
          title="暂无分配评审作品"
          description="您还没有被分配评审任何作品，请联系赛事主办方。"
        />
      ) : (
        <div className="space-y-4">
          {assignments.map((assignment) => {
            const statusInfo = getStatusInfo(assignment.judgingRecord);
            const work = assignment.work;
            const author = work.registration.user;
            const reviewHref = `/console/races/${slug}/judge/reviewing?workId=${work.id}`;

            return (
              <div
                key={assignment.id}
                className="rounded-xl border border-ary-line bg-white p-5 shadow-sm transition-shadow hover:shadow-md"
              >
                <div className="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
                  {/* Left: Work Info */}
                  <div className="min-w-0 flex-1">
                    <div className="flex items-start gap-3">
                      <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-ary-blue-100">
                        <FileText className="h-5 w-5 text-ary-blue-700" />
                      </div>
                      <div className="min-w-0">
                        <h3 className="truncate text-base font-semibold text-ary-blue-950">
                          {work.title}
                        </h3>
                        <p className="mt-0.5 text-sm text-ary-muted">
                          作者：{author.name || "未知"}
                          {(author.school || author.company) &&
                            ` · ${author.school || author.company}`}
                        </p>
                        <p className="mt-0.5 text-xs text-ary-muted">
                          提交时间：{formatDate(work.createdAt)}
                        </p>
                      </div>
                    </div>
                  </div>

                  {/* Right: Status + Action */}
                  <div className="flex shrink-0 items-center gap-4">
                    <span
                      className={`inline-flex items-center gap-1.5 rounded-full px-3 py-1 text-xs font-semibold ${statusInfo.bgColor} ${statusInfo.color}`}
                    >
                      <span
                        className={`h-1.5 w-1.5 rounded-full ${statusInfo.dotColor}`}
                      />
                      {statusInfo.label}
                    </span>
                    <ActionLink
                      href={reviewHref}
                      variant={
                        !assignment.judgingRecord ||
                        assignment.judgingRecord.status === "draft"
                          ? "primary"
                          : "secondary"
                      }
                    >
                      {!assignment.judgingRecord
                        ? "开始评审"
                        : assignment.judgingRecord.status === "draft"
                          ? "继续评审"
                          : "查看评审"}
                      <ExternalLink className="h-4 w-4" />
                    </ActionLink>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
