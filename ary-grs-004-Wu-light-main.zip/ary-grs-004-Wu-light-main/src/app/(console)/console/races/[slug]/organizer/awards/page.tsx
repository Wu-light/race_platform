import { OrganizerNav } from "@/components/layout/OrganizerNav";
import { prisma } from "@/lib/db";
import { auth } from "@/lib/auth";
import { redirect } from "next/navigation";
import { requireOrganizerOfRace } from "@/lib/permissions";
import { AwardsManager } from "./AwardsManager";

export default async function OrganizerAwardsPage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const session = await auth();
  if (!session?.user) redirect("/login");

  const race = await prisma.race.findUnique({ where: { slug } });
  if (!race) redirect("/console/races");
  try {
    await requireOrganizerOfRace(race.id);
  } catch {
    redirect("/console/access-denied");
  }

  // Parse award categories from race settings
  let awardCategories: string[] = [];
  try {
    const parsed = JSON.parse(race.awardSettings);
    awardCategories = Array.isArray(parsed) && parsed.length > 0 ? parsed : [];
  } catch {}

  // Fallback to default categories if none configured
  if (awardCategories.length === 0) {
    awardCategories = [
      "总成绩榜",
      "最佳作品",
      "最佳Agent Rider",
      "最佳纠偏",
      "最佳成本控制",
      "最佳复盘",
    ];
  }

  // Fetch all awards for this race
  const awards = await prisma.award.findMany({
    where: { raceId: race.id },
    include: {
      registration: {
        include: {
          user: { select: { name: true } },
        },
      },
      work: { select: { title: true } },
    },
    orderBy: [{ awardName: "asc" }, { rank: "asc" }],
  });

  // Fetch approved registrations
  const registrations = await prisma.registration.findMany({
    where: { raceId: race.id, status: "approved" },
    include: {
      user: { select: { name: true } },
      work: { select: { id: true, title: true } },
    },
    orderBy: { submittedAt: "asc" },
  });

  const awardsData = awards.map((a) => ({
    id: a.id,
    awardName: a.awardName,
    rank: a.rank,
    registrationId: a.registrationId,
    workId: a.workId,
    decisionReason: a.decisionReason,
    publishedAt: a.publishedAt?.toISOString() ?? null,
    userName: a.registration?.user?.name ?? "未知用户",
    workTitle: a.work?.title ?? null,
  }));

  const registrationsData = registrations.map((r) => ({
    id: r.id,
    userName: r.user?.name ?? "未知用户",
    workTitle: r.work?.title ?? null,
    workId: r.work?.id ?? null,
  }));

  return (
    <div className="mx-auto max-w-[1440px] px-6 py-8">
      <OrganizerNav slug={slug} current="awards" />
      <AwardsManager
        slug={slug}
        awardCategories={awardCategories}
        initialAwards={awardsData}
        registrations={registrationsData}
      />
    </div>
  );
}
