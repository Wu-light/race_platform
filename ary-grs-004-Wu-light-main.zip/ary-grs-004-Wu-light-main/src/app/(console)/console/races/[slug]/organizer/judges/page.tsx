import { OrganizerNav } from "@/components/layout/OrganizerNav";
import { prisma } from "@/lib/db";
import { auth } from "@/lib/auth";
import { redirect } from "next/navigation";
import { requireOrganizerOfRace } from "@/lib/permissions";
import { JudgesActions } from "./JudgesActions";
import { Users, BookOpen, Scale } from "lucide-react";

export default async function OrganizerJudgesPage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const session = await auth();
  if (!session?.user) redirect("/login");

  const race = await prisma.race.findUnique({ where: { slug } });
  if (!race) redirect("/console/races");
  try {
    await requireOrganizerOfRace(race.id);
  } catch {
    redirect("/console/access-denied");
  }

  // Get all submitted/locked works (assignable)
  const works = await prisma.work.findMany({
    where: {
      registration: { raceId: race.id },
      status: { in: ["submitted", "locked"] },
    },
    include: {
      registration: {
        include: {
          user: {
            select: { id: true, name: true },
          },
        },
      },
    },
    orderBy: { createdAt: "desc" },
  });

  // Get all users with judge role
  const allUsers = await prisma.user.findMany({
    select: { id: true, name: true, email: true, roles: true },
  });
  const judgeUsers = allUsers
    .filter((u) => {
      try {
        const roles: string[] = JSON.parse(u.roles);
        return roles.includes("judge");
      } catch {
        return false;
      }
    })
    .map((u) => ({ id: u.id, name: u.name, email: u.email }));

  // Get existing assignments
  const assignments = await prisma.judgeAssignment.findMany({
    where: { work: { registration: { raceId: race.id } } },
    include: {
      work: {
        select: { id: true, title: true, slug: true },
      },
      judge: {
        select: { id: true, name: true },
      },
      assignedBy: {
        select: { name: true },
      },
      judgingRecord: {
        select: { status: true, scoreResult: true, scoreRiding: true },
      },
    },
    orderBy: { assignedAt: "desc" },
  });

  const assignmentCount = assignments.length;

  return (
    <div className="mx-auto max-w-[1440px] px-6 py-8">
      <OrganizerNav slug={slug} current="judges" />

      <div className="mb-6">
        <h1 className="text-2xl font-bold text-slate-900">评委分配</h1>
        <p className="mt-1 text-sm text-ary-muted">
          为参赛作品分配评委
        </p>
      </div>

      {/* Summary */}
      <div className="mb-6 grid grid-cols-2 gap-4 sm:grid-cols-3">
        <div className="rounded-xl border border-ary-line bg-white p-4">
          <div className="flex items-center gap-3">
            <BookOpen className="h-5 w-5 text-ary-blue-700" />
            <div>
              <p className="text-xs text-ary-muted">可分配作品</p>
              <p className="text-xl font-bold text-slate-900">
                {works.length}
              </p>
            </div>
          </div>
        </div>
        <div className="rounded-xl border border-ary-line bg-white p-4">
          <div className="flex items-center gap-3">
            <Users className="h-5 w-5 text-green-600" />
            <div>
              <p className="text-xs text-ary-muted">评委人数</p>
              <p className="text-xl font-bold text-slate-900">
                {judgeUsers.length}
              </p>
            </div>
          </div>
        </div>
        <div className="rounded-xl border border-ary-line bg-white p-4">
          <div className="flex items-center gap-3">
            <Scale className="h-5 w-5 text-purple-600" />
            <div>
              <p className="text-xs text-ary-muted">已分配</p>
              <p className="text-xl font-bold text-slate-900">
                {assignmentCount}
              </p>
            </div>
          </div>
        </div>
      </div>

      <JudgesActions
        works={works.map((w) => ({
          id: w.id,
          title: w.title,
          slug: w.slug,
          authorName: w.registration.user.name ?? "未知",
        }))}
        judges={judgeUsers.map((j) => ({
          id: j.id,
          name: j.name ?? "未知评委",
          email: j.email ?? "",
        }))}
        assignments={assignments.map((a) => ({
          id: a.id,
          workTitle: a.work.title,
          workSlug: a.work.slug,
          judgeName: a.judge.name ?? "未知",
          judgeId: a.judge.id,
          assignedByName: a.assignedBy.name ?? "系统",
          assignedAt: a.assignedAt.toISOString(),
          judgingStatus: a.judgingRecord?.status ?? null,
          scoreResult: a.judgingRecord?.scoreResult ?? null,
          scoreRiding: a.judgingRecord?.scoreRiding ?? null,
        }))}
        slug={slug}
      />
    </div>
  );
}
