import { auth } from "@/lib/auth";
import { prisma } from "@/lib/db";
import { RiderNav } from "@/components/layout/RiderNav";
import { redirect } from "next/navigation";
import { formatDateTime } from "@/lib/utils";
import { MetricCard } from "@/components/ui/MetricCard";
import { EmptyState } from "@/components/ui/EmptyState";
import { ActionLink } from "@/components/ui/ActionLink";
import {
  Wifi,
  WifiOff,
  Activity,
  AlertTriangle,
  DollarSign,
  TrendingUp,
  Shield,
  Zap,
} from "lucide-react";

function ConnectionStatusBadge({ status }: { status: string }) {
  const styles: Record<string, string> = {
    not_configured: "border-slate-200 bg-slate-100 text-slate-600",
    connected: "border-blue-200 bg-blue-50 text-ary-blue-700",
    active: "border-emerald-200 bg-emerald-50 text-emerald-700",
    failed: "border-red-200 bg-red-50 text-red-700",
  };
  const labels: Record<string, string> = {
    not_configured: "未配置",
    connected: "已连接",
    active: "活动中",
    failed: "失败",
  };
  const icons: Record<string, React.ReactNode> = {
    not_configured: <WifiOff className="h-3.5 w-3.5" />,
    connected: <Wifi className="h-3.5 w-3.5" />,
    active: <Activity className="h-3.5 w-3.5" />,
    failed: <AlertTriangle className="h-3.5 w-3.5" />,
  };
  return (
    <span
      className={`inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-xs font-semibold ${
        styles[status] ?? styles.not_configured
      }`}
    >
      {icons[status] ?? null}
      {labels[status] ?? status}
    </span>
  );
}

function MetricsGrid({ metrics }: { metrics: Record<string, any> }) {
  const cards = [
    {
      label: "成本摘要",
      value: metrics.costSummary?.totalCost
        ? `$${Number(metrics.costSummary.totalCost).toFixed(2)}`
        : "--",
      hint: metrics.costSummary?.currency ?? "USD",
      icon: <DollarSign className="h-5 w-5" />,
    },
    {
      label: "进度摘要",
      value: metrics.progressSummary?.completion
        ? `${metrics.progressSummary.completion}%`
        : "--",
      hint: metrics.progressSummary?.status ?? "未知",
      icon: <TrendingUp className="h-5 w-5" />,
    },
    {
      label: "风险摘要",
      value: metrics.riskSummary?.level ?? "--",
      hint: metrics.riskSummary?.description ?? "无风险数据",
      icon: <Shield className="h-5 w-5" />,
    },
    {
      label: "技能摘要",
      value: metrics.skillSummary?.score
        ? `${metrics.skillSummary.score}/10`
        : "--",
      hint: metrics.skillSummary?.category ?? "综合",
      icon: <Zap className="h-5 w-5" />,
    },
  ];

  return (
    <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
      {cards.map((card) => (
        <MetricCard
          key={card.label}
          label={card.label}
          value={card.value}
          hint={card.hint}
        />
      ))}
    </div>
  );
}

export default async function RiderRidingPage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const session = await auth();
  if (!session?.user) redirect("/login");
  const userId = session.user.id!;

  const race = await prisma.race.findUnique({ where: { slug } });
  if (!race) {
    return (
      <div className="mx-auto max-w-[1440px] px-6 py-8">
        <RiderNav slug={slug} current="riding" />
        <p className="text-lg font-medium text-ary-muted">赛事不存在</p>
      </div>
    );
  }

  const registration = await prisma.registration.findUnique({
    where: {
      userId_raceId: { userId, raceId: race.id },
    },
  });

  if (!registration) {
    return (
      <div className="mx-auto max-w-[1440px] px-6 py-8">
        <RiderNav slug={slug} current="riding" />
        <EmptyState
          title="尚未报名"
          description="请先报名参赛以查看骑乘状态。"
        />
        <ActionLink
          href={`/console/races/${slug}/rider`}
          className="mt-4"
        >
          前往报名
        </ActionLink>
      </div>
    );
  }

  const raceProject = await prisma.raceProject.findUnique({
    where: { registrationId: registration.id },
    include: {
      caConnections: {
        include: {
          caSessions: {
            orderBy: { startedAt: "desc" },
            take: 20,
          },
          ridingMetrics: true,
        },
      },
    },
  });

  if (!raceProject) {
    return (
      <div className="mx-auto max-w-[1440px] px-6 py-8">
        <RiderNav slug={slug} current="riding" />
        <EmptyState
          title="赛事项目未就绪"
          description="请先完成报名审核以创建赛事项目。"
        />
        <ActionLink
          href={`/console/races/${slug}/rider`}
          className="mt-4"
        >
          查看报名状态
        </ActionLink>
      </div>
    );
  }

  const connections = raceProject.caConnections;
  const hasCaData = connections.length > 0;

  // Build evidence gap warnings
  const warnings: string[] = [];
  if (connections.length === 0) {
    warnings.push("尚未配置任何 CA 连接");
  }
  const noActiveConnection = connections.every(
    (c) => c.ingestionStatus === "not_configured" || c.ingestionStatus === "failed",
  );
  if (noActiveConnection && connections.length > 0) {
    warnings.push("没有活动的 CA 连接");
  }
  const noSessions = connections.every((c) => c.caSessions.length === 0);
  if (noSessions && connections.length > 0) {
    warnings.push("尚未产生任何 CA 会话数据");
  }

  // Get the first active connection's metrics for overview
  const metricsConn = connections.find(
    (c) => c.ridingMetrics && c.ridingMetrics.length > 0,
  );
  const firstMetrics = metricsConn?.ridingMetrics?.[0];

  return (
    <div className="mx-auto max-w-[1440px] px-6 py-8">
      <RiderNav slug={slug} current="riding" />

      <div className="mb-6 flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">骑乘状态</h1>
          <p className="mt-1 text-sm text-ary-muted">
            实时监控你的 Agent 骑乘表现
          </p>
        </div>
        {raceProject.aggregateIngestionStatus && (
          <ConnectionStatusBadge status={raceProject.aggregateIngestionStatus} />
        )}
      </div>

      {/* Evidence Gap Warnings */}
      {warnings.length > 0 && (
        <div className="mb-6 rounded-2xl border border-amber-200 bg-amber-50 p-4">
          <div className="flex items-center gap-2 text-amber-800">
            <AlertTriangle className="h-4 w-4" />
            <span className="text-sm font-semibold">注意事项</span>
          </div>
          <ul className="mt-2 space-y-1">
            {warnings.map((w, i) => (
              <li key={i} className="text-sm text-amber-700">
                {w}
              </li>
            ))}
          </ul>
          {connections.length === 0 && (
            <ActionLink
              href={`/console/races/${slug}/rider/ca-setup`}
              variant="secondary"
              className="mt-3"
            >
              前往 CA 配置
            </ActionLink>
          )}
        </div>
      )}

      {/* CA Connection Health */}
      <div className="mb-6">
        <h2 className="mb-3 text-lg font-bold text-slate-900">CA 连接状态</h2>
        {connections.length === 0 ? (
          <div className="rounded-2xl border border-dashed border-ary-line-strong bg-white/60 px-6 py-8 text-center">
            <p className="text-sm text-ary-muted">
              暂无 CA 连接。请先前往 CA 配置页面添加连接。
            </p>
          </div>
        ) : (
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {connections.map((conn) => {
              const health = (() => {
                try {
                  return JSON.parse(raceProject.connectionHealth);
                } catch {
                  return {};
                }
              })();
              return (
                <div
                  key={conn.id}
                  className="rounded-2xl border border-ary-line bg-white p-4"
                >
                  <div className="mb-2 flex items-center justify-between">
                    <span className="text-sm font-semibold text-slate-900">
                      {conn.caType === "claude_code"
                        ? "Claude Code"
                        : conn.caType === "codex"
                          ? "Codex"
                          : "其他"}
                    </span>
                    <ConnectionStatusBadge status={conn.ingestionStatus} />
                  </div>
                  {conn.connectorId && (
                    <p className="text-xs text-ary-muted">
                      ID: {conn.connectorId}
                    </p>
                  )}
                  {conn.externalProjectRef && (
                    <p className="text-xs text-ary-muted">
                      项目: {conn.externalProjectRef}
                    </p>
                  )}
                  {conn.handshakeAt && (
                    <p className="mt-1 text-xs text-ary-muted">
                      握手时间: {formatDateTime(conn.handshakeAt)}
                    </p>
                  )}
                  <p className="mt-1 text-xs text-ary-muted">
                    会话数: {conn.caSessions.length}
                  </p>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Metrics Cards */}
      <div className="mb-6">
        <h2 className="mb-3 text-lg font-bold text-slate-900">
          指标概览
        </h2>
        {!hasCaData ? (
          <div className="rounded-2xl border border-dashed border-ary-line-strong bg-white/60 px-6 py-8 text-center">
            <p className="text-sm text-ary-muted">
              暂无 CA 数据。配置并启用 CA 连接后将显示指标。
            </p>
          </div>
        ) : (
          <MetricsGrid
            metrics={{
              costSummary: firstMetrics?.costSummary
                ? JSON.parse(firstMetrics.costSummary as string)
                : {},
              progressSummary: firstMetrics?.progressSummary
                ? JSON.parse(firstMetrics.progressSummary as string)
                : {},
              riskSummary: firstMetrics?.riskSummary
                ? JSON.parse(firstMetrics.riskSummary as string)
                : {},
              skillSummary: firstMetrics?.skillSummary
                ? JSON.parse(firstMetrics.skillSummary as string)
                : {},
            }}
          />
        )}
      </div>

      {/* Recent CA Sessions */}
      <div>
        <h2 className="mb-3 text-lg font-bold text-slate-900">
          最近的 CA 会话
        </h2>
        {!hasCaData || connections.every((c) => c.caSessions.length === 0) ? (
          <div className="rounded-2xl border border-dashed border-ary-line-strong bg-white/60 px-6 py-8 text-center">
            <p className="text-sm text-ary-muted">暂无会话记录。</p>
          </div>
        ) : (
          <div className="overflow-hidden rounded-2xl border border-ary-line bg-white">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-ary-line bg-slate-50">
                  <th className="px-4 py-3 text-left font-semibold text-ary-muted">
                    开始时间
                  </th>
                  <th className="px-4 py-3 text-left font-semibold text-ary-muted">
                    消息数
                  </th>
                  <th className="px-4 py-3 text-left font-semibold text-ary-muted">
                    工具调用
                  </th>
                  <th className="px-4 py-3 text-left font-semibold text-ary-muted">
                    Token 成本
                  </th>
                  <th className="px-4 py-3 text-left font-semibold text-ary-muted">
                    连接
                  </th>
                </tr>
              </thead>
              <tbody>
                {connections.flatMap((conn) =>
                  conn.caSessions.map((session) => (
                    <tr
                      key={session.id}
                      className="border-b border-ary-line last:border-0 hover:bg-slate-50"
                    >
                      <td className="px-4 py-3 text-slate-900">
                        {formatDateTime(session.startedAt)}
                      </td>
                      <td className="px-4 py-3 text-slate-900">
                        {session.messageCount}
                      </td>
                      <td className="px-4 py-3 text-slate-900">
                        {session.toolCallCount}
                      </td>
                      <td className="px-4 py-3 text-slate-900">
                        ${session.tokenCost.toFixed(4)}
                      </td>
                      <td className="px-4 py-3 text-xs text-ary-muted">
                        {conn.caType === "claude_code"
                          ? "Claude Code"
                          : conn.caType === "codex"
                            ? "Codex"
                            : "其他"}
                      </td>
                    </tr>
                  )),
                )}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
