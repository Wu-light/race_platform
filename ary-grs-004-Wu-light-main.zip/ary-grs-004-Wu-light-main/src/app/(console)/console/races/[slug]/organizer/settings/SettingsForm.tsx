"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { updateRaceSettings, publishRace, archiveRace } from "../actions";
import {
  Save,
  Plus,
  Trash2,
  Send,
  Archive,
  AlertCircle,
  CheckCircle2,
} from "lucide-react";

const STATUS_OPTIONS = [
  { value: "draft", label: "草稿" },
  { value: "published", label: "即将开放" },
  { value: "registration", label: "报名中" },
  { value: "running", label: "进行中" },
  { value: "submitting", label: "提交中" },
  { value: "judging", label: "评审中" },
  { value: "completed", label: "已结束" },
  { value: "archived", label: "已归档" },
];

const VISIBILITY_OPTIONS = [
  { value: "public", label: "公开" },
  { value: "hidden", label: "隐藏" },
  { value: "internal", label: "内部" },
];

const SCHEDULE_FIELDS = [
  { key: "registrationStart", label: "报名开始" },
  { key: "registrationEnd", label: "报名结束" },
  { key: "raceStart", label: "比赛开始" },
  { key: "raceEnd", label: "比赛结束" },
  { key: "submissionDeadline", label: "提交截止" },
  { key: "judgingEnd", label: "评审结束" },
];

const SUBMISSION_FIELD_OPTIONS = [
  { value: "demoUrl", label: "演示链接" },
  { value: "githubUrl", label: "GitHub 链接" },
  { value: "videoUrl", label: "视频链接" },
  { value: "techDescription", label: "技术说明" },
];

interface InitialData {
  title: string;
  subtitle: string;
  description: string;
  challenge: string;
  rules: string;
  status: string;
  visibility: string;
  schedule: Record<string, string>;
  awardNames: string[];
  submissionFields: string[];
  submissionFormat: string;
  submissionDesc: string;
}

export function SettingsForm({
  slug,
  initialData,
}: {
  slug: string;
  initialData: InitialData;
}) {
  const router = useRouter();

  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState<{
    type: "success" | "error";
    text: string;
  } | null>(null);

  // Form fields
  const [title, setTitle] = useState(initialData.title);
  const [subtitle, setSubtitle] = useState(initialData.subtitle);
  const [description, setDescription] = useState(initialData.description);
  const [challenge, setChallenge] = useState(initialData.challenge);
  const [rules, setRules] = useState(initialData.rules);
  const [status, setStatus] = useState(initialData.status);
  const [visibility, setVisibility] = useState(initialData.visibility);
  const [schedule, setSchedule] = useState<Record<string, string>>(
    initialData.schedule,
  );
  const [awardNames, setAwardNames] = useState<string[]>(
    initialData.awardNames,
  );
  const [submissionFields, setSubmissionFields] = useState<string[]>(
    initialData.submissionFields,
  );
  const [submissionFormat, setSubmissionFormat] = useState(
    initialData.submissionFormat,
  );
  const [submissionDesc, setSubmissionDesc] = useState(
    initialData.submissionDesc,
  );

  const handleSave = async () => {
    setSaving(true);
    setMessage(null);
    try {
      await updateRaceSettings(slug, {
        title,
        subtitle,
        description,
        challenge,
        rules,
        status,
        visibility,
        schedule: JSON.stringify(schedule),
        awardSettings: JSON.stringify(awardNames),
        submissionRequirements: JSON.stringify({
          fields: submissionFields,
          format: submissionFormat,
          description: submissionDesc,
        }),
      });
      setMessage({ type: "success", text: "设置已保存" });
      router.refresh();
    } catch (err: any) {
      setMessage({ type: "error", text: err.message ?? "保存失败" });
    } finally {
      setSaving(false);
    }
  };

  const handlePublish = async () => {
    setSaving(true);
    try {
      await publishRace(slug);
      router.refresh();
    } catch (err: any) {
      setMessage({ type: "error", text: err.message ?? "发布失败" });
      setSaving(false);
    }
  };

  const handleArchive = async () => {
    setSaving(true);
    try {
      await archiveRace(slug);
      router.refresh();
    } catch (err: any) {
      setMessage({ type: "error", text: err.message ?? "归档失败" });
      setSaving(false);
    }
  };

  const addAwardName = () => {
    setAwardNames([...awardNames, ""]);
  };

  const updateAwardName = (index: number, value: string) => {
    const next = [...awardNames];
    next[index] = value;
    setAwardNames(next);
  };

  const removeAwardName = (index: number) => {
    setAwardNames(awardNames.filter((_, i) => i !== index));
  };

  const toggleSubmissionField = (field: string) => {
    if (submissionFields.includes(field)) {
      setSubmissionFields(submissionFields.filter((f) => f !== field));
    } else {
      setSubmissionFields([...submissionFields, field]);
    }
  };

  return (
    <div>
      <div className="mb-6 flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">赛事设置</h1>
          <p className="mt-1 text-sm text-ary-muted">
            管理赛事的基本信息、日程和配置
          </p>
        </div>
        <div className="flex gap-2">
          {status === "draft" && (
            <button
              onClick={handlePublish}
              disabled={saving}
              className="inline-flex items-center gap-1.5 rounded-lg bg-ary-blue-700 px-4 py-2 text-sm font-semibold text-white transition-colors hover:bg-ary-blue-800 disabled:opacity-50"
            >
              <Send className="h-4 w-4" />
              发布
            </button>
          )}
          {status !== "archived" && (
            <button
              onClick={handleArchive}
              disabled={saving}
              className="inline-flex items-center gap-1.5 rounded-lg border border-red-200 bg-white px-4 py-2 text-sm font-semibold text-red-600 transition-colors hover:bg-red-50 disabled:opacity-50"
            >
              <Archive className="h-4 w-4" />
              归档
            </button>
          )}
          <button
            onClick={handleSave}
            disabled={saving}
            className="inline-flex items-center gap-1.5 rounded-lg bg-ary-blue-700 px-4 py-2 text-sm font-semibold text-white transition-colors hover:bg-ary-blue-800 disabled:opacity-50"
          >
            <Save className="h-4 w-4" />
            {saving ? "保存中..." : "保存"}
          </button>
        </div>
      </div>

      {message && (
        <div
          className={`mb-6 flex items-center gap-2 rounded-lg border p-3 text-sm ${
            message.type === "success"
              ? "border-green-200 bg-green-50 text-green-700"
              : "border-red-200 bg-red-50 text-red-700"
          }`}
        >
          {message.type === "success" ? (
            <CheckCircle2 className="h-4 w-4" />
          ) : (
            <AlertCircle className="h-4 w-4" />
          )}
          {message.text}
        </div>
      )}

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
        {/* Main content - left column (spans 2 cols) */}
        <div className="space-y-6 lg:col-span-2">
          {/* Basic Info */}
          <div className="rounded-xl border border-ary-line bg-white p-6">
            <h2 className="mb-4 text-lg font-semibold text-slate-900">
              基本信息
            </h2>
            <div className="space-y-4">
              <div>
                <label className="mb-1 block text-sm font-medium text-slate-700">
                  赛事标题 <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  className="w-full rounded-lg border border-ary-line px-3 py-2 text-sm focus:border-ary-blue-500 focus:outline-none focus:ring-1 focus:ring-ary-blue-500"
                  placeholder="输入赛事标题"
                />
              </div>
              <div>
                <label className="mb-1 block text-sm font-medium text-slate-700">
                  副标题
                </label>
                <input
                  type="text"
                  value={subtitle}
                  onChange={(e) => setSubtitle(e.target.value)}
                  className="w-full rounded-lg border border-ary-line px-3 py-2 text-sm focus:border-ary-blue-500 focus:outline-none focus:ring-1 focus:ring-ary-blue-500"
                  placeholder="可选副标题"
                />
              </div>
              <div>
                <label className="mb-1 block text-sm font-medium text-slate-700">
                  描述 <span className="text-red-500">*</span>
                </label>
                <textarea
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  rows={4}
                  className="w-full rounded-lg border border-ary-line px-3 py-2 text-sm focus:border-ary-blue-500 focus:outline-none focus:ring-1 focus:ring-ary-blue-500"
                  placeholder="赛事描述（支持 Markdown）"
                />
              </div>
              <div>
                <label className="mb-1 block text-sm font-medium text-slate-700">
                  赛题说明 <span className="text-red-500">*</span>
                </label>
                <textarea
                  value={challenge}
                  onChange={(e) => setChallenge(e.target.value)}
                  rows={6}
                  className="w-full rounded-lg border border-ary-line px-3 py-2 text-sm font-mono focus:border-ary-blue-500 focus:outline-none focus:ring-1 focus:ring-ary-blue-500"
                  placeholder="赛题说明（支持 Markdown）"
                />
              </div>
              <div>
                <label className="mb-1 block text-sm font-medium text-slate-700">
                  参赛规则
                </label>
                <textarea
                  value={rules}
                  onChange={(e) => setRules(e.target.value)}
                  rows={4}
                  className="w-full rounded-lg border border-ary-line px-3 py-2 text-sm font-mono focus:border-ary-blue-500 focus:outline-none focus:ring-1 focus:ring-ary-blue-500"
                  placeholder="参赛规则（支持 Markdown）"
                />
              </div>
            </div>
          </div>

          {/* Schedule */}
          <div className="rounded-xl border border-ary-line bg-white p-6">
            <h2 className="mb-4 text-lg font-semibold text-slate-900">
              赛事日程
            </h2>
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
              {SCHEDULE_FIELDS.map((field) => (
                <div key={field.key}>
                  <label className="mb-1 block text-sm font-medium text-slate-700">
                    {field.label}
                  </label>
                  <input
                    type="datetime-local"
                    value={schedule[field.key] ?? ""}
                    onChange={(e) =>
                      setSchedule({
                        ...schedule,
                        [field.key]: e.target.value,
                      })
                    }
                    className="w-full rounded-lg border border-ary-line px-3 py-2 text-sm focus:border-ary-blue-500 focus:outline-none focus:ring-1 focus:ring-ary-blue-500"
                  />
                </div>
              ))}
            </div>
          </div>

          {/* Award Settings */}
          <div className="rounded-xl border border-ary-line bg-white p-6">
            <h2 className="mb-4 text-lg font-semibold text-slate-900">
              奖项设置
            </h2>
            <p className="mb-3 text-sm text-ary-muted">
              预设奖项名称列表。正式奖项分配在"奖项"页面进行。
            </p>
            <div className="space-y-2">
              {awardNames.map((name, index) => (
                <div key={index} className="flex items-center gap-2">
                  <input
                    type="text"
                    value={name}
                    onChange={(e) => updateAwardName(index, e.target.value)}
                    className="flex-1 rounded-lg border border-ary-line px-3 py-2 text-sm focus:border-ary-blue-500 focus:outline-none focus:ring-1 focus:ring-ary-blue-500"
                    placeholder={`奖项 ${index + 1}`}
                  />
                  <button
                    onClick={() => removeAwardName(index)}
                    className="rounded-lg p-2 text-red-500 hover:bg-red-50"
                  >
                    <Trash2 className="h-4 w-4" />
                  </button>
                </div>
              ))}
            </div>
            <button
              onClick={addAwardName}
              className="mt-3 inline-flex items-center gap-1.5 text-sm font-medium text-ary-blue-700 hover:text-ary-blue-800"
            >
              <Plus className="h-4 w-4" />
              添加奖项
            </button>
          </div>

          {/* Submission Requirements */}
          <div className="rounded-xl border border-ary-line bg-white p-6">
            <h2 className="mb-4 text-lg font-semibold text-slate-900">
              提交要求
            </h2>
            <div className="space-y-4">
              <div>
                <label className="mb-2 block text-sm font-medium text-slate-700">
                  需要提交的信息
                </label>
                <div className="flex flex-wrap gap-3">
                  {SUBMISSION_FIELD_OPTIONS.map((opt) => (
                    <label
                      key={opt.value}
                      className="flex items-center gap-2 rounded-lg border border-ary-line px-3 py-2 text-sm cursor-pointer hover:bg-ary-surface"
                    >
                      <input
                        type="checkbox"
                        checked={submissionFields.includes(opt.value)}
                        onChange={() => toggleSubmissionField(opt.value)}
                        className="h-4 w-4 rounded border-ary-line text-ary-blue-700 focus:ring-ary-blue-500"
                      />
                      {opt.label}
                    </label>
                  ))}
                </div>
              </div>
              <div>
                <label className="mb-1 block text-sm font-medium text-slate-700">
                  提交格式说明
                </label>
                <input
                  type="text"
                  value={submissionFormat}
                  onChange={(e) => setSubmissionFormat(e.target.value)}
                  className="w-full rounded-lg border border-ary-line px-3 py-2 text-sm focus:border-ary-blue-500 focus:outline-none focus:ring-1 focus:ring-ary-blue-500"
                  placeholder="如：Markdown, PDF, 等"
                />
              </div>
              <div>
                <label className="mb-1 block text-sm font-medium text-slate-700">
                  提交说明
                </label>
                <textarea
                  value={submissionDesc}
                  onChange={(e) => setSubmissionDesc(e.target.value)}
                  rows={3}
                  className="w-full rounded-lg border border-ary-line px-3 py-2 text-sm focus:border-ary-blue-500 focus:outline-none focus:ring-1 focus:ring-ary-blue-500"
                  placeholder="提交说明"
                />
              </div>
            </div>
          </div>
        </div>

        {/* Right sidebar */}
        <div className="space-y-6">
          {/* Status */}
          <div className="rounded-xl border border-ary-line bg-white p-6">
            <h2 className="mb-4 text-lg font-semibold text-slate-900">
              状态与可见性
            </h2>
            <div className="space-y-4">
              <div>
                <label className="mb-1 block text-sm font-medium text-slate-700">
                  赛事状态
                </label>
                <select
                  value={status}
                  onChange={(e) => setStatus(e.target.value)}
                  className="w-full rounded-lg border border-ary-line px-3 py-2 text-sm focus:border-ary-blue-500 focus:outline-none focus:ring-1 focus:ring-ary-blue-500"
                >
                  {STATUS_OPTIONS.map((opt) => (
                    <option key={opt.value} value={opt.value}>
                      {opt.label}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="mb-1 block text-sm font-medium text-slate-700">
                  可见性
                </label>
                <select
                  value={visibility}
                  onChange={(e) => setVisibility(e.target.value)}
                  className="w-full rounded-lg border border-ary-line px-3 py-2 text-sm focus:border-ary-blue-500 focus:outline-none focus:ring-1 focus:ring-ary-blue-500"
                >
                  {VISIBILITY_OPTIONS.map((opt) => (
                    <option key={opt.value} value={opt.value}>
                      {opt.label}
                    </option>
                  ))}
                </select>
              </div>
            </div>
          </div>

          {/* Quick Info */}
          <div className="rounded-xl border border-ary-line bg-white p-6">
            <h2 className="mb-3 text-lg font-semibold text-slate-900">
              快捷信息
            </h2>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between">
                <span className="text-ary-muted">Slug</span>
                <span className="font-mono text-slate-800">{slug}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-ary-muted">当前状态</span>
                <span className="font-medium">
                  {STATUS_OPTIONS.find((o) => o.value === status)?.label ??
                    status}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-ary-muted">奖项数</span>
                <span className="font-medium">{awardNames.length}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
