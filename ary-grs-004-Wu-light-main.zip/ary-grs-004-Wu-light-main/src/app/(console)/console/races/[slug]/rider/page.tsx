import { auth } from "@/lib/auth";
import { prisma } from "@/lib/db";
import { RiderNav } from "@/components/layout/RiderNav";
import { redirect } from "next/navigation";
import { formatDate, formatDateTime } from "@/lib/utils";
import { raceStatusLabels } from "@/lib/race-utils";
import { ArrowUpRight, CheckCircle, XCircle, Clock, CalendarDays } from "lucide-react";
import type { RaceStatus } from "@/types";
import Link from "next/link";
import { RegisterButton } from "./RegisterButton";

function StatusBadge({ status }: { status: string }) {
  const styles: Record<string, string> = {
    submitted: "border-amber-200 bg-amber-50 text-amber-700",
    approved: "border-emerald-200 bg-emerald-50 text-emerald-700",
    rejected: "border-red-200 bg-red-50 text-red-700",
    withdrawn: "border-slate-200 bg-slate-100 text-slate-600",
  };
  const labels: Record<string, string> = {
    submitted: "已提交",
    approved: "已通过",
    rejected: "已拒绝",
    withdrawn: "已撤回",
  };
  return (
    <span
      className={`inline-flex items-center gap-1.5 rounded-full border px-2.5 py-1 text-xs font-semibold ${
        styles[status] ?? "border-slate-200 bg-slate-100 text-slate-600"
      }`}
    >
      {labels[status] ?? status}
    </span>
  );
}

function Timeline({ schedule }: { schedule: Record<string, string> }) {
  const now = new Date();
  const events = [
    { key: "registrationStart", label: "报名开始" },
    { key: "registrationEnd", label: "报名截止" },
    { key: "raceStart", label: "比赛开始" },
    { key: "raceEnd", label: "比赛结束" },
    { key: "submissionDeadline", label: "提交截止" },
    { key: "judgingEnd", label: "评审结束" },
  ];

  return (
    <div className="space-y-3">
      {events.map((event) => {
        const dateStr = schedule[event.key];
        if (!dateStr) return null;
        const date = new Date(dateStr);
        const isPast = date < now;
        return (
          <div key={event.key} className="flex items-center gap-3">
            <div
              className={`h-2 w-2 rounded-full ${
                isPast ? "bg-ary-blue-500" : "bg-slate-300"
              }`}
            />
            <div className="flex-1">
              <p className="text-sm font-medium text-slate-900">{event.label}</p>
              <p className="text-xs text-ary-muted">{formatDateTime(date)}</p>
            </div>
            {isPast && (
              <span className="text-xs font-medium text-emerald-600">已完成</span>
            )}
          </div>
        );
      })}
    </div>
  );
}

export default async function RiderRegistrationPage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const session = await auth();
  if (!session?.user) redirect("/login");
  const userId = session.user.id!;

  const race = await prisma.race.findUnique({ where: { slug } });
  if (!race) {
    return (
      <div className="mx-auto max-w-[1440px] px-6 py-8">
        <RiderNav slug={slug} current="registration" />
        <div className="rounded-2xl border border-ary-line bg-white p-12 text-center">
          <p className="text-lg font-medium text-ary-muted">赛事不存在</p>
        </div>
      </div>
    );
  }

  const registration = await prisma.registration.findUnique({
    where: {
      userId_raceId: { userId, raceId: race.id },
    },
    include: {
      raceProject: true,
    },
  });

  const schedule = (() => {
    try {
      return JSON.parse(race.schedule);
    } catch {
      return {};
    }
  })();

  return (
    <div className="mx-auto max-w-[1440px] px-6 py-8">
      <RiderNav slug={slug} current="registration" />

      {/* Race Header */}
      <div className="mb-6 overflow-hidden rounded-2xl border border-ary-line bg-white">
        <div className="border-b border-ary-line bg-gradient-to-br from-ary-blue-800 to-ary-blue-500 px-6 py-8 text-white">
          <div className="mb-2 flex items-center gap-2">
            <span className="inline-flex items-center gap-1.5 rounded-full border border-white/20 bg-white/10 px-2.5 py-1 text-xs font-semibold text-white">
              {raceStatusLabels[race.status as RaceStatus] ?? race.status}
            </span>
          </div>
          <h1 className="text-3xl font-black tracking-tight">{race.title}</h1>
          {race.subtitle && (
            <p className="mt-2 text-base text-white/80">{race.subtitle}</p>
          )}
        </div>
        <div className="px-6 py-5">
          <h3 className="mb-2 text-sm font-bold uppercase tracking-wider text-ary-muted">
            赛事描述
          </h3>
          <p className="text-sm leading-6 text-slate-700">{race.description}</p>
          <h3 className="mb-2 mt-4 text-sm font-bold uppercase tracking-wider text-ary-muted">
            赛题说明
          </h3>
          <p className="text-sm leading-6 text-slate-700">{race.challenge}</p>
        </div>
      </div>

      {/* Registration Section */}
      {!registration ? (
        <div className="rounded-2xl border border-ary-line bg-white p-6">
          <h2 className="mb-4 text-lg font-bold text-slate-900">报名参赛</h2>
          <p className="mb-4 text-sm text-ary-muted">
            点击下方按钮报名参赛。报名提交后，需要等待主办方审核。
          </p>
          <div className="flex items-center gap-3">
            <RegisterButton raceId={race.id} />
            {(typeof schedule.registrationEnd === "string" ||
              typeof schedule.registrationEnd === "number") && (
              <span className="text-xs text-ary-muted">
                报名截止: {formatDateTime(new Date(schedule.registrationEnd))}
              </span>
            )}
          </div>
        </div>
      ) : (
        <div className="grid gap-6 lg:grid-cols-3">
          {/* Registration Status */}
          <div className="lg:col-span-2 space-y-6">
            <div className="rounded-2xl border border-ary-line bg-white p-6">
              <div className="flex items-center justify-between">
                <h2 className="text-lg font-bold text-slate-900">报名状态</h2>
                <StatusBadge status={registration.status} />
              </div>
              <div className="mt-4 space-y-3">
                <div className="flex items-center gap-2 text-sm">
                  <CalendarDays className="h-4 w-4 text-ary-muted" />
                  <span className="text-ary-muted">提交时间:</span>
                  <span className="font-medium text-slate-900">
                    {formatDateTime(registration.submittedAt)}
                  </span>
                </div>
                {registration.approvedAt && (
                  <div className="flex items-center gap-2 text-sm">
                    <CheckCircle className="h-4 w-4 text-emerald-500" />
                    <span className="text-ary-muted">审核通过时间:</span>
                    <span className="font-medium text-slate-900">
                      {formatDateTime(registration.approvedAt)}
                    </span>
                  </div>
                )}
              </div>
            </div>

            {/* Approved: Show navigation */}
            {registration.status === "approved" && (
              <>
                <div className="rounded-2xl border border-ary-line bg-white p-6">
                  <h2 className="mb-4 text-lg font-bold text-slate-900">
                    赛事项目
                  </h2>
                  <div className="grid gap-3 sm:grid-cols-2">
                    <Link
                      href={`/console/races/${slug}/rider/ca-setup`}
                      className="flex items-center gap-3 rounded-xl border border-ary-line bg-ary-surface p-4 transition-colors hover:border-ary-blue-500"
                    >
                      <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-ary-blue-100 text-ary-blue-700">
                        <Clock className="h-5 w-5" />
                      </div>
                      <div>
                        <p className="text-sm font-semibold text-ary-blue-900">
                          CA 配置
                        </p>
                        <p className="text-xs text-ary-muted">
                          配置你的 Agent 连接
                        </p>
                      </div>
                      <ArrowUpRight className="ml-auto h-4 w-4 text-ary-muted" />
                    </Link>
                    <Link
                      href={`/console/races/${slug}/rider/submission`}
                      className="flex items-center gap-3 rounded-xl border border-ary-line bg-ary-surface p-4 transition-colors hover:border-ary-blue-500"
                    >
                      <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-ary-blue-100 text-ary-blue-700">
                        <CheckCircle className="h-5 w-5" />
                      </div>
                      <div>
                        <p className="text-sm font-semibold text-ary-blue-900">
                          作品提交
                        </p>
                        <p className="text-xs text-ary-muted">
                          提交你的参赛作品
                        </p>
                      </div>
                      <ArrowUpRight className="ml-auto h-4 w-4 text-ary-muted" />
                    </Link>
                  </div>
                </div>
              </>
            )}

            {/* Rejected: Show reason */}
            {registration.status === "rejected" && (
              <div className="rounded-2xl border border-red-200 bg-red-50 p-6">
                <div className="flex items-center gap-2">
                  <XCircle className="h-5 w-5 text-red-500" />
                  <h2 className="text-lg font-bold text-red-900">报名未通过</h2>
                </div>
                <p className="mt-2 text-sm text-red-700">
                  你的报名申请未能通过审核。请联系赛事主办方了解更多信息。
                </p>
              </div>
            )}

            {/* Submitted: Waiting */}
            {registration.status === "submitted" && (
              <div className="rounded-2xl border border-amber-200 bg-amber-50 p-6">
                <div className="flex items-center gap-2">
                  <Clock className="h-5 w-5 text-amber-500" />
                  <h2 className="text-lg font-bold text-amber-900">
                    等待审核
                  </h2>
                </div>
                <p className="mt-2 text-sm text-amber-700">
                  你的报名已提交，请耐心等待主办方审核。
                </p>
              </div>
            )}
          </div>

          {/* Timeline Sidebar */}
          <div className="rounded-2xl border border-ary-line bg-white p-6">
            <h3 className="mb-4 text-sm font-bold uppercase tracking-wider text-ary-muted">
              赛事时间线
            </h3>
            <Timeline schedule={schedule} />
          </div>
        </div>
      )}

      {/* Show timeline even when not registered */}
      {!registration && (
        <div className="mt-6 rounded-2xl border border-ary-line bg-white p-6">
          <h3 className="mb-4 text-sm font-bold uppercase tracking-wider text-ary-muted">
            赛事时间线
          </h3>
          <Timeline schedule={schedule} />
        </div>
      )}
    </div>
  );
}
