import { OrganizerNav } from "@/components/layout/OrganizerNav";
import { prisma } from "@/lib/db";
import { auth } from "@/lib/auth";
import { redirect } from "next/navigation";
import { requireOrganizerOfRace } from "@/lib/permissions";
import { raceStatusLabels } from "@/lib/race-utils";
import Link from "next/link";
import {
  Users,
  FileText,
  Trophy,
  Activity,
  Eye,
  Clock,
  CheckCircle,
  XCircle,
  AlertCircle,
  ArrowRight,
} from "lucide-react";

function StatusBadge({ status }: { status: string }) {
  const colorMap: Record<string, string> = {
    draft: "bg-gray-100 text-gray-700",
    published: "bg-blue-100 text-blue-700",
    registration: "bg-yellow-100 text-yellow-700",
    running: "bg-green-100 text-green-700",
    submitting: "bg-purple-100 text-purple-700",
    judging: "bg-orange-100 text-orange-700",
    completed: "bg-teal-100 text-teal-700",
    archived: "bg-slate-100 text-slate-600",
  };
  return (
    <span
      className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-semibold ${
        colorMap[status] ?? "bg-gray-100 text-gray-700"
      }`}
    >
      {raceStatusLabels[status as keyof typeof raceStatusLabels] ?? status}
    </span>
  );
}

function VisibilityBadge({ visibility }: { visibility: string }) {
  const config: Record<string, { label: string; classes: string }> = {
    public: { label: "公开", classes: "bg-green-100 text-green-700" },
    hidden: { label: "隐藏", classes: "bg-gray-100 text-gray-600" },
    internal: { label: "内部", classes: "bg-yellow-100 text-yellow-700" },
  };
  const c = config[visibility] ?? { label: visibility, classes: "bg-gray-100 text-gray-600" };
  return (
    <span
      className={`inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-semibold ${c.classes}`}
    >
      {c.label}
    </span>
  );
}

function StatCard({
  icon: Icon,
  label,
  value,
  sub,
  href,
}: {
  icon: React.ElementType;
  label: string;
  value: string | number;
  sub?: string;
  href?: string;
}) {
  const inner = (
    <div className="flex items-start gap-4">
      <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-ary-blue-100">
        <Icon className="h-6 w-6 text-ary-blue-700" />
      </div>
      <div>
        <p className="text-sm text-ary-muted">{label}</p>
        <p className="text-2xl font-bold text-slate-900">{value}</p>
        {sub && <p className="mt-0.5 text-xs text-ary-muted">{sub}</p>}
      </div>
    </div>
  );

  if (href) {
    return (
      <Link
        href={href}
        className="block rounded-xl border border-ary-line bg-white p-5 transition-shadow hover:shadow-ary"
      >
        {inner}
      </Link>
    );
  }
  return <div className="rounded-xl border border-ary-line bg-white p-5">{inner}</div>;
}

export default async function OrganizerOverviewPage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const session = await auth();
  if (!session?.user) redirect("/login");

  const race = await prisma.race.findUnique({
    where: { slug },
    include: {
      organizer: { select: { name: true, avatar: true } },
      announcements: { orderBy: { publishedAt: "desc" }, take: 5 },
      _count: {
        select: {
          registrations: true,
        },
      },
    },
  });

  if (!race) redirect("/console/races");
  try {
    await requireOrganizerOfRace(race.id);
  } catch {
    redirect("/console/access-denied");
  }

  // Count registrations by status
  const regCounts = await prisma.registration.groupBy({
    by: ["status"],
    where: { raceId: race.id },
    _count: true,
  });
  const regMap: Record<string, number> = {};
  regCounts.forEach((r) => {
    regMap[r.status] = r._count;
  });
  const totalRegs = race._count.registrations;
  const approvedRegs = regMap["approved"] ?? 0;
  const submittedRegs = regMap["submitted"] ?? 0;
  const rejectedRegs = regMap["rejected"] ?? 0;

  // Count works
  const worksCount = await prisma.work.count({
    where: { registration: { raceId: race.id } },
  });
  const submittedWorksCount = await prisma.work.count({
    where: { registration: { raceId: race.id }, status: "submitted" },
  });
  const lockedWorksCount = await prisma.work.count({
    where: { registration: { raceId: race.id }, status: "locked" },
  });

  // Count judge assignments
  const assignmentCount = await prisma.judgeAssignment.count({
    where: { work: { registration: { raceId: race.id } } },
  });
  const judgedCount = await prisma.judgingRecord.count({
    where: {
      status: "submitted",
      assignment: { work: { registration: { raceId: race.id } } },
    },
  });

  // Count reports
  const reportCount = await prisma.report.count({
    where: { raceId: race.id },
  });

  // Parse schedule
  let schedule: Record<string, string> = {};
  try {
    schedule = JSON.parse(race.schedule);
  } catch {
    // ignore
  }

  const quickLinks = [
    { label: "报名管理", href: `/console/races/${slug}/organizer/registrations`, count: submittedRegs, desc: "待审核" },
    { label: "作品管理", href: `/console/races/${slug}/organizer/works`, count: submittedWorksCount, desc: "已提交" },
    { label: "评审进度", href: `/console/races/${slug}/organizer/judging`, count: assignmentCount > 0 ? `${judgedCount}/${assignmentCount}` : "0", desc: "已完成/总分配" },
    { label: "奖项管理", href: `/console/races/${slug}/organizer/awards`, count: "-", desc: "设置奖项" },
  ];

  return (
    <div className="mx-auto max-w-[1440px] px-6 py-8">
      <OrganizerNav slug={slug} current="overview" />

      {/* Header */}
      <div className="mb-8">
        <div className="flex items-center gap-3">
          <h1 className="text-2xl font-bold text-slate-900">{race.title}</h1>
          <StatusBadge status={race.status} />
          <VisibilityBadge visibility={race.visibility} />
        </div>
        {race.subtitle && (
          <p className="mt-1 text-sm text-ary-muted">{race.subtitle}</p>
        )}
        <p className="mt-1 text-xs text-ary-muted">
          主办方: {race.organizer.name ?? "未知"} | 创建于{" "}
          {race.createdAt.toLocaleDateString("zh-CN")}
        </p>
      </div>

      {/* Key Metrics */}
      <div className="mb-8 grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard
          icon={Users}
          label="总报名"
          value={totalRegs}
          sub={`已批准 ${approvedRegs} / 待审核 ${submittedRegs} / 已拒绝 ${rejectedRegs}`}
          href={`/console/races/${slug}/organizer/registrations`}
        />
        <StatCard
          icon={FileText}
          label="作品"
          value={worksCount}
          sub={`已提交 ${submittedWorksCount} / 已锁定 ${lockedWorksCount}`}
          href={`/console/races/${slug}/organizer/works`}
        />
        <StatCard
          icon={Trophy}
          label="评审"
          value={`${judgedCount}/${assignmentCount}`}
          sub="已完成/总分配"
          href={`/console/races/${slug}/organizer/judging`}
        />
        <StatCard
          icon={Activity}
          label="报告"
          value={reportCount}
          href={`/console/races/${slug}/organizer/reports`}
        />
      </div>

      {/* Schedule & Quick Links */}
      <div className="mb-8 grid grid-cols-1 gap-6 lg:grid-cols-2">
        {/* Schedule */}
        <div className="rounded-xl border border-ary-line bg-white p-5">
          <h2 className="mb-3 flex items-center gap-2 text-base font-semibold text-slate-900">
            <Clock className="h-4 w-4 text-ary-blue-700" />
            赛事日程
          </h2>
          {Object.keys(schedule).length > 0 ? (
            <div className="space-y-2">
              {Object.entries(schedule).map(([key, val]) => {
                if (!val) return null;
                const labelMap: Record<string, string> = {
                  registrationStart: "报名开始",
                  registrationEnd: "报名结束",
                  raceStart: "比赛开始",
                  raceEnd: "比赛结束",
                  submissionDeadline: "提交截止",
                  judgingEnd: "评审结束",
                };
                return (
                  <div key={key} className="flex justify-between text-sm">
                    <span className="text-ary-muted">
                      {labelMap[key] ?? key}
                    </span>
                    <span className="font-medium text-slate-800">
                      {new Date(val).toLocaleDateString("zh-CN", {
                        year: "numeric",
                        month: "long",
                        day: "numeric",
                        hour: "2-digit",
                        minute: "2-digit",
                      })}
                    </span>
                  </div>
                );
              })}
            </div>
          ) : (
            <p className="text-sm text-ary-muted">尚未设置日程</p>
          )}
          <Link
            href={`/console/races/${slug}/organizer/settings`}
            className="mt-3 inline-flex items-center gap-1 text-sm font-medium text-ary-blue-700 hover:text-ary-blue-800"
          >
            编辑日程 <ArrowRight className="h-3.5 w-3.5" />
          </Link>
        </div>

        {/* Quick Links */}
        <div className="rounded-xl border border-ary-line bg-white p-5">
          <h2 className="mb-3 flex items-center gap-2 text-base font-semibold text-slate-900">
            <ArrowRight className="h-4 w-4 text-ary-blue-700" />
            快捷操作
          </h2>
          <div className="grid grid-cols-2 gap-3">
            {quickLinks.map((link) => (
              <Link
                key={link.href}
                href={link.href}
                className="rounded-lg border border-ary-line bg-ary-surface p-3 transition-colors hover:bg-ary-blue-100"
              >
                <p className="text-2xl font-bold text-ary-blue-800">
                  {link.count}
                </p>
                <p className="text-sm font-medium text-slate-800">
                  {link.label}
                </p>
                <p className="text-xs text-ary-muted">{link.desc}</p>
              </Link>
            ))}
          </div>
        </div>
      </div>

      {/* Announcements */}
      <div className="rounded-xl border border-ary-line bg-white p-5">
        <div className="mb-3 flex items-center justify-between">
          <h2 className="flex items-center gap-2 text-base font-semibold text-slate-900">
            <Activity className="h-4 w-4 text-ary-blue-700" />
            最近公告
          </h2>
          <Link
            href={`/console/races/${slug}/organizer/settings`}
            className="text-xs font-medium text-ary-blue-700 hover:text-ary-blue-800"
          >
            查看全部
          </Link>
        </div>
        {race.announcements.length > 0 ? (
          <div className="divide-y divide-ary-line">
            {race.announcements.map((a) => (
              <div key={a.id} className="py-3">
                <div className="flex items-center justify-between">
                  <p className="text-sm font-medium text-slate-900">
                    {a.title}
                  </p>
                  <span className="text-xs text-ary-muted">
                    {a.publishedAt.toLocaleDateString("zh-CN")}
                  </span>
                </div>
                <p className="mt-1 line-clamp-2 text-xs text-ary-muted">
                  {a.body.slice(0, 200)}
                </p>
              </div>
            ))}
          </div>
        ) : (
          <div className="flex flex-col items-center py-8 text-center">
            <AlertCircle className="mb-2 h-8 w-8 text-ary-muted" />
            <p className="text-sm text-ary-muted">暂无公告</p>
            <p className="mt-1 text-xs text-ary-muted">
              赛事公告将在后续版本中支持
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
