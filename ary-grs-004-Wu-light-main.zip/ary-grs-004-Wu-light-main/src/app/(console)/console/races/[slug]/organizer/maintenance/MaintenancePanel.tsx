"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { publishRace, archiveRace, updateRaceSettings } from "../actions";
import {
  Settings2,
  Archive,
  Send,
  RefreshCw,
  AlertTriangle,
  CheckCircle2,
  AlertCircle,
  BarChart3,
} from "lucide-react";

const STATUS_OPTIONS = [
  { value: "draft", label: "草稿" },
  { value: "published", label: "即将开放" },
  { value: "registration", label: "报名中" },
  { value: "running", label: "进行中" },
  { value: "submitting", label: "提交中" },
  { value: "judging", label: "评审中" },
  { value: "completed", label: "已结束" },
  { value: "archived", label: "已归档" },
];

export function MaintenancePanel({
  slug,
  currentStatus,
  raceId,
}: {
  slug: string;
  currentStatus: string;
  raceId: string;
}) {
  const router = useRouter();

  const [newStatus, setNewStatus] = useState(currentStatus);
  const [changing, setChanging] = useState(false);
  const [archiving, setArchiving] = useState(false);
  const [rebuilding, setRebuilding] = useState(false);
  const [message, setMessage] = useState<{
    type: "success" | "error";
    text: string;
  } | null>(null);

  const currentLabel =
    STATUS_OPTIONS.find((o) => o.value === currentStatus)?.label ??
    currentStatus;

  const handleChangeStatus = async () => {
    setChanging(true);
    setMessage(null);
    try {
      await updateRaceSettings(slug, {
        title: "",
        description: "",
        challenge: "",
        rules: "",
        status: newStatus,
        visibility: "public",
        schedule: "{}",
        awardSettings: "[]",
        submissionRequirements: "{}",
      });
      setMessage({
        type: "success",
        text: `状态已更新为 ${STATUS_OPTIONS.find((o) => o.value === newStatus)?.label}`,
      });
      router.refresh();
    } catch (err: any) {
      setMessage({ type: "error", text: err.message ?? "状态更新失败" });
    } finally {
      setChanging(false);
    }
  };

  const handleArchive = async () => {
    setArchiving(true);
    setMessage(null);
    try {
      await archiveRace(slug);
      setMessage({ type: "success", text: "赛事已归档" });
      router.refresh();
    } catch (err: any) {
      setMessage({ type: "error", text: err.message ?? "归档失败" });
      setArchiving(false);
    }
  };

  const handlePublish = async () => {
    setChanging(true);
    setMessage(null);
    try {
      await publishRace(slug);
      setNewStatus("published");
      setMessage({ type: "success", text: "赛事已发布" });
      router.refresh();
    } catch (err: any) {
      setMessage({ type: "error", text: err.message ?? "发布失败" });
    } finally {
      setChanging(false);
    }
  };

  return (
    <div>
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-slate-900">维护</h1>
        <p className="mt-1 text-sm text-ary-muted">
          赛事状态管理和维护操作（完整实现见 Baton 5）
        </p>
      </div>

      {message && (
        <div
          className={`mb-6 flex items-center gap-2 rounded-lg border p-3 text-sm ${
            message.type === "success"
              ? "border-green-200 bg-green-50 text-green-700"
              : "border-red-200 bg-red-50 text-red-700"
          }`}
        >
          {message.type === "success" ? (
            <CheckCircle2 className="h-4 w-4" />
          ) : (
            <AlertCircle className="h-4 w-4" />
          )}
          {message.text}
        </div>
      )}

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        {/* Status Management */}
        <div className="rounded-xl border border-ary-line bg-white p-6">
          <h2 className="mb-4 flex items-center gap-2 text-lg font-semibold text-slate-900">
            <Settings2 className="h-5 w-5 text-ary-blue-700" />
            状态管理
          </h2>

          <div className="mb-4 rounded-lg bg-ary-surface p-4">
            <p className="text-sm text-ary-muted">当前状态</p>
            <p className="mt-1 text-lg font-bold text-ary-blue-800">
              {currentLabel}
            </p>
          </div>

          <div className="space-y-4">
            <div>
              <label className="mb-1 block text-sm font-medium text-slate-700">
                切换到新状态
              </label>
              <select
                value={newStatus}
                onChange={(e) => setNewStatus(e.target.value)}
                className="w-full rounded-lg border border-ary-line px-3 py-2 text-sm focus:border-ary-blue-500 focus:outline-none focus:ring-1 focus:ring-ary-blue-500"
              >
                {STATUS_OPTIONS.map((opt) => (
                  <option key={opt.value} value={opt.value}>
                    {opt.label}
                  </option>
                ))}
              </select>
            </div>

            <div className="flex gap-3">
              <button
                onClick={handleChangeStatus}
                disabled={changing || newStatus === currentStatus}
                className="inline-flex items-center gap-1.5 rounded-lg bg-ary-blue-700 px-4 py-2 text-sm font-semibold text-white transition-colors hover:bg-ary-blue-800 disabled:opacity-50"
              >
                <RefreshCw className="h-4 w-4" />
                {changing ? "更新中..." : "更新状态"}
              </button>

              {currentStatus === "draft" && (
                <button
                  onClick={handlePublish}
                  disabled={changing}
                  className="inline-flex items-center gap-1.5 rounded-lg bg-green-600 px-4 py-2 text-sm font-semibold text-white transition-colors hover:bg-green-700 disabled:opacity-50"
                >
                  <Send className="h-4 w-4" />
                  发布赛事
                </button>
              )}
            </div>
          </div>
        </div>

        {/* Projection Management */}
        <div className="rounded-xl border border-ary-line bg-white p-6">
          <h2 className="mb-4 flex items-center gap-2 text-lg font-semibold text-slate-900">
            <BarChart3 className="h-5 w-5 text-ary-blue-700" />
            Projection 管理
          </h2>

          <p className="mb-4 text-sm text-ary-muted">
            重建赛事 Projection（进度/榜单/成本/风险/大屏 feed）。
            Live Hall 和大屏展示依赖 Projection 数据。
          </p>

          <button
            onClick={async () => {
              setRebuilding(true);
              setMessage(null);
              try {
                const res = await fetch(
                  "/api/internal/projections/rebuild",
                  {
                    method: "POST",
                    headers: { "Content-Type": "application/json" },
                    body: JSON.stringify({ raceId }),
                  },
                );
                const data = await res.json();
                if (res.ok) {
                  const failed =
                    data.failed?.length > 0
                      ? `。失败: ${data.failed.join("、")}`
                      : "";
                  setMessage({
                    type: "success",
                    text: `Projection 重建完成 (${data.types?.length ?? 0} 种类型)${failed}`,
                  });
                  router.refresh();
                } else {
                  setMessage({
                    type: "error",
                    text: data.error || "重建失败",
                  });
                }
              } catch {
                setMessage({ type: "error", text: "网络错误" });
              } finally {
                setRebuilding(false);
              }
            }}
            disabled={rebuilding}
            className="inline-flex items-center gap-2 rounded-lg bg-ary-blue-700 px-4 py-2 text-sm font-semibold text-white transition-colors hover:bg-ary-blue-800 disabled:opacity-50"
          >
            <RefreshCw className={`h-4 w-4 ${rebuilding ? "animate-spin" : ""}`} />
            {rebuilding ? "重建中..." : "重建 Projection"}
          </button>
        </div>

        {/* Danger Zone */}
        <div className="rounded-xl border border-red-200 bg-white p-6">
          <h2 className="mb-4 flex items-center gap-2 text-lg font-semibold text-red-700">
            <AlertTriangle className="h-5 w-5" />
            危险区域
          </h2>

          <p className="mb-4 text-sm text-ary-muted">
            以下操作不可逆，请谨慎执行。
          </p>

          <div className="space-y-4">
            {currentStatus !== "archived" && (
              <div className="rounded-lg border border-red-100 bg-red-50 p-4">
                <div className="flex items-start justify-between">
                  <div>
                    <p className="font-medium text-red-800">归档赛事</p>
                    <p className="mt-1 text-xs text-red-600">
                      归档后赛事将不再活跃，所有数据保留但变为只读。
                    </p>
                  </div>
                  <button
                    onClick={handleArchive}
                    disabled={archiving}
                    className="inline-flex items-center gap-1.5 rounded-lg bg-red-600 px-3 py-2 text-xs font-semibold text-white transition-colors hover:bg-red-700 disabled:opacity-50"
                  >
                    <Archive className="h-4 w-4" />
                    {archiving ? "归档中..." : "归档"}
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
