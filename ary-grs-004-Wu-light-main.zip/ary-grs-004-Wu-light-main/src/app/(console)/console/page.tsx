import { auth } from "@/lib/auth";
import { redirect } from "next/navigation";
import Link from "next/link";
import { getUserRoles } from "@/lib/permissions";
import { prisma } from "@/lib/db";

export const dynamic = "force-dynamic";

export default async function ConsoleHomePage() {
  const session = await auth();
  if (!session?.user) {
    redirect("/login");
  }

  if (!(session.user as any).profileCompleted) {
    redirect("/console/profile/complete");
  }

  const userRoles = getUserRoles((session.user as any).roles ?? "[]");

  const managedRaces =
    userRoles.includes("organizer") || userRoles.includes("admin")
      ? await prisma.race.findMany({
          where: userRoles.includes("admin") ? {} : { organizerId: session.user.id },
          orderBy: { createdAt: "desc" },
          take: 10,
        })
      : [];

  const riderRegistrations =
    userRoles.includes("rider")
      ? await prisma.registration.findMany({
          where: { userId: session.user.id },
          include: { race: true },
          orderBy: { createdAt: "desc" },
        })
      : [];

  const judgeAssignments =
    userRoles.includes("judge")
      ? await prisma.judgeAssignment.findMany({
          where: { judgeId: session.user.id },
          include: { work: { include: { registration: { include: { race: true } } } } },
          orderBy: { assignedAt: "desc" },
        })
      : [];

  return (
    <div className="mx-auto max-w-[1440px] px-6 py-8">
      <h1 className="mb-1 text-2xl font-bold text-slate-900">Console</h1>
      <p className="mb-8 text-sm text-muted-foreground">
        Welcome, {session.user.name || "Rider"}. Your roles: {userRoles.join(", ") || "none"}
      </p>

      <div className="grid gap-6 lg:grid-cols-3">
        {userRoles.includes("admin") && (
          <Link
            href="/console/admin"
            className="rounded-xl border bg-white p-6 shadow-sm transition-shadow hover:shadow-md"
          >
            <h2 className="text-lg font-semibold">Admin Console</h2>
            <p className="mt-1 text-sm text-muted-foreground">Manage users, roles, and system settings</p>
          </Link>
        )}

        {userRoles.includes("organizer") && managedRaces.length > 0 && (
          <div className="rounded-xl border bg-white p-6 shadow-sm">
            <h2 className="mb-3 text-lg font-semibold">Organizer View</h2>
            <ul className="space-y-2">
              {managedRaces.slice(0, 5).map((race) => (
                <li key={race.id}>
                  <Link
                    href={`/console/races/${race.slug}/organizer`}
                    className="flex items-center justify-between rounded-md px-3 py-2 text-sm transition-colors hover:bg-slate-50"
                  >
                    <span>{race.title}</span>
                    <span className="rounded-full bg-slate-100 px-2 py-0.5 text-xs">{race.status}</span>
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        )}

        {userRoles.includes("rider") && riderRegistrations.length > 0 && (
          <div className="rounded-xl border bg-white p-6 shadow-sm">
            <h2 className="mb-3 text-lg font-semibold">Rider View</h2>
            <ul className="space-y-2">
              {riderRegistrations.slice(0, 5).map((reg) => (
                <li key={reg.id}>
                  <Link
                    href={`/console/races/${reg.race.slug}/rider`}
                    className="flex items-center justify-between rounded-md px-3 py-2 text-sm transition-colors hover:bg-slate-50"
                  >
                    <span>{reg.race.title}</span>
                    <span className="rounded-full bg-slate-100 px-2 py-0.5 text-xs">{reg.status}</span>
                  </Link>
                </li>
              ))}
            </ul>
          </div>
        )}

        {userRoles.includes("judge") && (
          <Link
            href={`/console/races/${judgeAssignments[0]?.work?.registration?.race?.slug || ""}/judge`}
            className="rounded-xl border bg-white p-6 shadow-sm transition-shadow hover:shadow-md"
          >
            <h2 className="text-lg font-semibold">Judge View</h2>
            <p className="mt-1 text-sm text-muted-foreground">
              {judgeAssignments.length > 0
                ? `${judgeAssignments.length} works assigned to you`
                : "No assignments yet"}
            </p>
          </Link>
        )}

        {userRoles.some((r) => r === "organizer" || r === "admin") && (
          <Link
            href="/console/screen"
            className="rounded-xl border bg-white p-6 shadow-sm transition-shadow hover:shadow-md"
          >
            <h2 className="text-lg font-semibold">Screen Console</h2>
            <p className="mt-1 text-sm text-muted-foreground">Control large screen display for live events</p>
          </Link>
        )}

        {userRoles.length === 0 && (
          <div className="rounded-xl border bg-white p-6 shadow-sm">
            <p className="text-sm text-muted-foreground">
              You don&apos;t have any roles assigned yet. Contact an admin to get started.
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
