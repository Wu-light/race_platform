import { auth } from "@/lib/auth";
import { redirect } from "next/navigation";
import { getUserRoles } from "@/lib/permissions";
import { RequireRole } from "@/components/layout/RequireRole";
import { prisma } from "@/lib/db";
import { AdminUserTable } from "./AdminUserTable";

export const dynamic = "force-dynamic";

export default async function AdminConsolePage() {
  const session = await auth();
  if (!session?.user) redirect("/login");

  if (!(session.user as any).profileCompleted) {
    redirect("/console/profile/complete");
  }

  const userRoles = getUserRoles((session.user as any).roles ?? "[]");
  if (!userRoles.includes("admin")) {
    redirect("/console/access-denied");
  }

  const users = await prisma.user.findMany({
    orderBy: { createdAt: "desc" },
    select: {
      id: true,
      githubId: true,
      name: true,
      email: true,
      avatar: true,
      roles: true,
      profileCompleted: true,
      createdAt: true,
      sessions: {
        orderBy: { expires: "desc" },
        take: 1,
        select: { expires: true },
      },
    },
  });

  const parsed = users.map((u) => {
    const lastSession = u.sessions[0];
    const lastSignInAt = lastSession
      ? new Date(lastSession.expires.getTime() - 30 * 24 * 60 * 60 * 1000)
      : null;
    const { sessions, ...rest } = u;
    return {
      ...rest,
      roles: JSON.parse(u.roles) as string[],
      lastSignInAt,
    };
  });

  return (
    <RequireRole roles={["admin"]} userRoles={userRoles}>
      <div className="mx-auto max-w-[1440px] px-6 py-8">
        <h1 className="mb-1 text-2xl font-bold text-slate-900">Admin Console</h1>
        <p className="mb-6 text-sm text-muted-foreground">
          Manage users and roles
        </p>
        <AdminUserTable users={parsed} />
      </div>
    </RequireRole>
  );
}
