"use client";

import { useState } from "react";
import type { Role } from "@/types";

const ALL_ROLES: Role[] = ["rider", "judge", "organizer", "admin"];

interface RoleEditorProps {
  userId: string;
  userName: string;
  currentRoles: Role[];
  onClose: () => void;
  onSaved: (roles: Role[]) => void;
}

export function RoleEditor({ userId, userName, currentRoles, onClose, onSaved }: RoleEditorProps) {
  const [selected, setSelected] = useState<Role[]>(currentRoles);
  const [saving, setSaving] = useState(false);

  const toggle = (role: Role) => {
    setSelected((prev) =>
      prev.includes(role) ? prev.filter((r) => r !== role) : [...prev, role],
    );
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      const res = await fetch(`/api/admin/users/${userId}/roles`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ roles: selected }),
      });
      if (!res.ok) throw new Error("Failed to update roles");
      onSaved(selected);
    } catch {
      // ignore
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40" onClick={onClose}>
      <div
        className="w-full max-w-sm rounded-xl bg-white p-6 shadow-xl"
        onClick={(e) => e.stopPropagation()}
      >
        <h3 className="mb-1 text-lg font-semibold text-slate-900">Edit Roles</h3>
        <p className="mb-4 text-sm text-muted-foreground">{userName}</p>

        <div className="space-y-2">
          {ALL_ROLES.map((role) => (
            <label
              key={role}
              className="flex cursor-pointer items-center gap-3 rounded-lg border border-slate-200 px-4 py-3 transition hover:border-ary-blue-300"
            >
              <input
                type="checkbox"
                checked={selected.includes(role)}
                onChange={() => toggle(role)}
                className="h-4 w-4 rounded border-slate-300 text-ary-blue-700 focus:ring-ary-blue-200"
              />
              <span className="text-sm font-medium capitalize text-slate-700">{role}</span>
            </label>
          ))}
        </div>

        <div className="mt-5 flex justify-end gap-3">
          <button
            onClick={onClose}
            className="rounded-lg border border-slate-300 px-4 py-2 text-sm font-medium text-slate-600 transition hover:bg-slate-50"
          >
            Cancel
          </button>
          <button
            onClick={handleSave}
            disabled={saving}
            className="rounded-lg bg-ary-blue-800 px-4 py-2 text-sm font-bold text-white transition hover:bg-ary-blue-700 disabled:opacity-50"
          >
            {saving ? "Saving..." : "Save"}
          </button>
        </div>
      </div>
    </div>
  );
}
