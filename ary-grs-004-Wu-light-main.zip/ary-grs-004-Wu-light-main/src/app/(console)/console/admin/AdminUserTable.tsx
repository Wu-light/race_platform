"use client";

import { useState } from "react";
import Image from "next/image";
import { RoleEditor } from "./RoleEditor";

interface UserRow {
  id: string;
  githubId: number | null;
  name: string | null;
  email: string | null;
  avatar: string | null;
  roles: string[];
  profileCompleted: boolean;
  createdAt: Date;
  lastSignInAt: Date | null;
}

interface Props {
  users: UserRow[];
}

function formatRelative(date: Date | null): string {
  if (!date) return "Never";
  const diff = Date.now() - new Date(date).getTime();
  const minutes = Math.floor(diff / 60000);
  if (minutes < 1) return "Just now";
  if (minutes < 60) return `${minutes}m ago`;
  const hours = Math.floor(minutes / 60);
  if (hours < 24) return `${hours}h ago`;
  const days = Math.floor(hours / 24);
  if (days < 30) return `${days}d ago`;
  return new Date(date).toLocaleDateString();
}

export function AdminUserTable({ users }: Props) {
  const [editUser, setEditUser] = useState<UserRow | null>(null);
  const [localUsers, setLocalUsers] = useState(users);

  const handleSaved = (roles: string[]) => {
    if (!editUser) return;
    setLocalUsers((prev) =>
      prev.map((u) => (u.id === editUser.id ? { ...u, roles } : u)),
    );
    setEditUser(null);
  };

  return (
    <>
      <div className="overflow-x-auto rounded-xl border bg-white">
        <table className="w-full text-left text-sm">
          <thead>
            <tr className="border-b bg-slate-50 text-[11px] font-semibold uppercase tracking-wider text-slate-500">
              <th className="px-4 py-3">User</th>
              <th className="px-4 py-3">GitHub ID</th>
              <th className="px-4 py-3">Roles</th>
              <th className="px-4 py-3">Profile</th>
              <th className="px-4 py-3">Last Sign-in</th>
              <th className="px-4 py-3" />
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {localUsers.map((user) => (
              <tr key={user.id} className="transition-colors hover:bg-slate-50">
                <td className="px-4 py-3">
                  <div className="flex items-center gap-3">
                    {user.avatar ? (
                      <Image
                        src={user.avatar}
                        alt=""
                        width={32}
                        height={32}
                        className="h-8 w-8 rounded-full object-cover"
                        unoptimized
                      />
                    ) : (
                      <div className="flex h-8 w-8 items-center justify-center rounded-full bg-slate-200 text-xs font-bold text-slate-500">
                        {(user.name ?? "?")[0]}
                      </div>
                    )}
                    <div>
                      <p className="font-medium text-slate-900">{user.name ?? "Unnamed"}</p>
                      {user.email && (
                        <p className="text-xs text-muted-foreground">{user.email}</p>
                      )}
                    </div>
                  </div>
                </td>
                <td className="px-4 py-3 font-mono text-xs text-slate-500">{user.githubId ?? "-"}</td>
                <td className="px-4 py-3">
                  <div className="flex flex-wrap gap-1">
                    {user.roles.map((role) => (
                      <span
                        key={role}
                        className="rounded-full bg-ary-blue-100 px-2.5 py-0.5 text-[11px] font-medium capitalize text-ary-blue-800"
                      >
                        {role}
                      </span>
                    ))}
                    {user.roles.length === 0 && (
                      <span className="text-xs text-muted-foreground">none</span>
                    )}
                  </div>
                </td>
                <td className="px-4 py-3">
                  {user.profileCompleted ? (
                    <span className="rounded-full bg-green-100 px-2.5 py-0.5 text-[11px] font-medium text-green-700">
                      Complete
                    </span>
                  ) : (
                    <span className="rounded-full bg-amber-100 px-2.5 py-0.5 text-[11px] font-medium text-amber-700">
                      Pending
                    </span>
                  )}
                </td>
                <td className="px-4 py-3 text-xs text-muted-foreground">
                  {formatRelative(user.lastSignInAt)}
                </td>
                <td className="px-4 py-3">
                  <button
                    onClick={() => setEditUser(user)}
                    className="rounded-lg border border-slate-300 px-3 py-1.5 text-xs font-medium text-slate-600 transition hover:bg-slate-50"
                  >
                    Edit Roles
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {editUser && (
        <RoleEditor
          userId={editUser.id}
          userName={editUser.name ?? "Unknown"}
          currentRoles={editUser.roles as any}
          onClose={() => setEditUser(null)}
          onSaved={handleSaved as any}
        />
      )}
    </>
  );
}
